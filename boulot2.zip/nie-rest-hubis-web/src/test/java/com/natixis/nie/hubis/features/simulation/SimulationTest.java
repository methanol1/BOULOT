package com.natixis.nie.hubis.features.simulation;

import com.natixis.nie.hubis.core.AppProperties;
import com.natixis.nie.hubis.core.domain.simulation.Simulation;
import com.natixis.nie.hubis.core.domain.simulation.SimulationsDatas;
import com.natixis.nie.hubis.core.exception.AppException;
import org.junit.Before;
import org.junit.Test;

import static com.natixis.nie.hubis.core.domain.simulation.SimulationCriteria.dirigeantSalarieWithoutSalarie;
import static org.assertj.core.api.Assertions.assertThat;

public class SimulationTest {

    private SimulationsDatas datas;
    private SimulationService service;

    @Before
    public void setUp() throws Exception {
        AppProperties appProperties = new AppProperties();
        datas = new SimulationsDatas.Builder(appProperties).build();
        service = new SimulationService(appProperties);
    }


    @Test(expected = AppException.class)
    public void canNotBuildASimulationWithoutEpargneAndCesu() throws Exception {
        service.build(dirigeantSalarieWithoutSalarie(datas), 0, 0);
    }

    @Test
    public void mustComputeTotalVersementWithCesuAndEpargne() throws Exception {

        Simulation simulation = service.build(dirigeantSalarieWithoutSalarie(datas), 3500, 1000);

        assertThat(simulation.getTotalVersement()).isEqualTo(4500);
    }

    @Test
    public void mustComputeTotalMaxVersementWithCesuAndEpargne() throws Exception {

        Simulation simulation = service.build(dirigeantSalarieWithoutSalarie(datas), 3500, 1000);

        assertThat(simulation.getOptimizedTotalVersement()).isEqualTo(12704);
    }

    @Test
    public void mustComputeTotalVersementWithOnlyCesu() throws Exception {

        Simulation simulation = service.build(dirigeantSalarieWithoutSalarie(datas), 0, 1000);

        assertThat(simulation.getTotalVersement()).isEqualTo(1000);
    }

    @Test
    public void mustComputeTotalVersementWithOnlyEpargne() throws Exception {

        Simulation simulation = service.build(dirigeantSalarieWithoutSalarie(datas), 3500, 0);

        assertThat(simulation.getTotalVersement()).isEqualTo(3500);
    }

}
