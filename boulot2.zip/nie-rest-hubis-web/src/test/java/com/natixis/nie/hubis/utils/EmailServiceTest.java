package com.natixis.nie.hubis.utils;

import com.natixis.nie.hubis.core.AppProperties;
import com.natixis.nie.hubis.features.email.EmailService;
import com.natixis.nie.hubis.features.email.ResetEmailTemplate;
import org.junit.Test;

import java.util.UUID;

import static org.junit.Assert.fail;

public class EmailServiceTest {

    @Test
    public void shouldThrowExWhenEmailCannotBeSent() throws Exception {

        EmailService emailService = new EmailService();

        try {
            emailService.sendEmail("t@t.com", new ResetEmailTemplate(UUID.randomUUID(), new AppProperties()));
            fail();
        } catch (Exception e) {

        }

    }
}