package com.natixis.nie.hubis.it.web;

import com.natixis.nie.hubis.features.simulation.web.dto.*;
import com.natixis.nie.hubis.features.user.dto.ForgottenPasswordDTO;
import com.natixis.nie.hubis.features.user.dto.RawCredentialsDTO;
import com.natixis.nie.hubis.it.utils.IntegrationTestBase;
import com.natixis.nie.hubis.web.Errors;
import com.natixis.nie.hubis.web.dto.StateDTO;
import org.junit.Test;

import java.util.UUID;

import static com.natixis.nie.hubis.core.domain.State.SIMULATION;
import static com.natixis.nie.hubis.it.utils.DataUtil.*;
import static com.natixis.nie.hubis.it.utils.RestClient.IS_OK;
import static org.assertj.core.api.Assertions.assertThat;

public class SignupResourceIT extends IntegrationTestBase {


    @Test
    public void whenUserSignUpItsStateIsUpdated() throws Exception {

        SignupDTO dto = new SignupDTO(new NewUserDTO(generateEmail(), "Hubis123"), createDefaultContratDTO());
        client.signup(dto, response -> {
            assertThat(response.code()).isEqualTo(200);
            StateDTO stateDTO = client.asPojo(response.body(), StateDTO.class);
            assertThat(stateDTO.getName()).isEqualTo(SIMULATION);
        });
    }

    @Test
    public void whenUserSignUpAnEmailIsSent() throws Exception {

        String email = generateEmail();

        client.signup(new SignupDTO(new NewUserDTO(email, "Hubis123"), createDefaultContratDTO()));

        assertThat(mailServer.getLastEmailContent()).contains(email);
        assertThat(mailServer.extractLinkFromEmail()).isEqualTo("http://localhost:9000/optimisation-fiscale.html#/login");
    }

    @Test
    public void canSignUpWithOnlyEpargne() throws Exception {

        String email = generateEmail();
        String password = "Hubis123";
        SignupDTO dto = new SignupDTO(new NewUserDTO(email, password), createDefaultContratDTO());

        client
                .signup(dto)
                .login(new RawCredentialsDTO(email, password), IS_OK);
    }

    @Test
    public void canSignUpWithOnlyCesu() throws Exception {

        String email = generateEmail();
        String password = "Hubis123";
        CartDTO cesuOnly = new CartDTO();
        cesuOnly.setChosenCesuVersement(1000);
        SignupDTO dto = new SignupDTO(new NewUserDTO(email, password), new NewSimulationDTO(new SimulationCriteriaDTO(), cesuOnly));

        client
                .signup(dto)
                .login(new RawCredentialsDTO(email, password), IS_OK);
    }

    @Test
    public void cannotSignupWithEmptyCart() throws Exception {

        CartDTO emptyCart = new CartDTO();
        SignupDTO dto = new SignupDTO(new NewUserDTO(generateEmail(), "Hubis123"), new NewSimulationDTO(new SimulationCriteriaDTO(), emptyCart));

        client
                .signup(dto, response -> {
                    assertThat(response.code()).isEqualTo(400);
                    Errors errors = client.asPojo(response.body(), Errors.class);
                    assertThat(errors.getMessages()).hasSize(1);
                });
    }

    @Test
    public void cannotSignupWithInvalidPassword() throws Exception {

        CartDTO emptyCart = new CartDTO();
        SignupDTO dto = new SignupDTO(new NewUserDTO(generateEmail(), "too_weak"), new NewSimulationDTO(new SimulationCriteriaDTO(), emptyCart));

        client
                .signup(dto, response -> {
                    assertThat(response.code()).isEqualTo(400);
                    Errors errors = client.asPojo(response.body(), Errors.class);
                    assertThat(errors.getMessages()).hasSize(1);
                });
    }

    @Test
    public void cannotSignupIfUsernameIsAlreadyUsedByAPendingUser() throws Exception {

        SignupDTO dto = createDefaultSignupDTO();
        client
                .signup(dto)
                .forgottenPassword(new ForgottenPasswordDTO(dto.getNewUser().getEmail()), IS_OK);

        client
                .signup(dto, response -> {
                    assertThat(response.code()).isEqualTo(400);
                    Errors errors = client.asPojo(response.body(), Errors.class);
                    assertThat(errors.getMessages()).hasSize(1);
                });
    }

    @Test
    public void cannotSignupIfUsernameIsAlreadyUsedByAUser() throws Exception {

        SignupDTO dto = createDefaultSignupDTO();
        client.signup(dto);

        client.signup(dto, response -> {
            assertThat(response.code()).isEqualTo(400);
            client.assertResponseContainsErrors(response);
        });
    }

    @Test
    public void cannotLoginBeforeInitPassword() throws Exception {

        client
                .signup(createDefaultSignupDTO())
                .login(new RawCredentialsDTO("jdoe", "value"), response -> {
                    assertThat(response.code()).isEqualTo(400);
                });
    }

}
