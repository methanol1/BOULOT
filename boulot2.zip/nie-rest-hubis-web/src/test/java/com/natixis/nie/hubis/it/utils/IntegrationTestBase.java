package com.natixis.nie.hubis.it.utils;


import com.natixis.nie.hubis.it.utils.server.JBossServer;
import com.natixis.nie.hubis.it.utils.server.JettyServer;
import com.natixis.nie.hubis.it.utils.server.WebServer;
import org.junit.After;
import org.junit.Before;

public class IntegrationTestBase {

    protected MailServer mailServer;
    protected RestClient client;

    @Before
    public void initIntegrationTest() throws Exception {
        mailServer = MailServer.INSTANCE;
        client = new RestClient(getWebServer().getPort());
    }

    @After
    public void resetMailServer() throws Exception {
        mailServer.reset();
    }

    protected static WebServer getWebServer() {

        String isLocal = System.getProperty("hubis.test.jboss");
        if (isLocal != null && isLocal.equals("true")) {
            return JBossServer.instance;
        } else {
            return JettyServer.instance;
        }
    }
}
