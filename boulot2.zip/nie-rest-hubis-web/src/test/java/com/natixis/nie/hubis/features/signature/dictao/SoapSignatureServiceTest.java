package com.natixis.nie.hubis.features.signature.dictao;

import com.natixis.nie.hubis.core.AppProperties;
import com.natixis.nie.hubis.signature.*;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.core.io.ClassPathResource;

import javax.net.ssl.SSLSocketFactory;
import java.io.File;
import java.io.FileInputStream;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

public class SoapSignatureServiceTest {

    private AppProperties appProperties;

    @Before
    public void setUp() throws Exception {
        appProperties = new AppProperties();
    }

    @Test
    @Ignore
    public void canRequestTransactionService() throws Exception {
        String tenant = "hubis_rec";
        String policy = "service";
        String businessId = "hubis";
        String typeDoc = "CONTRACT";
        String typeUser = "SIGNER";
        String label = "LABEL";
        String zoneSignatureEntite = "ZONESIGNENTITE";
        String zoneSignatureUser = "ZONESIGNUSER";
        String fileName = "contrat.pdf";

        //Ouverture du service
        DictaoWSClient service = new DictaoWSClient(appProperties);

        //Création de la transaction
        TransactionPort transactionPort = service.getTransactionPort();
        String transactionId = transactionPort.createTransaction(tenant, policy, businessId, null, null);

        assertThat(transactionId).isNotNull();
        assertThat(UUID.nameUUIDFromBytes(transactionId.getBytes())).isNotNull();

        //Ajout du Document
        DocumentPort documentPort = service.getDocumentPort();
        File file = new ClassPathResource("signature/contrat.pdf").getFile();
        Document doc = new Document();
        doc.setMimetype("application/pdf");
        doc.setFilename(fileName);
        doc.setLabel(label);
        doc.setDescription("Description du bulletin de souscription Hubis");
        FileInputStream fis = new FileInputStream(file);
        byte[] content = new byte[(int) file.length()];
        fis.read(content);
        fis.close();
        doc.setContent(content);

        SignatureField signatureFieldEntite = new SignatureField();
        signatureFieldEntite.setLabel(zoneSignatureEntite);
        signatureFieldEntite.setLocation(null);
        doc.getSignatureField().add(signatureFieldEntite);

        SignatureField signatureFieldUser = new SignatureField();
        signatureFieldUser.setLabel(zoneSignatureUser);
        signatureFieldUser.setLocation(null);
        doc.getSignatureField().add(signatureFieldUser);

        documentPort.putDocument(transactionId, doc, typeDoc, false, null);

        //Création d’un accès utilisateur:
        /*Informations sur le signataire*/
        PersonalInfo pi = new PersonalInfo();
        pi.setUserId(UUID.randomUUID().toString());
        SignatureInfo si = new SignatureInfo();
        si.setTitle("M.");
        si.setFirstName("Jean");
        si.setLastName("Dupont");
        UserDN udn = new UserDN();
        udn.setCountryName("FR");
        udn.setOrganizationName("Natixis");
        udn.setCommonName("Jean Dupont");
        si.setUserDN(udn);
        pi.setSignatureInfo(si);

		/*Informations sur l’authentification*/
        AuthenticationInfo ai = new AuthenticationInfo();
        ai.setPhoneNumber("0762101876");
        pi.setAuthenticationInfo(ai);

        //Personnalisation du SMS (option)
        /*AuthenticationContextType context = new AuthenticationContextType();
        ContextMetadataType ctxMd = new ContextMetadataType();
		ctxMd.setName("1");
		ctxMd.setValue("Jean");
		context.getMetadatas().add(ctxMd);
		ContextMetadataType ctxMd1 = new ContextMetadataType();
		ctxMd1.setName("2");
		ctxMd1.setValue("Dupont");
		context.getMetadatas().add(ctxMd1);*/

        List<String> authorizedDocs = Arrays.asList(new String[]{typeDoc});
        Long timeout = 36000000L;
        Metadata metadata = null;
        String uaId = transactionPort.createUserAccess(transactionId, pi, timeout, metadata, authorizedDocs, typeUser, null, false);

        //Signature Cachet d’un document:
        SignatureRequest signatureRequest = new SignatureRequest();
        signatureRequest.setType(typeDoc);
        signatureRequest.setLabel(zoneSignatureEntite);
        String signPolicy = null;
        documentPort.signDocuments(transactionId, Arrays.asList(signatureRequest), signPolicy);

        //Document docOut = documentPort.getDocument(transactionId, fileName);
        //assertThat(docOut).isNotNull();
    }
}