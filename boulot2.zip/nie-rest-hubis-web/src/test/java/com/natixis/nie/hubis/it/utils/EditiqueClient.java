package com.natixis.nie.hubis.it.utils;

import com.natixis.nie.hubis.core.AppProperties;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;


public class EditiqueClient {

    private final static Logger logger = LoggerFactory.getLogger(EditiqueClient.class);

    private final OkHttpClient client;
    private final AppProperties appProperties;

    public EditiqueClient() {
        client = new OkHttpClient.Builder().build();
        appProperties = new AppProperties();
    }

    public boolean canPingEditique() throws IOException {
        try {
            Request request = new Request.Builder()
                    .url(appProperties.get("editique.wsdl.endpoint"))
                    .get()
                    .build();

            Response response = client.newCall(request).execute();
            return response.code() != 404;
        } catch (Exception e) {
            logger.error("Unable to reach filenet server due to " + e.getMessage());
            return false;
        }
    }
}
