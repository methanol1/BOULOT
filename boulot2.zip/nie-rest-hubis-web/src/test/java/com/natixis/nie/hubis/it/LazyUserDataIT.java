package com.natixis.nie.hubis.it;

import com.natixis.nie.hubis.core.db.UserDAO;
import com.natixis.nie.hubis.core.domain.User;
import com.natixis.nie.hubis.it.utils.DBTestBase;
import com.natixis.nie.hubis.it.utils.DataUtil;
import org.junit.Before;
import org.junit.Test;

import static com.natixis.nie.hubis.it.utils.DataUtil.generateEmail;
import static com.natixis.nie.hubis.it.utils.DataUtil.generateSaltedPassword;
import static org.assertj.core.api.Assertions.assertThat;


public class LazyUserDataIT extends DBTestBase {

    private UserDAO userDAO;

    @Before
    public void setUp() throws Exception {
        userDAO = DataUtil.createUserDAO(dataSource);
    }

    @Test
    public void shouldReturnAnEmptyOptionalWhenUserHasnotEntreprise() throws Exception {

        User user = userDAO.create(generateEmail(), generateSaltedPassword());

        assertThat(user.getEntrepriseAsOptional().isPresent()).isFalse();
    }
}