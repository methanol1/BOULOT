package com.natixis.nie.hubis.it;

import com.natixis.nie.hubis.core.SouscriptionService;
import com.natixis.nie.hubis.core.db.DataSourceHandler;
import com.natixis.nie.hubis.core.db.EntrepriseDAO;
import com.natixis.nie.hubis.core.db.TransactionManager;
import com.natixis.nie.hubis.core.db.UserDAO;
import com.natixis.nie.hubis.core.domain.*;
import com.natixis.nie.hubis.core.domain.kbis.Kbis;
import com.natixis.nie.hubis.features.entreprise.kbis.KbisException;
import com.natixis.nie.hubis.features.entreprise.kbis.societe.ClasspathKbisFetcher;
import com.natixis.nie.hubis.features.entreprise.kbis.societe.xml.KbisXmlMapper;
import com.natixis.nie.hubis.it.utils.DBTestBase;
import com.natixis.nie.hubis.it.utils.DataUtil;
import com.natixis.nie.hubis.utils.StubbedDatas;
import org.junit.Before;
import org.junit.Test;

import java.time.Month;

import static com.natixis.nie.hubis.it.utils.DataUtil.*;
import static com.natixis.nie.hubis.utils.StubbedDatas.defaultDatas;
import static org.assertj.core.api.Assertions.assertThat;

public class EntrepriseIT extends DBTestBase {

    private EntrepriseDAO entrepriseDAO;
    private UserDAO userDAO;
    private SouscriptionService souscriptionService;
    private ClasspathKbisFetcher kbisFetcher;

    @Before
    public void setUp() throws Exception {

        DataSourceHandler dataSourceHandler = new DataSourceHandler(dataSource);
        StubbedDatas datas = defaultDatas();
        entrepriseDAO = new EntrepriseDAO(new TransactionManager(dataSourceHandler), new KbisXmlMapper(datas));
        userDAO = DataUtil.createUserDAO(dataSource);
        souscriptionService = DataUtil.createSubscriptionManager(dataSource);
        kbisFetcher = new ClasspathKbisFetcher(new KbisXmlMapper(datas));
    }

    @Test
    public void canSaveEntreprise() throws Exception {

        User user = userDAO.create(generateEmail(), generateSaltedPassword());
        Entreprise entreprise = DataUtil.createDummyEntreprise();

        souscriptionService.createEntreprise(user, entreprise);

        Id entrepriseId = user.getEntreprise().getId().get();
        assertThat(entrepriseId).isNotNull();
        Entreprise result = entrepriseDAO.findByUser(user);
        assertThat(result).isNotNull();
        assertThat(result.getId()).isNotNull();
        assertThat(result.getDirigeant().getFullname()).isEqualTo("MONSIEUR CLAUDE SENBEL");
        assertThat(result.getDirigeant().getFonction()).isEqualTo("Dirigeant");
        assertThat(result.getRaisonSociale()).isEqualTo("DailyBrian");
        assertThat(result.getSiret().asString()).isEqualTo("81456211200015");
        assertThat(result.getRaisonSociale()).isEqualTo("DailyBrian");
        assertThat(result.getEffectif()).isEqualTo(10);
        assertThat(result.getMoisDeCloture()).isEqualTo(Month.JANUARY);
        assertThat(result.getAdresse().getRue()).isEqualTo("32 rue des Lilas");
        assertThat(result.getAdresse().getCodePostal()).isEqualTo(75001);
        assertThat(result.getAdresse().getVille()).isEqualTo("Paris");
        assertThat(result.getFormeJuridique().getLabel()).isEqualTo("Affaire personnelle artisan commerçant");
        assertThat(result.getNace().getCode()).isEqualTo("2611Z");
        assertThat(result.getBankData().getBic()).isEqualTo("DABAIE2D");
        assertThat(result.getBankData().getIban()).isEqualTo("FR1420041010050500013M02606");
        assertThat(result.getBankData().getTelephone()).isEqualTo("0614789542");
        assertThat(result.getBankData().getAgence()).isEqualTo("BRED");
        assertThat(result.getKbis().isPresent()).isFalse();
    }

    @Test
    public void canSaveEntrepriseWithEncryptedIban() throws Exception {

        User user = userDAO.create(generateEmail(), generateSaltedPassword());
        Entreprise entreprise = DataUtil.createDummyEntreprise();
        souscriptionService.createEntreprise(user, entreprise);

        Entreprise crypted = DataUtil.createDummyEntreprise(new BankData("DABAIE2D", "***************************", "0614789542", "BRED"));
        souscriptionService.createEntreprise(user, crypted);

        Entreprise result = entrepriseDAO.findByUser(user);
        assertThat(result.getBankData().getIban()).isEqualTo("FR1420041010050500013M02606");
    }

    @Test
    public void canSaveEntrepriseWithKbis() throws Exception {

        //Prepare Dataset
        User user = userDAO.create(generateEmail(), generateSaltedPassword());
        Entreprise entreprise = createEntrepriseWithKbis();

        souscriptionService.createEntreprise(user, entreprise);

        Entreprise saved = entrepriseDAO.findByUser(user);
        assertThat(saved).isNotNull();
        assertThat(saved.getKbis().isPresent()).isTrue();
        Kbis kbis = saved.getKbis().get();
        assertThat(kbis.asXml()).isNotNull();
        assertThat(kbis.asXml()).isEqualTo(loadKbisXml(new Siret(entreprise.getSiret().asString())));
    }


    public Entreprise createEntrepriseWithKbis() throws KbisException {

        Siret siret = new Siret("32052067900020");
        FormeJuridique formeJuridique = new FormeJuridique(1500, "Affaire personnelle profession libérale", true);
        Nace nace = new Nace("8621Z", "Activité des médecins généralistes", true);
        Adresse adresse = new Adresse("11 RUE LEPIC", 75018, "Paris");
        Dirigeant dirigeant = createDummyDirigeant();
        Kbis kbis = createKbis(siret);

        return new Entreprise(siret, "MONSIEUR LAURENT BERDAH", formeJuridique, nace, adresse, 10, Month.JANUARY, dirigeant, createDummyBankData(), kbis, null);
    }

    public Kbis createKbis(Siret siret) throws KbisException {
        return kbisFetcher.fetch(siret).get();
    }

    public String loadKbisXml(Siret siret) throws KbisException {
        return kbisFetcher.fetch(siret).get().asXml();
    }

}