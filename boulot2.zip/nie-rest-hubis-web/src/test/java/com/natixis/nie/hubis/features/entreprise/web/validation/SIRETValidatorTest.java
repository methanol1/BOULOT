package com.natixis.nie.hubis.features.entreprise.web.validation;

import com.natixis.nie.hubis.web.validation.Validation;
import org.junit.Test;

import javax.validation.constraints.NotNull;

import static org.assertj.core.api.Assertions.assertThat;

public class SIRETValidatorTest {

    @Test
    public void shouldAcceptValidIBAN() throws Exception {

        MySiret mySiret = new MySiret("81456211200015");//last value

        assertThat(Validation.hasErros(mySiret)).isFalse();
    }

    @Test
    public void shouldRejectValidIBANWithSpaces() throws Exception {

        MySiret mySiret = new MySiret("8145621 1200015");//last value

        assertThat(Validation.hasErros(mySiret)).isTrue();
    }

    @Test
    public void shouldRejectIBANWithInvalidChecksum() throws Exception {

        MySiret mySiret = new MySiret("81456211300015");//9th digit

        assertThat(Validation.hasErros(mySiret)).isTrue();
    }

    @Test
    public void shouldRejectInvalidValue() throws Exception {

        MySiret mySiret = new MySiret("invalid");

        assertThat(Validation.hasErros(mySiret)).isTrue();
    }

    private static class MySiret {
        @NotNull
        @SIRET
        private String siret;

        public MySiret(String siret) {
            this.siret = siret;
        }
    }

}