package com.natixis.nie.hubis.it.utils;

import com.icegreen.greenmail.util.GreenMail;
import com.icegreen.greenmail.util.ServerSetup;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import java.io.IOException;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.jayway.awaitility.Awaitility.await;
import static java.util.concurrent.TimeUnit.MILLISECONDS;

public class MailServer {

    private final static Logger logger = LoggerFactory.getLogger(MailServer.class);
    public static MailServer INSTANCE = createInstance();
    private static final int DEFAULT_MAIL_SERVER_PORT = 3025;
    private final int port;

    private GreenMail greenMail;

    public MailServer(int port) {
        this.port = port;
        greenMail = new GreenMail(new ServerSetup(this.port, null, ServerSetup.PROTOCOL_SMTP));
    }

    private void start() throws Exception {
        greenMail.start();
        logger.info("Greenmail server has been started on port {}", port);
    }

    private void stop() throws Exception {
        greenMail.stop();
        logger.info("Greemail server has been stopped");
    }

    public UUID extractResetKeyFromEmail() throws IOException, MessagingException {

        Matcher matcher = Pattern.compile("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}").matcher(getLastEmailContent().trim());

        if (!matcher.find()) {
            Assert.fail("Unable to find reset key in email content");
        }

        return UUID.fromString(matcher.group());
    }

    public String extractLinkFromEmail() throws IOException, MessagingException {

        Matcher matcher = Pattern.compile("href=\"([^\"]*)\"").matcher(getLastEmailContent().trim());

        if (!matcher.find()) {
            Assert.fail("Unable to find href in email content");
        }

        return matcher.group(1);
    }

    public String getLastEmailContent() throws IOException, MessagingException {
        await().atMost(500, MILLISECONDS).until(() -> greenMail.getReceivedMessages().length > 0);
        MimeMessage[] receivedMessages = greenMail.getReceivedMessages();
        return ((MimeMultipart) receivedMessages[receivedMessages.length - 1].getContent()).getBodyPart(0).getContent().toString();
    }


    public void reset() {
        greenMail.reset();
    }

    private static MailServer createInstance() {
        try {

            MailServer mailServer = new MailServer(DEFAULT_MAIL_SERVER_PORT);
            mailServer.start();

            shutdownWhenJVMExit(mailServer);

            return mailServer;

        } catch (Exception e) {
            throw new RuntimeException("Failed to initialize Greenmail server instance", e);
        }

    }

    private static void shutdownWhenJVMExit(final MailServer mailServer) {
        Runtime.getRuntime().addShutdownHook(new Thread() {

            @Override
            public void run() {
                try {
                    mailServer.stop();
                } catch (Exception e) {
                    throw new RuntimeException("Unable to stop Greenmail server", e);
                }
            }
        });
    }

}
