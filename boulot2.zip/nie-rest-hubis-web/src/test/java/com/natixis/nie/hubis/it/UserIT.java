package com.natixis.nie.hubis.it;

import com.natixis.nie.hubis.core.db.UserDAO;
import com.natixis.nie.hubis.core.domain.User;
import com.natixis.nie.hubis.it.utils.DBTestBase;
import org.junit.Before;
import org.junit.Test;

import static com.natixis.nie.hubis.it.utils.DataUtil.*;
import static org.assertj.core.api.Assertions.assertThat;

public class UserIT extends DBTestBase {

    private UserDAO userDAO;

    @Before
    public void setUp() throws Exception {
        userDAO = createUserDAO(dataSource);
    }

    @Test
    public void canSaveAUser() throws Exception {

        String email = generateEmail();
        userDAO.create(email, generateSaltedPassword());

        User saved = userDAO.get(email);

        assertThat(saved.getEmail()).isEqualTo(email);
    }

    @Test
    public void canCheckIfAUserExists() throws Exception {

        String email = generateEmail();
        userDAO.create(email, generateSaltedPassword());

        boolean exists = userDAO.exists(email);

        assertThat(exists).isTrue();
    }

    @Test
    public void canSearchAUser() throws Exception {

        String email = generateEmail();
        userDAO.create(email, generateSaltedPassword());

        User admin = userDAO.get(email);

        assertThat(admin.getEmail()).isEqualTo(email);
    }

}