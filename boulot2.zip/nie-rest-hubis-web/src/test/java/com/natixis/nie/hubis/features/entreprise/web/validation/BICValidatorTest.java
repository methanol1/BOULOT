package com.natixis.nie.hubis.features.entreprise.web.validation;

import com.natixis.nie.hubis.web.validation.Validation;
import org.junit.Test;

import javax.validation.constraints.NotNull;

import static org.assertj.core.api.Assertions.assertThat;


public class BICValidatorTest {

    @Test
    public void shouldAcceptValidIBAN() throws Exception {

        MyBic myBic = new MyBic("DABAIE2D");

        assertThat(Validation.hasErros(myBic)).isFalse();
    }

    @Test
    public void shouldAcceptLowerCaseValidIBAN() throws Exception {

        MyBic myBic = new MyBic("dabaie2d");

        assertThat(Validation.hasErros(myBic)).isFalse();
    }

    @Test
    public void shouldRejectValidIBANWithSpaces() throws Exception {

        MyBic myBic = new MyBic("DABA IE2D");

        assertThat(Validation.hasErros(myBic)).isTrue();
    }

    @Test
    public void shouldRejectIBANWithInvalidCountry() throws Exception {

        MyBic myBic = new MyBic("GRACXXP2");//XX

        assertThat(Validation.hasErros(myBic)).isTrue();
    }

    @Test
    public void shouldRejectInvalidValue() throws Exception {

        MyBic myBic = new MyBic("invalid");

        assertThat(Validation.hasErros(myBic)).isTrue();
    }

    private static class MyBic {
        @NotNull
        @BIC
        private String bic;

        public MyBic(String bic) {
            this.bic = bic;
        }
    }
}