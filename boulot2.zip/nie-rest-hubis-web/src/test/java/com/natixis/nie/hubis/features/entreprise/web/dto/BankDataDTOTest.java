package com.natixis.nie.hubis.features.entreprise.web.dto;

import com.natixis.nie.hubis.it.utils.DataUtil;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;


public class BankDataDTOTest {

    private BankDataDTO dto;

    @Before
    public void setUp() throws Exception {

        dto = DataUtil.createDefaultBankDataDTO();
    }

    @Test
    public void shouldRejectPhoneNumberWithChar() throws Exception {

        dto.setTelephone("X148759421");
        assertThat(dto.isValid()).isFalse();
    }

    @Test
    public void shouldRejectInvalidPhoneNumber() throws Exception {

        dto = DataUtil.createDefaultBankDataDTO();
        dto.setTelephone("00148759421");
        assertThat(dto.isValid()).isFalse();
    }

    @Test
    public void shouldAcceptValidPhoneNumber() throws Exception {

        BankDataDTO dto = DataUtil.createDefaultBankDataDTO();
        dto.setTelephone("0148759421");

        assertThat(dto.isValid()).isTrue();
    }
}