package com.natixis.nie.hubis.it.utils.server;


import com.natixis.nie.hubis.core.db.DataSourceHandler;
import com.natixis.nie.hubis.core.domain.DocumentType;
import com.natixis.nie.hubis.it.utils.FilenetClient;
import org.eclipse.jetty.jndi.factories.MailSessionReference;
import org.eclipse.jetty.maven.plugin.JettyWebAppContext;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.util.component.LifeCycle;
import org.eclipse.jetty.util.resource.Resource;
import org.eclipse.jetty.webapp.Configuration;
import org.eclipse.jetty.webapp.WebAppClassLoader;
import org.eclipse.jetty.webapp.WebAppContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.naming.NamingException;
import javax.sql.DataSource;
import java.io.File;
import java.util.Properties;

import static com.natixis.nie.hubis.it.utils.DBUtil.createDatasource;

public class JettyServer implements WebServer {

    private final static Logger logger = LoggerFactory.getLogger(JettyServer.class);
    public static JettyServer instance = instance(9899);

    private final int port;
    private final Server server;
    private final DataSource datasource;
    private final MailSessionReference mailSession;

    private JettyServer(int port) {

        try {
            System.setProperty("app.env", "test");
            this.port = port;
            this.server = new Server(this.port);
            this.datasource = createDatasource();
            this.mailSession = createMailSession();

            configureServer(createWebAppContext());

        } catch (Exception e) {
            throw new RuntimeException("Unable to create Jetty web app context", e);
        }
    }

    private MailSessionReference createMailSession() {
        MailSessionReference mailSessionReference = new MailSessionReference();
        Properties props = new Properties();
        props.put("mail.user", "admin");
        props.put("mail.password", "secret");
        props.put("mail.transport.protocol", "smtp");
        props.put("mail.smtp.host", "localhost");
        props.put("mail.smtp.port", "3025");
        props.put("mail.debug", "false");
        mailSessionReference.setProperties(props);
        return mailSessionReference;
    }

    private JettyWebAppContext createWebAppContext() throws Exception {

        JettyWebAppContext context = new JettyWebAppContext();
        context.setParentLoaderPriority(true);
        context.setContextPath("/nie-rest-hubis-web");
        context.setTempDirectory(new File("./target/tmp"));
        context.setClasses(new File("./target/classes"));
        context.setResourceBase("./src/main/webapp/");
        context.setWar("./src/main/webapp/");
        context.setClassLoader(new WebAppClassLoader(context));
        context.setInitParameter("resteasy.injector.factory", "org.jboss.resteasy.cdi.CdiInjectorFactory");

        return context;
    }

    private void configureServer(WebAppContext context) throws NamingException {
        Resource.setDefaultUseCaches(false);

        server.setStopAtShutdown(true);//auto stop
        server.setAttribute("hubis", new org.eclipse.jetty.plus.jndi.Resource("java:comp/env/jdbc/hubis", this.datasource));
        server.setAttribute("mail", new org.eclipse.jetty.plus.jndi.Resource("mail/session", this.mailSession));
        server.setAttribute(Configuration.ATTR, new String[]{
                "org.eclipse.jetty.maven.plugin.MavenWebInfConfiguration",
                "org.eclipse.jetty.webapp.WebXmlConfiguration",
                "org.eclipse.jetty.webapp.MetaInfConfiguration",
                "org.eclipse.jetty.webapp.FragmentConfiguration",
                "org.eclipse.jetty.plus.webapp.PlusConfiguration",
                "org.eclipse.jetty.annotations.AnnotationConfiguration",
                "org.eclipse.jetty.webapp.JettyWebXmlConfiguration"
        });

        server.setHandler(context);
        createLifecycleListener();
    }

    private void createLifecycleListener() {
        FilenetClient filenetClient = new FilenetClient(new DataSourceHandler(this.getDatasource()));
        server.addLifeCycleListener(new LifeCycle.Listener() {
            @Override
            public void lifeCycleStarting(LifeCycle event) {

            }

            @Override
            public void lifeCycleStarted(LifeCycle event) {

            }

            @Override
            public void lifeCycleFailure(LifeCycle event, Throwable cause) {

            }

            @Override
            public void lifeCycleStopping(LifeCycle event) {
                filenetClient.removeAllDocuments(DocumentType.values());
            }

            @Override
            public void lifeCycleStopped(LifeCycle event) {

            }
        });
    }

    private void start() throws Exception {
        server.start();
        logger.info("Jetty web server has been started on port {}", port);
    }

    @Override
    public int getPort() {
        return port;
    }

    @Override
    public DataSource getDatasource() {
        return datasource;
    }

    private static JettyServer instance(int port) {
        try {
            JettyServer jetty = new JettyServer(port);
            jetty.start();
            return jetty;
        } catch (Exception e) {
            throw new RuntimeException("Failed to initialize Jetty Web Server instance", e);
        }
    }

}
