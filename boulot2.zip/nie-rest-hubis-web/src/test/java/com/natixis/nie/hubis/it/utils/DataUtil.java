package com.natixis.nie.hubis.it.utils;

import com.natixis.nie.hubis.core.AppProperties;
import com.natixis.nie.hubis.core.Messages;
import com.natixis.nie.hubis.core.SouscriptionService;
import com.natixis.nie.hubis.core.db.*;
import com.natixis.nie.hubis.core.domain.*;
import com.natixis.nie.hubis.core.domain.kbis.Kbis;
import com.natixis.nie.hubis.features.entreprise.kbis.societe.xml.KbisXmlMapper;
import com.natixis.nie.hubis.features.entreprise.web.dto.AdresseDTO;
import com.natixis.nie.hubis.features.entreprise.web.dto.BankDataDTO;
import com.natixis.nie.hubis.features.entreprise.web.dto.DirigeantDTO;
import com.natixis.nie.hubis.features.entreprise.web.dto.EntrepriseDTO;
import com.natixis.nie.hubis.features.simulation.SimulationService;
import com.natixis.nie.hubis.features.simulation.web.dto.*;
import org.assertj.core.util.Files;
import org.mindrot.jbcrypt.BCrypt;

import javax.sql.DataSource;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.time.LocalDate;
import java.time.Month;
import java.util.UUID;

import static com.natixis.nie.hubis.utils.StubbedDatas.nodata;

public class DataUtil {

    public static final AppProperties APP_PROPERTIES = new AppProperties();
    private static final Messages messages = new Messages();

    public static String generateEmail() {
        return "jdoe" + Math.random() + "@gmail.com";
    }

    public static String generateSaltedPassword() {
        return BCrypt.hashpw("test", BCrypt.gensalt());
    }

    public static String getMessage(String key) {
        return messages.get(key);
    }

    public static File createFileWithSize(int size) throws IOException {
        File file = Files.newFile("target/dummy-" + UUID.randomUUID());
        RandomAccessFile f = new RandomAccessFile(file, "rw");
        f.setLength(1024 * 1024 * size);
        return file;
    }

    public static Entreprise createDummyEntreprise() {
        return createDummyEntreprise(createDummyBankData());
    }

    public static Entreprise createDummyEntreprise(BankData bankData) {

        FormeJuridique formeJuridique = new FormeJuridique(1100, "Entrepreneur individuel", true);
        Nace nace = new Nace("2611Z", "Fabrication de composants électroniques", true);
        Adresse adresse = new Adresse("32 rue des Lilas", 75001, "Paris");
        Dirigeant dirigeant = createDummyDirigeant();
        Kbis noKbis = null;
        String noDispositif = null;

        return new Entreprise(new Siret("81456211200015"), "DailyBrian", formeJuridique, nace, adresse, 10, Month.JANUARY, dirigeant, bankData, noKbis, noDispositif);
    }

    public static BankData createDummyBankData() {
        return new BankData("DABAIE2D", "FR1420041010050500013M02606", "0614789542", "BRED");
    }

    public static Dirigeant createDummyDirigeant() {
        Adresse adresse = new Adresse("32 rue des Lilas", 75001, "Paris");
        LocalDate birthDate = LocalDate.of(1982, 4, 26);
        return Dirigeant.newDirigeant("MONSIEUR CLAUDE SENBEL", "Dirigeant", "0645789652", birthDate, adresse, "");
    }

    public static UserDAO createUserDAO(DataSource dataSource) {

        DataSourceHandler dataSourceHandler = new DataSourceHandler(dataSource);
        TransactionManager transactionManager = new TransactionManager(dataSourceHandler);
        EntrepriseDAO entrepriseDAO = new EntrepriseDAO(transactionManager, new KbisXmlMapper(nodata()));
        UploadDAO uploadDAO = new UploadDAO(dataSourceHandler);
        StateDAO stateDAO = new StateDAO(dataSourceHandler);

        SimulationService simulationService = new SimulationService(APP_PROPERTIES);
        SimulationDAO simulationDAO = new SimulationDAO(transactionManager, simulationService);

        DummyGed ged = new DummyGed();
        LazyUserData lazyUserData = new LazyUserData(uploadDAO, simulationDAO, entrepriseDAO, stateDAO, ged);
        return new UserDAO(dataSourceHandler, lazyUserData);
    }

    public static SouscriptionService createSubscriptionManager(DataSource dataSource) {

        DataSourceHandler dataSourceHandler = new DataSourceHandler(dataSource);
        TransactionManager transactionManager = new TransactionManager(dataSourceHandler);
        EntrepriseDAO entrepriseDAO = new EntrepriseDAO(transactionManager, new KbisXmlMapper(nodata()));
        UploadDAO uploadDAO = new UploadDAO(dataSourceHandler);
        StateDAO stateDAO = new StateDAO(dataSourceHandler);

        SimulationService simulationService = new SimulationService(APP_PROPERTIES);
        SimulationDAO simulationDAO = new SimulationDAO(transactionManager, simulationService);

        DummyGed ged = new DummyGed();

        return new SouscriptionService(transactionManager, stateDAO, simulationDAO, entrepriseDAO, uploadDAO, ged);
    }

    public static EntrepriseDTO createDefaultEntrepriseDTO() {

        EntrepriseDTO dto = new EntrepriseDTO();
        dto.setSiret("32052067900020");
        dto.setRaisonSociale("MONSIEUR CLAUDE SENBEL");
        dto.setEffectif(1);
        dto.setMoisDeCloture(12);
        dto.setFormeJuridique(1500);//Affaire personnelle profession libérale
        dto.setNace("8621Z");//Activité des médecins généralistes
        AdresseDTO adresseDTO = new AdresseDTO("11 RUE LEPIC", 75018, "Paris");
        dto.setAdresse(adresseDTO);
        dto.setDirigeant(createDefaultDirigeantDTO(adresseDTO));
        dto.setBankData(createDefaultBankDataDTO());

        return dto;
    }

    public static BankDataDTO createDefaultBankDataDTO() {
        BankDataDTO dto = new BankDataDTO();
        dto.setBic("DABAIE2D");
        dto.setIban("FR1420041010050500013M02606");
        dto.setTelephone("0645789541");
        dto.setAgence("BRED");
        return dto;
    }

    public static DirigeantDTO createDefaultDirigeantDTO(AdresseDTO adresseDTO) {
        DirigeantDTO dirigeantDTO = new DirigeantDTO();
        dirigeantDTO.setFullname("MONSIEUR CLAUDE SENBEL");
        dirigeantDTO.setFonction("Dirigeant");
        dirigeantDTO.setTelephone("0645789652");
        dirigeantDTO.setDatenaiss(LocalDate.of(1982, 4, 26));
        dirigeantDTO.setAdresse(adresseDTO);
        return dirigeantDTO;
    }

    public static SignupDTO createDefaultSignupDTO() {
        return new SignupDTO(new NewUserDTO(generateEmail(), "Hubis123"), createDefaultContratDTO());
    }

    public static NewSimulationDTO createDefaultContratDTO() {
        return new NewSimulationDTO(new SimulationCriteriaDTO(), createDefaultCartDTO());
    }

    public static CartDTO createDefaultCartDTO() {
        CartDTO dto = new CartDTO();
        dto.setChosenCesuVersement(1000);
        dto.setChosenEpargneVersement(3500);
        return dto;
    }
}
