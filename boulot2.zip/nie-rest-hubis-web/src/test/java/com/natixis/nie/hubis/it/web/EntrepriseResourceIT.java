package com.natixis.nie.hubis.it.web;

import com.natixis.nie.hubis.features.entreprise.web.dto.*;
import com.natixis.nie.hubis.features.user.dto.UserDTO;
import com.natixis.nie.hubis.it.utils.IntegrationTestBase;
import com.natixis.nie.hubis.web.Errors;
import com.natixis.nie.hubis.web.dto.StateDTO;
import org.junit.Test;

import java.time.LocalDate;
import java.util.Map;

import static com.natixis.nie.hubis.core.domain.State.ENTREPRISE;
import static com.natixis.nie.hubis.core.domain.State.SIGNATURE;
import static com.natixis.nie.hubis.it.utils.DataUtil.*;
import static com.natixis.nie.hubis.it.utils.RestClient.IS_OK;
import static com.natixis.nie.hubis.web.Errors.Type.INVALID_PARAMS;
import static org.assertj.core.api.Assertions.assertThat;

public class EntrepriseResourceIT extends IntegrationTestBase {

    @Test
    public void canSaveEntrepriseWithKbis() throws Exception {

        client
                .signupAndLog(createDefaultSignupDTO())
                .postEntreprise(createDefaultEntrepriseDTO(), IS_OK, response -> {
                    StateDTO dto = client.asPojo(response.body(), StateDTO.class);
                    assertThat(dto.getName()).isEqualTo(ENTREPRISE);
                    assertThat(dto.getName().allowedStates()).contains(SIGNATURE);
                })
                .getUserDatas(response -> {
                    assertThat(response.code()).isEqualTo(200);
                    UserDTO dto = client.asPojo(response.body(), UserDTO.class);
                    EntrepriseDTO entreprise = dto.getEntreprise();
                    assertThat(entreprise.getSiret()).isEqualTo("32052067900020");
                    DirigeantDTO dirigeant = entreprise.getDirigeant();
                    assertThat(dirigeant.getFullname()).isEqualTo("MONSIEUR CLAUDE SENBEL");
                    assertThat(dirigeant.getFonction()).isEqualTo("Dirigeant");
                    assertThat(dirigeant.getDatenaiss()).isEqualTo(LocalDate.of(1982, 4, 26));
                    assertThat(dirigeant.getTelephone()).isEqualTo("0645789652");
                    assertThat(dirigeant.getAdresse().getRue()).isEqualTo("11 RUE LEPIC");
                    assertThat(entreprise.getBankData().getTelephone()).isEqualTo("0645789541");
                    assertThat(entreprise.getBankData().getAgence()).isEqualTo("BRED");
                    assertThat(entreprise.getBankData().getIban()).isEqualTo("FR14200**010**0500013M0****");
                });
    }

    @Test
    public void canSaveEntrepriseWithCustomDirigeantAdresse() throws Exception {

        EntrepriseDTO entrepriseDTO = createDefaultEntrepriseDTO();
        entrepriseDTO.getDirigeant().setAdresse(new AdresseDTO("rue des lilas", 75001, "Paris"));

        client
                .signupAndLog(createDefaultSignupDTO())
                .postEntreprise(entrepriseDTO, IS_OK, response -> {
                    StateDTO dto = client.asPojo(response.body(), StateDTO.class);
                    assertThat(dto.getName()).isEqualTo(ENTREPRISE);
                    assertThat(dto.getName().allowedStates()).contains(SIGNATURE);
                })
                .getUserDatas(response -> {
                    assertThat(response.code()).isEqualTo(200);
                    UserDTO dto = client.asPojo(response.body(), UserDTO.class);
                    DirigeantDTO dirigeant = dto.getEntreprise().getDirigeant();
                    assertThat(dirigeant.getAdresse().getRue()).isEqualTo("rue des lilas");
                });
    }

    @Test
    public void canSaveTwoEntrepriseForTwoUsers() throws Exception {

        client
                .signupAndLog(createDefaultSignupDTO())
                .postEntreprise(createDefaultEntrepriseDTO(), IS_OK)
                .logout();

        client
                .signupAndLog(createDefaultSignupDTO())
                .postEntreprise(createDefaultEntrepriseDTO(), IS_OK)
                .logout();
    }

    @Test
    public void canSaveEntrepriseWithoutKbisOnFetchingError() throws Exception {

        EntrepriseDTO entrepriseDTO = createEntrepriseDTOLeadingToFetchingError();

        client
                .signupAndLog(createDefaultSignupDTO())
                .postEntreprise(entrepriseDTO)
                .getUserDatas(response -> {
                    assertThat(response.code()).isEqualTo(200);
                    UserDTO dto = client.asPojo(response.body(), UserDTO.class);
                    EntrepriseDTO entreprise = dto.getEntreprise();
                    assertThat(entreprise.getSiret()).isEqualTo("81456211200015");
                    assertThat(entreprise.getDirigeant().getFullname()).isEqualTo("MONSIEUR CLAUDE SENBEL");
                    assertThat(entreprise.getDirigeant().getFonction()).isEqualTo("Dirigeant");
                });
    }

    @Test
    public void canUpdateEntrepriseWithEncryptedIban() throws Exception {

        EntrepriseDTO entrepriseDTO = createDefaultEntrepriseDTO();
        EntrepriseDTO entrepriseWithoutIbanDTO = createDefaultEntrepriseDTO();
        entrepriseWithoutIbanDTO.getBankData().setIban(null);

        client
                .signupAndLog(createDefaultSignupDTO())
                .postEntreprise(entrepriseDTO)
                .postEntreprise(entrepriseWithoutIbanDTO, IS_OK);
    }

    @Test
    public void shouldSerializeBirthDateWithCustomPattern() throws Exception {

        EntrepriseDTO entrepriseDTO = createDefaultEntrepriseDTO();
        entrepriseDTO.getDirigeant().setDatenaiss(LocalDate.of(1982, 3, 6));

        client
                .signupAndLog(createDefaultSignupDTO())
                .postEntreprise(entrepriseDTO)
                .getUserDatas(response -> {
                    assertThat(response.code()).isEqualTo(200);
                    Map dto = client.asPojo(response.body(), Map.class);
                    Map entreprise = (Map) dto.get("entreprise");
                    assertThat(((Map) entreprise.get("dirigeant")).get("datenaiss")).isEqualTo("1982-03-06");
                });
    }

    @Test
    public void cannotSaveEntrepriseWithUnknownKbis() throws Exception {

        EntrepriseDTO dto = createDefaultEntrepriseDTO();
        dto.setSiret("00000000000000");
        client
                .signupAndLog(createDefaultSignupDTO())
                .postEntreprise(dto, response -> {
                    assertThat(response.code()).isEqualTo(400);
                    Errors errors = client.asPojo(response.body(), Errors.class);
                    assertThat(errors.getMessages().get(0)).isEqualTo(getMessage("kbis.errors.invalid"));
                });
    }

    @Test
    public void cannotSaveEntrepriseWhenDirigeantHasntAddress() throws Exception {

        EntrepriseDTO dto = createDefaultEntrepriseDTO();
        dto.getDirigeant().setAdresse(null);

        client
                .signupAndLog(createDefaultSignupDTO())
                .postEntreprise(dto, response -> {
                    assertThat(response.code()).isEqualTo(400);
                    Errors errors = client.asPojo(response.body(), Errors.class);
                    assertThat(errors.getType()).isEqualTo(INVALID_PARAMS);
                });
    }

    @Test
    public void cannotSaveEntrepriseWothInvalidBIC() throws Exception {

        EntrepriseDTO dto = createDefaultEntrepriseDTO();
        dto.getBankData().setBic("dfffffff");

        client
                .signupAndLog(createDefaultSignupDTO())
                .postEntreprise(dto, response -> {
                    assertThat(response.code()).isEqualTo(400);
                    Errors errors = client.asPojo(response.body(), Errors.class);
                    assertThat(errors.getType()).isEqualTo(INVALID_PARAMS);
                    assertThat(errors.getMessages().get(0)).contains("Le BIC n'est pas valide");
                });
    }

    @Test
    public void cannotSaveInvalidEntreprise() throws Exception {

        EntrepriseDTO dto = createDefaultEntrepriseDTO();
        dto.setNace(null);

        client
                .signupAndLog(createDefaultSignupDTO())
                .postEntreprise(dto, response -> {
                    assertThat(response.code()).isEqualTo(400);
                    Errors errors = client.asPojo(response.body(), Errors.class);
                    assertThat(errors.getMessages()).isNotEmpty();
                });
    }

    @Test
    public void canUpdateEntrepriseWhenUserAsAnotherState() throws Exception {

        EntrepriseDTO dto = createDefaultEntrepriseDTO();

        client
                .signupAndLog(createDefaultSignupDTO())
                .postEntreprise(dto, IS_OK, response -> {
                    StateDTO state = client.asPojo(response.body(), StateDTO.class);
                    assertThat(state.getName()).isEqualTo(ENTREPRISE);
                })
                .postEntreprise(dto, IS_OK);
    }

    @Test
    public void canGetAPreloadedKbis() throws Exception {

        client
                .signupAndLog(createDefaultSignupDTO())
                .preloadEntreprise("32052067900020", response -> {

                    assertThat(response.code()).isEqualTo(200);
                    KbisDTO dto = client.asPojo(response.body(), KbisDTO.class);

                    EntrepriseInfosDTO entreprise = dto.getEntreprise();
                    assertThat(entreprise.getSiret()).isEqualTo("32052067900020");
                    assertThat(entreprise.getDirigeant().getFullname()).isEqualTo("MONSIEUR CLAUDE SENBEL");
                    assertThat(entreprise.getDirigeant().getFonction()).isEqualTo("Dirigeant");
                    assertThat(dto.getDirigeants()).isEmpty();
                });
    }

    @Test
    public void canGetAPreloadedKbisWithMultipleDirigeants() throws Exception {

        client
                .signupAndLog(createDefaultSignupDTO())
                .preloadEntreprise("56200034902188", response -> {

                    assertThat(response.code()).isEqualTo(200);
                    KbisDTO dto = client.asPojo(response.body(), KbisDTO.class);

                    assertThat(dto.getDirigeants()).hasSize(12);
                });
    }

    @Test
    public void shouldSendBackAnErrorWhenSiretIsUnknown() throws Exception {

        client
                .signupAndLog(createDefaultSignupDTO())
                .preloadEntreprise("00000000000000", response -> {

                    assertThat(response.code()).isEqualTo(400);
                    Errors errors = client.asPojo(response.body(), Errors.class);
                    assertThat(errors.getMessages().get(0)).isEqualTo(getMessage("kbis.errors.invalid"));
                });
    }

    @Test
    public void shouldSendBackAnErrorOnTechnicalErrorDuringPrealoading() throws Exception {

        client
                .signupAndLog(createDefaultSignupDTO())
                .preloadEntreprise("81456211200015", response -> {

                    assertThat(response.code()).isEqualTo(500);
                    Errors errors = client.asPojo(response.body(), Errors.class);
                    assertThat(errors.getMessages().get(0)).isEqualTo(getMessage("kbis.errors.technical"));
                });
    }

    private EntrepriseDTO createEntrepriseDTOLeadingToFetchingError() {
        EntrepriseDTO dto = createDefaultEntrepriseDTO();
        dto.setSiret("81456211200015");
        return dto;
    }

}
