package com.natixis.nie.hubis.features.simulation;

import com.natixis.nie.hubis.core.AppProperties;
import com.natixis.nie.hubis.core.domain.simulation.*;
import org.assertj.core.api.SoftAssertions;
import org.junit.Before;
import org.junit.Test;

import static com.natixis.nie.hubis.core.domain.simulation.SimulationCriteria.dirigeantSalarieWithoutSalarie;
import static com.natixis.nie.hubis.core.domain.simulation.SimulationCriteria.tnsWithoutSalarie;
import static org.assertj.core.api.Assertions.assertThat;


public class EpargneTest {

    private SimulationsDatas datas;
    private SimulationService service;

    @Before
    public void setUp() throws Exception {
        AppProperties appProperties = new AppProperties();
        datas = new SimulationsDatas.Builder(appProperties).build();
        service = new SimulationService(appProperties);
    }

    @Test
    public void whenAmountIsTooSmallShouldUseOnlyPEI() throws Exception {

        SimulationCriteria tns = tnsWithoutSalarie(datas);

        SimulationItems simulationItems = service.generateItems(tns);

        assertThat(simulationItems.getEpargnes().get(0).getAbondementNet()).isEqualTo(2682);
    }

    @Test
    public void whenAmountIsTooBigShouldsePEIandPERCO() throws Exception {

        SimulationCriteria tns = tnsWithoutSalarie(datas);

        SimulationItems simulationItems = service.generateItems(tns);

        assertThat(simulationItems.getEpargnes().get(2).getAbondementNet()).isEqualTo(5056);
    }

    @Test
    public void mustComputeVmaxItem() throws Exception {

        SimulationCriteria tns = tnsWithoutSalarie(datas);

        SimulationItems simulationItems = service.generateItems(tns);

        Epargne epargne = simulationItems.getEpargnes().get(5);
        SoftAssertions soft = new SoftAssertions();
        soft.assertThat(epargne.getVersement()).isEqualTo(10874);
        soft.assertThat(epargne.getAbondementBrut()).isEqualTo(9267);
        soft.assertThat(epargne.getForfaitSocial()).isEqualTo(1606);
        soft.assertAll();
    }

    @Test
    public void mustComputeEpargneValuesForTNS() throws Exception {

        SimulationCriteria tns = tnsWithoutSalarie(datas);

        SimulationItems simulationItems = service.generateItems(tns);

        Epargne epargne = simulationItems.getEpargnes().get(0);
        SoftAssertions soft = new SoftAssertions();
        soft.assertThat(epargne.getAbondementBrut()).isEqualTo(2916);
        soft.assertThat(epargne.getForfaitSocial()).isEqualTo(583);
        soft.assertThat(epargne.getAbondementNet()).isEqualTo(2682);
        soft.assertThat(epargne.getCotisationSociales()).isEqualTo(234);
        soft.assertAll();
    }

    @Test
    public void mustComputeEpargnantValuesForTNS() throws Exception {

        SimulationCriteria tns = tnsWithoutSalarie(datas);

        SimulationItems simulationItems = service.generateItems(tns);

        Epargne epargne = simulationItems.getEpargnes().get(0);
        SoftAssertions soft = new SoftAssertions();
        Epargnant epargnant = epargne.getEpargnant();
        soft.assertThat(epargnant.getVersementMensuel()).isEqualTo(81);
        soft.assertThat(epargnant.getVersementAnnuel()).isEqualTo(972);
        soft.assertAll();
    }

    @Test
    public void mustComputeRemunerationValuesForTNS() throws Exception {

        SimulationCriteria tns = tnsWithoutSalarie(datas);

        SimulationItems simulationItems = service.generateItems(tns);

        Epargne epargne = simulationItems.getEpargnes().get(0);
        SoftAssertions soft = new SoftAssertions();
        Remuneration remuneration = epargne.getEpargnant().getRemuneration();
        soft.assertThat(remuneration.getMontantNet()).isEqualTo(1536);
        soft.assertAll();
    }

    @Test
    public void mustComputeEpargneValuesForDirigeant() throws Exception {

        SimulationCriteria dirigeant = dirigeantSalarieWithoutSalarie(datas);

        SimulationItems simulationItems = service.generateItems(dirigeant);

        Epargne epargne = simulationItems.getEpargnes().get(3);
        SoftAssertions soft = new SoftAssertions();
        soft.assertThat(epargne.getAbondementBrut()).isEqualTo(6790);
        soft.assertThat(epargne.getForfaitSocial()).isEqualTo(1209);
        soft.assertThat(epargne.getAbondementNet()).isEqualTo(6246);
        soft.assertThat(epargne.getCotisationSociales()).isEqualTo(544);
        soft.assertAll();
    }

    @Test
    public void mustComputeEpargnantValuesForDirigeant() throws Exception {

        SimulationCriteria dirigeant = dirigeantSalarieWithoutSalarie(datas);

        SimulationItems simulationItems = service.generateItems(dirigeant);

        Epargne epargne = simulationItems.getEpargnes().get(3);
        SoftAssertions soft = new SoftAssertions();
        Epargnant epargnant = epargne.getEpargnant();
        soft.assertThat(epargnant.getVersementMensuel()).isEqualTo(188);
        soft.assertThat(epargnant.getVersementAnnuel()).isEqualTo(2263);
        soft.assertAll();
    }

    @Test
    public void mustComputeRemunerationValuesForDirigeant() throws Exception {

        SimulationCriteria dirigeant = dirigeantSalarieWithoutSalarie(datas);

        SimulationItems simulationItems = service.generateItems(dirigeant);

        Epargne epargne = simulationItems.getEpargnes().get(3);
        SoftAssertions soft = new SoftAssertions();
        Remuneration remuneration = epargne.getEpargnant().getRemuneration();
        soft.assertThat(remuneration.getMontantNet()).isEqualTo(2842);
        soft.assertThat(remuneration.getChargesPatronales()).isEqualTo(2366);
        soft.assertThat(remuneration.getChargesSociales()).isEqualTo(1239);
        soft.assertThat(remuneration.getCsgCrds()).isEqualTo(442);
        soft.assertThat(remuneration.getImpotsRevenu()).isEqualTo(1110);
        soft.assertAll();
    }
}