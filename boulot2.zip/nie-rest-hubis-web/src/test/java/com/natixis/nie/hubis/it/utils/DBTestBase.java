package com.natixis.nie.hubis.it.utils;

import org.apache.commons.dbcp.BasicDataSource;
import org.junit.BeforeClass;

public class DBTestBase {

    protected static BasicDataSource dataSource;

    @BeforeClass
    public static void prepare() throws Exception {
        dataSource = DBUtil.createDatasource();
    }
}
