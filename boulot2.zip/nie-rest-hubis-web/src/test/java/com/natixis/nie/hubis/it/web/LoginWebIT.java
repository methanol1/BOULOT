package com.natixis.nie.hubis.it.web;

import com.natixis.nie.hubis.features.simulation.web.dto.SignupDTO;
import com.natixis.nie.hubis.features.user.dto.RawCredentialsDTO;
import com.natixis.nie.hubis.it.utils.IntegrationTestBase;
import com.natixis.nie.hubis.web.Errors;
import com.natixis.nie.hubis.web.dto.StateDTO;
import org.junit.Test;

import static com.natixis.nie.hubis.core.domain.State.SIMULATION;
import static com.natixis.nie.hubis.it.utils.DataUtil.createDefaultSignupDTO;
import static com.natixis.nie.hubis.it.utils.DataUtil.getMessage;
import static com.natixis.nie.hubis.it.utils.RestClient.IS_BAD;
import static com.natixis.nie.hubis.web.Errors.Type.LOCKED;
import static org.assertj.core.api.Assertions.assertThat;

public class LoginWebIT extends IntegrationTestBase {

    @Test
    public void canLoginWithValidCredentials() throws Exception {

        SignupDTO signupDTO = createDefaultSignupDTO();
        client
                .signup(signupDTO)
                .login(signupDTO.asRawCredentialsDTO(), response -> {
                    assertThat(response.code()).isEqualTo(200);
                    StateDTO dto = client.asPojo(response.body(), StateDTO.class);
                    assertThat(dto.getName()).isEqualTo(SIMULATION);

                    assertThat(client.getCookies()).extracting("name").contains("JSESSIONID");
                    assertThat(client.getCookies()).extracting("value").doesNotContainNull();
                });
    }

    @Test
    public void canNotLoginWithAnInvalidUser() throws Exception {
        client.login(new RawCredentialsDTO("unknown", "admin"), response -> {
            assertThat(response.code()).isEqualTo(400);
        });
    }

    @Test
    public void canNotLoginWithAnInvalidPassword() throws Exception {
        SignupDTO dto = createDefaultSignupDTO();
        client
                .signup(dto)
                .login(new RawCredentialsDTO(dto.getNewUser().getEmail(), "INVALID"), response -> {
                    assertThat(response.code()).isEqualTo(400);
                });
    }

    @Test
    public void shouldLockAccountWhen3LoginAttemptsFail() throws Exception {
        SignupDTO dto = createDefaultSignupDTO();
        client
                .signup(dto)
                .login(new RawCredentialsDTO(dto.getNewUser().getEmail(), "INVALID"), IS_BAD)
                .login(new RawCredentialsDTO(dto.getNewUser().getEmail(), "INVALID"), IS_BAD)
                .login(new RawCredentialsDTO(dto.getNewUser().getEmail(), "INVALID"), IS_BAD)
                .login(new RawCredentialsDTO(dto.getNewUser().getEmail(), "INVALID"), response -> {
                    assertThat(response.code()).isEqualTo(403);
                    Errors errors = client.asPojo(response.body(), Errors.class);
                    assertThat(errors.getType()).isEqualTo(LOCKED);
                    assertThat(errors.getMessages().get(0)).isEqualTo(getMessage("auth.errors.account.locked"));
                });
    }

    @Test
    public void canLogoutWhenAuthenticated() throws Exception {

        client
                .signupAndLog(createDefaultSignupDTO())
                .logout()
                .pingAuth(response -> {
                    assertThat(response.code()).isEqualTo(401);
                });
    }

    @Test
    public void canNotAccessResourcesWithoutBeingAuthenticatd() throws Exception {

        client.pingAuth(response -> {
            assertThat(response.code()).isEqualTo(401);
            Errors errors = client.asPojo(response.body(), Errors.class);
            assertThat(errors.getMessages().get(0)).isEqualTo(getMessage("auth.invalid.session"));
        });
    }

}
