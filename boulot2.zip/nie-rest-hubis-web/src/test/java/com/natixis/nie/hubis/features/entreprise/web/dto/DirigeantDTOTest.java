package com.natixis.nie.hubis.features.entreprise.web.dto;

import com.natixis.nie.hubis.it.utils.DataUtil;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class DirigeantDTOTest {

    private DirigeantDTO dto;

    @Before
    public void setUp() throws Exception {
        AdresseDTO adresseDTO = new AdresseDTO("11 RUE LEPIC", 75018, "Paris");
        dto = DataUtil.createDefaultDirigeantDTO(adresseDTO);
    }

    @Test
    public void shouldAcceptMobilePhoneNumber() throws Exception {

        BankDataDTO dto = DataUtil.createDefaultBankDataDTO();
        dto.setTelephone("0648759421");

        assertThat(dto.isValid()).isTrue();
    }

    @Test
    public void shouldAcceptNewMobilePhoneNumber() throws Exception {

        BankDataDTO dto = DataUtil.createDefaultBankDataDTO();
        dto.setTelephone("0748759421");

        assertThat(dto.isValid()).isTrue();
    }

    @Test
    public void shouldRejectPhoneNumberWithChar() throws Exception {

        dto.setTelephone("X148759421");
        assertThat(dto.isValid()).isFalse();
    }

    @Test
    public void shouldRejectInvalidPhoneNumber() throws Exception {

        dto.setTelephone("00148759421");
        assertThat(dto.isValid()).isFalse();
    }

    @Test
    public void shouldRejectWiredPhoneNumber() throws Exception {

        dto.setTelephone("0148759421");
        assertThat(dto.isValid()).isFalse();
    }

}