package com.natixis.nie.hubis.features.entreprise.kbis;

import com.natixis.nie.hubis.core.KbisMapper;
import com.natixis.nie.hubis.core.domain.FormeJuridique;
import com.natixis.nie.hubis.core.domain.Nace;
import com.natixis.nie.hubis.core.domain.Siret;
import com.natixis.nie.hubis.core.domain.kbis.EntrepriseInfos;
import com.natixis.nie.hubis.core.domain.kbis.Kbis;
import com.natixis.nie.hubis.features.entreprise.kbis.societe.ClasspathKbisFetcher;
import com.natixis.nie.hubis.features.entreprise.kbis.societe.xml.KbisXmlMapper;
import com.natixis.nie.hubis.utils.StubbedDatas;
import org.junit.Ignore;
import org.junit.Test;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.fail;

@Ignore
public class KbisResolverTest {

    @Test
    public void shouldResolveSiretIntoEntreprise() throws Exception {

        FormeJuridique formeJuridique = new FormeJuridique(1, "Affaire personnelle profession libérale", true);
        Nace nace = new Nace("8621Z", "Activité des médecins généralistes", true);
        KbisFetcher fetcher = new ClasspathKbisFetcher(createMapper(formeJuridique, nace));

        Optional<Kbis> kbis = fetcher.fetch(new Siret("320520679"));

        EntrepriseInfos infos = kbis.get().getEntreprise();
        assertThat(kbis.get().getDirigeants()).isEmpty();
        assertThat(infos.getSiret().asString()).isEqualTo("32052067900020");
        assertThat(infos.getDirigeantInfos().getFullname()).isEqualTo("MONSIEUR CLAUDE SENBEL");
        assertThat(infos.getDirigeantInfos().getFonction()).isEqualTo("Dirigeant");
        assertThat(infos.getRaisonSociale()).isEqualTo("MONSIEUR CLAUDE SENBEL");
        assertThat(infos.getAdresse().getRue()).isEqualTo("11 RUE LEPIC");
        assertThat(infos.getAdresse().getCodePostal()).isEqualTo(75018);
        assertThat(infos.getAdresse().getVille()).isEqualTo("PARIS");
        assertThat(infos.getNace().getCode()).isEqualTo("8621Z");
        assertThat(infos.getNace().getLabel()).isEqualTo("Activité des médecins généralistes");
        assertThat(infos.getFormeJuridique().getId()).isEqualTo(1);
        assertThat(infos.getFormeJuridique().getLabel()).isEqualTo("Affaire personnelle profession libérale");
    }

    @Test
    public void shouldResolveSiretWithMultipleDirigeantsIntoEntreprise() throws Exception {

        FormeJuridique formeJuridique = new FormeJuridique(1, "SA à conseil d'administration", true);
        Nace nace = new Nace("7022Z", "Conseil pour les affaires et autres conseils de gestion", true);
        KbisFetcher fetcher = new ClasspathKbisFetcher(createMapper(formeJuridique, nace));

        Optional<Kbis> kbis = fetcher.fetch(new Siret("562000349"));

        EntrepriseInfos infos = kbis.get().getEntreprise();
        assertThat(kbis.get().getDirigeants()).isNotEmpty();
        assertThat(kbis.get().getDirigeants().get(2).getFullname()).isEqualTo("MME IRISSON Marina");
        assertThat(infos.getSiret().asString()).isEqualTo("56200034902188");
        assertThat(infos.getDirigeantInfos().getFullname()).isEqualTo("M KEITA Dessouffiana");
        assertThat(infos.getDirigeantInfos().getFonction()).isEqualTo("Président du conseil d'administration");
    }

    @Test
    public void shouldUseDefaultWordingWhenASingleDirigeant() throws Exception {

        FormeJuridique formeJuridique = new FormeJuridique(1, "Affaire personnelle profession libérale", true);
        Nace nace = new Nace("8621Z", "Activité des médecins généralistes", true);
        KbisFetcher fetcher = new ClasspathKbisFetcher(createMapper(formeJuridique, nace));

        Optional<Kbis> kbis = fetcher.fetch(new Siret("320520679"));

        assertThat(kbis.get().getEntreprise().getDirigeantInfos().getFonction()).isEqualTo("Dirigeant");
    }

    @Test
    public void shouldAllowKbisToBeConvertedIntoXml() throws Exception {

        FormeJuridique formeJuridique = new FormeJuridique(1, "Affaire personnelle profession libérale", true);
        Nace nace = new Nace("8621Z", "Activité des médecins généralistes", true);
        KbisFetcher fetcher = new ClasspathKbisFetcher(createMapper(formeJuridique, nace));

        Optional<Kbis> kbis = fetcher.fetch(new Siret("320520679"));

        assertThat(kbis.get().asXml()).isNotNull();
    }

    @Test
    public void shouldReturnEmptyWhenNoResultFound() throws Exception {

        FormeJuridique formeJuridique = new FormeJuridique(1, "Affaire personnelle profession libérale", true);
        Nace nace = new Nace("8621Z", "Activité des médecins généralistes", true);
        KbisFetcher fetcher = new ClasspathKbisFetcher(createMapper(formeJuridique, nace));

        Optional<Kbis> kbis = fetcher.fetch(new Siret("00000000000000"));

        assertThat(kbis.isPresent()).isFalse();
    }

    @Test
    public void shouldThrowExceptionWhenFetcherFails() throws Exception {

        FormeJuridique formeJuridique = new FormeJuridique(1, "Affaire personnelle profession libérale", true);
        Nace nace = new Nace("8621Z", "Activité des médecins généralistes", true);
        KbisFetcher fetcher = new ClasspathKbisFetcher(createMapper(formeJuridique, nace));

        try {
            fetcher.fetch(new Siret("00000000000000"));
            fail();
        } catch (KbisException e) {
        }
    }

    private KbisMapper createMapper(FormeJuridique formeJuridique, Nace nace) {
        return new KbisXmlMapper(new StubbedDatas(formeJuridique, nace));
    }


}