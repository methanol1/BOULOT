package com.natixis.nie.hubis.core;

import org.junit.Test;

import java.util.Properties;

import static org.assertj.core.api.Assertions.assertThat;

public class AppPropertiesTest {

    @Test
    public void shouldDetectDevEnv() throws Exception {

        assertThat(new AppProperties().isLocal()).isTrue();
    }

    @Test
    public void shouldDetectTestEnv() throws Exception {

        Properties properties = new Properties();
        properties.put("app.env", "test");

        AppProperties prodProperties = new AppProperties(properties);

        assertThat(prodProperties.isLocal()).isTrue();
        assertThat(prodProperties.isTest()).isTrue();
    }

    @Test
    public void shouldDetectProdEnv() throws Exception {

        Properties properties = new Properties();
        properties.put("app.env", "prod");

        AppProperties prodProperties = new AppProperties(properties);

        assertThat(prodProperties.isLocal()).isFalse();
    }

    @Test
    public void shouldOverrideOtherPropertiesWithSystemOnes() throws Exception {

        Properties defaults = new Properties();
        defaults.put("societe.api.proxy.port", "8080");
        Properties xldeploy = new Properties();
        xldeploy.put("societe.api.proxy.port", "9090");
        Properties env = new Properties();
        env.put("societe.api.proxy.port", "3000");

        AppProperties prodProperties = new AppProperties(defaults, xldeploy, env);

        assertThat(prodProperties.get("societe.api.proxy.port")).isEqualTo("3000");
    }

    @Test
    public void shouldOverrideDefaultPropertiesWithXLDeployOnes() throws Exception {

        Properties defaults = new Properties();
        defaults.put("societe.api.proxy.port", "8080");
        Properties xldeploy = new Properties();
        xldeploy.put("societe.api.proxy.port", "9090");

        AppProperties prodProperties = new AppProperties(defaults, xldeploy, new Properties());

        assertThat(prodProperties.get("societe.api.proxy.port")).isEqualTo("9090");
    }

    @Test
    public void shouldIgnoreXLDeployPropertiesWithMustache() throws Exception {

        Properties defaults = new Properties();
        defaults.put("societe.api.proxy.port", "8080");

        Properties xldeploy = new Properties();
        xldeploy.put("societe.api.proxy.port", "{{PORT}}");

        AppProperties prodProperties = new AppProperties(defaults, xldeploy, new Properties());

        assertThat(prodProperties.get("societe.api.proxy.port")).isEqualTo("8080");
    }
}