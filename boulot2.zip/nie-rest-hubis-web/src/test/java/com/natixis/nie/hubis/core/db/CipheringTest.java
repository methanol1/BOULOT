package com.natixis.nie.hubis.core.db;

import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class CipheringTest {

    @Test
    public void setUp() throws Exception {

        Ciphering ciphering = new Ciphering();

        byte[] cipher = ciphering.encrypt("test");
        String decrypted = ciphering.decrypt(cipher);

        assertThat(decrypted).isEqualTo("test");

    }
}