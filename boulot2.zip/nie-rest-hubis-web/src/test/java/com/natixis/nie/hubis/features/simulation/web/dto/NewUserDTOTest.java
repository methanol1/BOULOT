package com.natixis.nie.hubis.features.simulation.web.dto;

import com.natixis.nie.hubis.web.validation.Validation;
import org.junit.Test;

import javax.validation.ConstraintViolation;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

public class NewUserDTOTest {

    @Test
    public void isNotValidWhenPasswordHasNoUpperCaseLetter() throws Exception {

        NewUserDTO dto = new NewUserDTO("admin@gmail", minLengthPwd() + "123");

        assertThat(dto.isValid()).isFalse();
    }

    @Test
    public void isNotValidWhenPasswordHasOnlyOneNumber() throws Exception {

        NewUserDTO dto = new NewUserDTO("admin@gmail", minLengthPwd().toUpperCase() + "1");

        assertThat(dto.isValid()).isFalse();
    }

    @Test
    public void isNotValidWhenPasswordHasOnlyUppercaseLetter() throws Exception {

        NewUserDTO dto = new NewUserDTO("admin@gmail", minLengthPwd().toUpperCase() + "A");

        assertThat(dto.isValid()).isFalse();
    }

    @Test
    public void isValidWhenPasswordHasTwoNumbersAndAnUpperCaseLetter() throws Exception {

        NewUserDTO dto = new NewUserDTO("admin@gmail", minLengthPwd() + "12A");

        assertThat(dto.isValid()).isTrue();
    }

    @Test
    public void mustHaveAtLeast8MinCharacters() throws Exception {

        NewUserDTO dto = new NewUserDTO("admin@gmail", "123A");

        assertThat(dto.isValid()).isFalse();
    }

    @Test
    public void whenNoValidShouldAddMessage() throws Exception {

        NewUserDTO dto = new NewUserDTO("admin@gmail", "123A");

        Set<ConstraintViolation<NewUserDTO>> violations = Validation.validator.validate(dto);
        assertThat(violations).isNotEmpty();
        assertThat(violations.iterator().next().getMessage()).contains("Password does not match security constraints");

    }

    private String minLengthPwd() {
        return "aaaaaaaa";
    }
}