package com.natixis.nie.hubis.it.utils.server;


import com.natixis.nie.hubis.it.utils.DBUtil;

import javax.sql.DataSource;

public class JBossServer implements WebServer {

    public static JBossServer instance = instance(8080);

    private final int port;

    private JBossServer(int port) {
        this.port = port;
    }

    @Override
    public DataSource getDatasource() {
        return DBUtil.createOracleDataSource();
    }

    @Override
    public int getPort() {
        return port;
    }

    private static JBossServer instance(int port) {
        try {
            return new JBossServer(port);
        } catch (Exception e) {
            throw new RuntimeException("Failed to initialize Jetty Web Server instance", e);
        }
    }

}
