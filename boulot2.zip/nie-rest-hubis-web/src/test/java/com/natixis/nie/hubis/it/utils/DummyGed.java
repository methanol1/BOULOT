package com.natixis.nie.hubis.it.utils;


import com.natixis.nie.hubis.core.Ged;
import com.natixis.nie.hubis.core.domain.Document;
import com.natixis.nie.hubis.core.domain.DocumentMetadatas;

import static com.google.common.collect.Lists.newArrayList;

public class DummyGed implements Ged {


    public static final String ID = "{7B70D302-F5F9-426D-A931-6DE5BADAF396}";

    @Override
    public void save(Document... documents) {

        newArrayList(documents).stream().forEach(document -> {
            document.setId(ID);
        });
    }

    @Override
    public Document get(DocumentMetadatas metadatas) {
        return null;
    }
}
