package com.natixis.nie.hubis.it;


import com.natixis.nie.hubis.core.SouscriptionService;
import com.natixis.nie.hubis.core.db.UserDAO;
import com.natixis.nie.hubis.core.domain.State;
import com.natixis.nie.hubis.core.domain.User;
import com.natixis.nie.hubis.it.utils.DBTestBase;
import com.natixis.nie.hubis.it.utils.DataUtil;
import org.junit.Before;
import org.junit.Test;

import static com.natixis.nie.hubis.it.utils.DataUtil.*;
import static org.assertj.core.api.Assertions.assertThat;

public class StateIT extends DBTestBase {

    private UserDAO userDAO;
    private SouscriptionService souscriptionService;

    @Before
    public void setUp() throws Exception {
        userDAO = DataUtil.createUserDAO(dataSource);
        souscriptionService = createSubscriptionManager(dataSource);
    }

    @Test
    public void canResolveStateWhenUserAsDoNothing() throws Exception {

        User user = userDAO.create(generateEmail(), generateSaltedPassword());

        State state = user.getCurrentState();

        assertThat(state).isEqualTo(State.SIMULATION);
    }

    @Test
    public void canResolveStateWhenUserAsFilledInEntrepriseDatas() throws Exception {

        User user = userDAO.create(generateEmail(), generateSaltedPassword());

        State state = souscriptionService.createEntreprise(user, createDummyEntreprise());

        assertThat(state).isEqualTo(State.ENTREPRISE);
    }
}
