package com.natixis.nie.hubis.features.simulation.web.validation;

import com.natixis.nie.hubis.features.simulation.web.dto.CartDTO;
import com.natixis.nie.hubis.web.validation.Validation;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;


public class CartValidatorTest {

    @Test
    public void shouldRejectEmptyCart() throws Exception {

        assertThat(Validation.hasErros(new CartDTO())).isTrue();
    }

    @Test
    public void shouldAllowCartWithCesu() throws Exception {

        CartDTO dto = new CartDTO();
        dto.setChosenCesuVersement(1);

        assertThat(Validation.hasErros(dto)).isFalse();
    }

    @Test
    public void shouldAllowCartWithEpargne() throws Exception {

        CartDTO dto = new CartDTO();
        dto.setChosenEpargneVersement(1);

        assertThat(Validation.hasErros(dto)).isFalse();
    }
}