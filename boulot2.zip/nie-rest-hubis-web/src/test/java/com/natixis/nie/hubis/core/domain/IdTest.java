package com.natixis.nie.hubis.core.domain;

import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;


public class IdTest {

    @Test
    public void canConvertIdIntoString() throws Exception {
        assertThat(new Id(1).asString()).isEqualTo("1");
    }

    @Test
    public void canConvertIdIntoInt() throws Exception {
        assertThat(new Id(1).asInt()).isEqualTo(1);
    }
}