package com.natixis.nie.hubis.it.web;

import com.natixis.nie.hubis.core.domain.SignatureTransaction;
import com.natixis.nie.hubis.it.utils.EditiqueClient;
import com.natixis.nie.hubis.it.utils.IntegrationTestBase;
import com.natixis.nie.hubis.it.utils.ResponseBodyCaptor;
import com.natixis.nie.hubis.web.dto.StateDTO;
import org.junit.BeforeClass;
import org.junit.Test;

import static com.natixis.nie.hubis.core.domain.State.SIGNATURE;
import static com.natixis.nie.hubis.it.utils.DataUtil.createDefaultEntrepriseDTO;
import static com.natixis.nie.hubis.it.utils.DataUtil.createDefaultSignupDTO;
import static com.natixis.nie.hubis.it.utils.RestClient.IS_FORBIDDEN;
import static com.natixis.nie.hubis.it.utils.RestClient.IS_OK;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assume.assumeTrue;

public class SignatureResourceIT extends IntegrationTestBase {

    @BeforeClass
    public static void assumeFilenetCanBeReached() throws Exception {
        EditiqueClient editiqueClient = new EditiqueClient();
        assumeTrue(editiqueClient.canPingEditique());
    }

    @Test
    public void canCreateTransaction() throws Exception {

        client
                .signupAndLog(createDefaultSignupDTO())
                .postEntreprise(createDefaultEntrepriseDTO())
                .createTransaction(response -> {
                    assertThat(response.code()).isEqualTo(200);
                    SignatureTransaction transaction = client.asPojo(response.body(), SignatureTransaction.class);
                    assertThat(transaction.getAccessId()).isNotNull();
                    assertThat(transaction.getTransactionId()).isNotNull();
                });
    }

    @Test
    public void canFinishTransaction() throws Exception {

        ResponseBodyCaptor<SignatureTransaction> captor = new ResponseBodyCaptor<>();
        client
                .signupAndLog(createDefaultSignupDTO())
                .postEntreprise(createDefaultEntrepriseDTO())
                .createTransaction(response -> {
                    captor.set(client.asPojo(response.body(), SignatureTransaction.class));
                })
                .finishTransaction(captor.get(), response -> {
                    assertThat(response.code()).isEqualTo(200);
                    StateDTO state = client.asPojo(response.body(), StateDTO.class);
                    assertThat(state.getName()).isEqualTo(SIGNATURE);
                });
    }

    @Test
    public void shouldSendEmailWhenUserHasSignContract() throws Exception {

        ResponseBodyCaptor<SignatureTransaction> captor = new ResponseBodyCaptor<>();
        client
                .signupAndLog(createDefaultSignupDTO())
                .postEntreprise(createDefaultEntrepriseDTO())
                .createTransaction(response -> {
                    captor.set(client.asPojo(response.body(), SignatureTransaction.class));
                })
                .finishTransaction(captor.get(), IS_OK);

        assertThat(mailServer.getLastEmailContent()).contains("Plafond d'abondement");
    }

    @Test
    public void cannotGoBackToEntrepriseWhenContratHasBeenSigned() throws Exception {

        ResponseBodyCaptor<SignatureTransaction> captor = new ResponseBodyCaptor<>();
        client
                .signupAndLog(createDefaultSignupDTO())
                .postEntreprise(createDefaultEntrepriseDTO())
                .createTransaction(response -> {
                    captor.set(client.asPojo(response.body(), SignatureTransaction.class));
                })
                .finishTransaction(captor.get(), IS_OK)
                .postEntreprise(createDefaultEntrepriseDTO(), response -> {
                    assertThat(response.code()).isEqualTo(403);
                });
    }

    @Test
    public void canCancelTransaction() throws Exception {

        ResponseBodyCaptor<SignatureTransaction> captor = new ResponseBodyCaptor<>();
        client
                .signupAndLog(createDefaultSignupDTO())
                .postEntreprise(createDefaultEntrepriseDTO())
                .createTransaction(response -> {
                    captor.set(client.asPojo(response.body(), SignatureTransaction.class));
                })
                .cancelTransaction(captor.get(), response -> {
                    assertThat(response.code()).isEqualTo(200);
                    StateDTO state = client.asPojo(response.body(), StateDTO.class);
                    assertThat(state.getName()).isEqualTo(SIGNATURE);
                });
    }

    @Test
    public void cannotSignBeforeCreatingEntreprise() throws Exception {

        client
                .signupAndLog(createDefaultSignupDTO())
                .createTransaction(IS_FORBIDDEN);
    }


}
