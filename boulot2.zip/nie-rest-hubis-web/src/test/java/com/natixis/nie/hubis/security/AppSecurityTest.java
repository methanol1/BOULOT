package com.natixis.nie.hubis.security;

import com.natixis.nie.hubis.core.Messages;
import com.natixis.nie.hubis.core.db.UserDAO;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.fail;

public class AppSecurityTest {

    private AppSecurity appSecurity;

    @Before
    public void setUp() throws Exception {
        appSecurity = new AppSecurity(Mockito.mock(UserDAO.class), new Messages());
    }

    @Test
    public void shouldHashPasswordAsModularCryptFormat() {

        String salted = appSecurity.hashPassword("password");

        assertThat(salted).startsWith("$2a$10");//bcrypt MCF identifier + rounds
    }

    @Test
    public void shouldFailWhenPasswordIsNull() {

        try {
            appSecurity.hashPassword(null);
            fail();
        } catch (IllegalArgumentException e) {
        }

    }

}