package com.natixis.nie.hubis.it.web;

import com.natixis.nie.hubis.core.db.DataSourceHandler;
import com.natixis.nie.hubis.features.user.dto.UserDTO;
import com.natixis.nie.hubis.it.utils.DataUtil;
import com.natixis.nie.hubis.it.utils.FilenetClient;
import com.natixis.nie.hubis.it.utils.IntegrationTestBase;
import com.natixis.nie.hubis.it.utils.RestClient.FormPart;
import com.natixis.nie.hubis.web.Errors;
import com.natixis.nie.hubis.web.dto.StateDTO;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import org.assertj.core.util.Files;
import org.junit.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;

import java.io.File;
import java.net.SocketException;

import static com.natixis.nie.hubis.core.domain.DocumentType.*;
import static com.natixis.nie.hubis.core.domain.State.UPLOAD;
import static com.natixis.nie.hubis.it.utils.DataUtil.createDefaultEntrepriseDTO;
import static com.natixis.nie.hubis.it.utils.DataUtil.createDefaultSignupDTO;
import static com.natixis.nie.hubis.it.utils.RestClient.IS_FORBIDDEN;
import static com.natixis.nie.hubis.it.utils.RestClient.IS_UNAUTHORIZED;
import static com.natixis.nie.hubis.web.Errors.Type.INVALID_CONTENT;
import static com.natixis.nie.hubis.web.Errors.Type.MISSING_FILES;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.util.Lists.newArrayList;
import static org.junit.Assume.assumeTrue;

public class UploadResourceIT extends IntegrationTestBase {

    private final static Logger logger = LoggerFactory.getLogger(UploadResourceIT.class);
    private static FilenetClient filenetClient;

    private File fakeBigPng;
    private FormPart identity_recto;
    private FormPart identity_verso;
    private FormPart invoice;
    private FormPart secu;
    private FormPart engagement;

    @BeforeClass
    public static void configureFilenetClient() throws Exception {
        filenetClient = new FilenetClient(new DataSourceHandler(getWebServer().getDatasource()));
        assumeTrue(filenetClient.canPingFilenet());
    }

    @Before
    public void setUp() throws Exception {
        File png = new ClassPathResource("upload/linux.png").getFile();
        identity_recto = pngPart("identity_recto", png);
        identity_verso = pngPart("identity_verso", png);
        invoice = pngPart("invoice", png);
        secu = new FormPart("secu", "secu", RequestBody.create(MediaType.parse("text/plain"), "182047512020560"));
        engagement = new FormPart("engagement", "engagement", RequestBody.create(MediaType.parse("text/plain"), "true"));
    }

    @After
    public void cleanAll() throws Exception {
        if (fakeBigPng != null && fakeBigPng.exists()) {
            Files.delete(fakeBigPng);
        }
    }

    @Test
    public void canUploadPngFiles() throws Exception {

        client
                .signupAndLog(createDefaultSignupDTO())
                .postEntreprise(createDefaultEntrepriseDTO())
                .signConvention()
                .upload(newArrayList(identity_recto, identity_verso, invoice, secu, engagement), response -> {
                    assertThat(response.code()).isEqualTo(200);
                    StateDTO state = client.asPojo(response.body(), StateDTO.class);
                    assertThat(state.getName()).isEqualTo(UPLOAD);

                })
                .getUserDatas(response -> {
                    UserDTO dto = client.asPojo(response.body(), UserDTO.class);
                    Integer entrepriseId = dto.getEntreprise().getId();
                    assertThat(filenetClient.getUploadedDocument(entrepriseId, IDENTITY_RECTO).getGedId()).isNotNull();
                    assertThat(filenetClient.getUploadedDocument(entrepriseId, IDENTITY_VERSO).getGedId()).isNotNull();
                    assertThat(filenetClient.getUploadedDocument(entrepriseId, INVOICE).getGedId()).isNotNull();
                });
    }

    @Test
    public void canUploadPdfFiles() throws Exception {

        File pdf = new ClassPathResource("upload/api-pro-societe.com.pdf").getFile();
        FormPart passport = pdfPart("identity_recto", pdf);
        FormPart invoice = pdfPart("invoice", pdf);

        client
                .signupAndLog(createDefaultSignupDTO())
                .postEntreprise(createDefaultEntrepriseDTO())
                .signConvention()
                .upload(newArrayList(passport, invoice, secu, engagement), response -> {
                    assertThat(response.code()).isEqualTo(200);
                    StateDTO state = client.asPojo(response.body(), StateDTO.class);
                    assertThat(state.getName()).isEqualTo(UPLOAD);
                })
                .getUserDatas(response -> {
                    UserDTO dto = client.asPojo(response.body(), UserDTO.class);
                    Integer entrepriseId = dto.getEntreprise().getId();
                    assertThat(filenetClient.getUploadedDocument(entrepriseId, IDENTITY_RECTO).getGedId()).isNotNull();
                    assertThat(filenetClient.getUploadedDocument(entrepriseId, INVOICE).getGedId()).isNotNull();
                });
    }

    @Test
    public void cannotUploadABigFile() throws Exception {

        fakeBigPng = DataUtil.createFileWithSize(21);
        FormPart bigPart = pngPart("identity_recto", fakeBigPng);

        client
                .signupAndLog(createDefaultSignupDTO())
                .postEntreprise(createDefaultEntrepriseDTO())
                .signConvention()
                .upload(newArrayList(bigPart, identity_verso, invoice, secu, engagement), response -> {
                    assertThat(response.code()).isEqualTo(400);
                    Errors errors = client.asPojo(response.body(), Errors.class);
                    assertThat(errors.getType()).isEqualTo(INVALID_CONTENT);
                });
    }

    @Test
    public void cannotUploadWhenNotLogged() throws Exception {
        try {
            client.upload(newArrayList(identity_recto, identity_verso, invoice, engagement), IS_UNAUTHORIZED);
        } catch (SocketException e) {
            logger.warn("Shiro seems to close connection for a multipart request", e);
        }
    }

    @Test
    public void cannotUploadBeforeSign() throws Exception {

        client
                .signupAndLog(createDefaultSignupDTO())
                .postEntreprise(createDefaultEntrepriseDTO())
                .upload(newArrayList(identity_recto, identity_verso, invoice), IS_FORBIDDEN);
    }

    @Test
    public void cannotUploadASingleFile() throws Exception {

        client
                .signupAndLog(createDefaultSignupDTO())
                .postEntreprise(createDefaultEntrepriseDTO())
                .signConvention()
                .upload(newArrayList(identity_recto, engagement), response -> {
                    assertThat(response.code()).isEqualTo(400);
                    Errors errors = client.asPojo(response.body(), Errors.class);
                    assertThat(errors.getType()).isEqualTo(MISSING_FILES);
                });
    }

    private FormPart pngPart(String name, File file) {
        return new FormPart(name, name + ".png", RequestBody.create(MediaType.parse("image/png"), file));
    }

    private FormPart pdfPart(String name, File file) {
        return new FormPart(name, name + ".pdf", RequestBody.create(MediaType.parse("image/png"), file));
    }

}
