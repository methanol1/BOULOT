package com.natixis.nie.hubis.features.simulation;

import com.natixis.nie.hubis.core.AppProperties;
import com.natixis.nie.hubis.core.domain.simulation.Cesu;
import com.natixis.nie.hubis.core.domain.simulation.SimulationsDatas;
import org.assertj.core.api.SoftAssertions;
import org.junit.Before;
import org.junit.Test;

import static com.natixis.nie.hubis.core.domain.simulation.SimulationCriteria.*;
import static org.assertj.core.api.Assertions.assertThat;


public class CesuTest {

    private SimulationsDatas datas;
    private SimulationService service;

    @Before
    public void setUp() throws Exception {
        AppProperties appProperties = new AppProperties();
        datas = new SimulationsDatas.Builder(appProperties).build();
        service = new SimulationService(appProperties);
    }

    @Test
    public void cesuForTNSWithoutSalarie() throws Exception {

        SimulationItems simulationItems = service.generateItems(tnsWithoutSalarie(datas));

        Cesu cesu = simulationItems.getCesus().get(0);
        SoftAssertions soft = new SoftAssertions();
        soft.assertThat(cesu.getVersement()).isEqualTo(1000);
        soft.assertThat(cesu.getRemuneration().getMontantNet()).isEqualTo(440);
        soft.assertAll();
    }

    @Test
    public void creditImpotForTNSWithoutSalarie() throws Exception {

        SimulationItems simulationItems = service.generateItems(tnsWithoutSalarie(datas));

        Cesu cesu = simulationItems.getCesus().get(0);
        assertThat(cesu.getCreditImpot()).isEqualTo(0);
    }

    @Test
    public void creditImpotForTNSWithSalarie() throws Exception {

        SimulationItems simulationItems = service.generateItems(tnsWithSalarie(datas));

        Cesu cesu = simulationItems.getCesus().get(0);
        assertThat(cesu.getCreditImpot()).isEqualTo(250);
    }

    @Test
    public void cesuForDirigeant() throws Exception {

        SimulationItems simulationItems = service.generateItems(dirigeantSalarieWithoutSalarie(datas));

        Cesu cesu = simulationItems.getCesus().get(0);
        SoftAssertions soft = new SoftAssertions();
        soft.assertThat(cesu.getVersement()).isEqualTo(1000);
        soft.assertThat(cesu.getRemuneration().getMontantNet()).isEqualTo(356);
        soft.assertAll();
    }

    @Test
    public void creditImpotForDirigeantWithoutSalarie() throws Exception {

        SimulationItems simulationItems = service.generateItems(dirigeantSalarieWithoutSalarie(datas));

        Cesu cesu = simulationItems.getCesus().get(0);

        assertThat(cesu.getCreditImpot()).isEqualTo(0);
    }

    @Test
    public void creditImpotForDirigeantWithSalarie() throws Exception {

        SimulationItems simulationItems = service.generateItems(dirigeantSalarieWithSalarie(datas));

        Cesu cesu = simulationItems.getCesus().get(0);

        assertThat(cesu.getCreditImpot()).isEqualTo(250);
    }
}
