package com.natixis.nie.hubis.features.entreprise.web.dto;

import com.natixis.nie.hubis.core.domain.Entreprise;
import com.natixis.nie.hubis.core.domain.FormeJuridique;
import com.natixis.nie.hubis.core.domain.Nace;
import com.natixis.nie.hubis.it.utils.DataUtil;
import com.natixis.nie.hubis.utils.StubbedDatas;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;


public class EntrepriseDTOTest {

    @Test
    public void shouldNotSetEntrepriseId() throws Exception {

        EntrepriseDTO dto = DataUtil.createDefaultEntrepriseDTO();
        FormeJuridique formeJuridique = new FormeJuridique(1500, "Affaire personnelle profession libérale", true);
        Nace nace = new Nace("8621Z", "Activité des médecins généralistes", true);
        StubbedDatas datas = new StubbedDatas(formeJuridique, nace);

        Entreprise entreprise = dto.toModel(datas);

        assertThat(entreprise.getId().isPresent()).isFalse();
    }

    @Test
    public void entrepriseWithLessThan250SalarisSouldBeInvalid() throws Exception {

        EntrepriseDTO dto = DataUtil.createDefaultEntrepriseDTO();
        dto.setEffectif(100);

        assertThat(dto.isValid()).isTrue();
    }

    @Test
    public void entrepriseWithMoreThan250SalarisSouldBeInvalid() throws Exception {

        EntrepriseDTO dto = DataUtil.createDefaultEntrepriseDTO();
        dto.setEffectif(300);

        assertThat(dto.isValid()).isFalse();
    }
}