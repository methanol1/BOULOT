package com.natixis.nie.hubis.core.domain;


import org.junit.Test;

import static com.natixis.nie.hubis.core.domain.State.*;
import static org.assertj.core.api.Assertions.assertThat;

public class StateTest {

    @Test
    public void shouldComputeNextState() throws Exception {
        assertThat(SIGNATURE.nextState()).isEqualTo(UPLOAD);
        assertThat(ENTREPRISE.nextState()).isEqualTo(SIGNATURE);
    }

    @Test
    public void whenSouscriptionTerminatedShouldStayOnLastState() throws Exception {
        assertThat(VERSEMENT.nextState()).isEqualTo(VERSEMENT);
    }

    @Test
    public void shouldComputeAllowedStateForFirstState() throws Exception {
        assertThat(SIMULATION.allowedStates()).containsOnly(SIMULATION, RECAPITULATIF);
    }

    @Test
    public void shouldComputeAllowedState() throws Exception {
        assertThat(RECAPITULATIF.allowedStates()).containsOnly(SIMULATION, RECAPITULATIF, ENTREPRISE);
        assertThat(ENTREPRISE.allowedStates()).containsOnly(SIMULATION, RECAPITULATIF, ENTREPRISE, SIGNATURE);
    }

    @Test
    public void shouldComputeAllowedStateForNextOnlyState() throws Exception {
        assertThat(SIGNATURE.allowedStates()).containsOnly(SIGNATURE, UPLOAD);
        assertThat(UPLOAD.allowedStates()).containsOnly(UPLOAD, VERSEMENT);
        assertThat(VERSEMENT.allowedStates()).containsOnly(VERSEMENT);
    }
}
