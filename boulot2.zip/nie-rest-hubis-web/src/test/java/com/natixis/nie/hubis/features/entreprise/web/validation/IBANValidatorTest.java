package com.natixis.nie.hubis.features.entreprise.web.validation;

import com.natixis.nie.hubis.web.validation.Validation;
import org.junit.Test;

import javax.validation.constraints.NotNull;

import static org.assertj.core.api.Assertions.assertThat;


public class IBANValidatorTest {

    @Test
    public void shouldAcceptValidIBAN() throws Exception {

        MyIban myIban = new MyIban("FR1420041010050500013M02606");//last value

        assertThat(Validation.hasErros(myIban)).isFalse();
    }

    @Test
    public void shouldAcceptLowerCaseValidIBAN() throws Exception {

        MyIban myIban = new MyIban("fr1420041010050500013M02606");//last value

        assertThat(Validation.hasErros(myIban)).isFalse();
    }

    @Test
    public void shouldRejectValidIBANWithSpaces() throws Exception {

        MyIban myIban = new MyIban("FR14200410 10050500013M02606");//last value

        assertThat(Validation.hasErros(myIban)).isTrue();
    }

    @Test
    public void shouldRejectIBANWithInvalidChecksum() throws Exception {

        MyIban myIban = new MyIban("FR1420041010050500013M02608");//last value

        assertThat(Validation.hasErros(myIban)).isTrue();
    }

    @Test
    public void shouldRejectInvalidValue() throws Exception {

        MyIban myIban = new MyIban("invalid");

        assertThat(Validation.hasErros(myIban)).isTrue();
    }

    private static class MyIban {
        @NotNull
        @IBAN
        private String iban;

        public MyIban(String iban) {
            this.iban = iban;
        }
    }
}