package com.natixis.nie.hubis.it.web;

import com.natixis.nie.hubis.features.simulation.web.dto.*;
import com.natixis.nie.hubis.features.user.dto.RawCredentialsDTO;
import com.natixis.nie.hubis.features.user.dto.UserDTO;
import com.natixis.nie.hubis.it.utils.IntegrationTestBase;
import com.natixis.nie.hubis.web.dto.StateDTO;
import org.assertj.core.api.SoftAssertions;
import org.junit.Test;

import static com.natixis.nie.hubis.core.domain.State.SIMULATION;
import static com.natixis.nie.hubis.it.utils.DataUtil.createDefaultCartDTO;
import static com.natixis.nie.hubis.it.utils.DataUtil.generateEmail;
import static org.assertj.core.api.Assertions.assertThat;

public class SimulationResourceIT extends IntegrationTestBase {

    @Test
    public void canLoadItems() throws Exception {

        SimulationCriteriaDTO tns = new SimulationCriteriaDTO(false, false);

        client.getSimulationItems(tns, response -> {
            assertThat(response.code()).isEqualTo(200);

            SimulationItemsDTO dto = client.asPojo(response.body(), SimulationItemsDTO.class);
            assertThat(dto.getEpargneAvailableVersements()).isNotEmpty();

            SoftAssertions soft = new SoftAssertions();
            EpargneDTO epargneDTO = dto.getEpargneAvailableVersements().get(0);
            soft.assertThat(epargneDTO.getVersement()).isEqualTo(3500);
            soft.assertThat(epargneDTO.getForfaitSocial()).isEqualTo(583);
            soft.assertThat(epargneDTO.getAbondementBrut()).isEqualTo(2916);
            soft.assertThat(epargneDTO.getAbondementNet()).isEqualTo(2682);
            soft.assertThat(epargneDTO.getCotisationsSociales()).isEqualTo(234);

            EpargnantDTO epargnantDTO = epargneDTO.getEpargnant();
            soft.assertThat(epargnantDTO.getVersementAnnuel()).isEqualTo(972);
            soft.assertThat(epargnantDTO.getVersementMensuel()).isEqualTo(81);
            soft.assertThat(epargnantDTO.getRemuneration().getMontantNet()).isEqualTo(1536);
            soft.assertAll();
        });
    }

    @Test
    public void canLoadItemsForDirigeantTNS() throws Exception {

        SimulationCriteriaDTO tns = new SimulationCriteriaDTO(false, false);

        client.getSimulationItems(tns, response -> {
            assertThat(response.code()).isEqualTo(200);
            SimulationItemsDTO dto = client.asPojo(response.body(), SimulationItemsDTO.class);
            assertThat(dto.getEpargneAvailableVersements().get(0).getEpargnant().getRemuneration().getMontantNet()).isEqualTo(1536);
            assertThat(dto.getCesuAvailableVersements().get(0).getRemuneration().getMontantNet()).isEqualTo(440);
        });
    }

    @Test
    public void canLoadItemsForDirigeantSalarie() throws Exception {

        SimulationCriteriaDTO salarié = new SimulationCriteriaDTO(true, true);

        client.getSimulationItems(salarié, response -> {
            assertThat(response.code()).isEqualTo(200);
            SimulationItemsDTO dto = client.asPojo(response.body(), SimulationItemsDTO.class);
            assertThat(dto.getEpargneAvailableVersements().get(0).getEpargnant().getRemuneration().getMontantNet()).isEqualTo(1244);
            assertThat(dto.getCesuAvailableVersements().get(0).getRemuneration().getMontantNet()).isEqualTo(356);
        });
    }

    @Test
    public void canUpdateUserSimulation() throws Exception {

        NewSimulationDTO previousContrat = new NewSimulationDTO(new SimulationCriteriaDTO(true, true), createDefaultCartDTO());
        NewSimulationDTO newContrat = new NewSimulationDTO(new SimulationCriteriaDTO(false, true), createDefaultCartDTO());

        SignupDTO signupDTO = new SignupDTO(new NewUserDTO(generateEmail(), "Hubis123"), previousContrat);
        NewUserDTO newUser = signupDTO.getNewUser();

        client
                .signup(signupDTO)
                .login(new RawCredentialsDTO(newUser.getEmail(), newUser.getPassword()))
                .getUserDatas(response -> {
                    assertThat(response.code()).isEqualTo(200);
                    UserDTO dto = client.asPojo(response.body(), UserDTO.class);
                    assertThat(dto.getSimulation().getSimulationCriteria().isDirigeantSalarie()).isTrue();
                })
                .updateSimulation(newContrat, response -> {
                    assertThat(response.code()).isEqualTo(200);
                    StateDTO state = client.asPojo(response.body(), StateDTO.class);
                    assertThat(state.getName()).isEqualTo(SIMULATION);
                })
                .getUserDatas(response -> {
                    assertThat(response.code()).isEqualTo(200);
                    UserDTO dto = client.asPojo(response.body(), UserDTO.class);
                    assertThat(dto.getSimulation().getSimulationCriteria().isDirigeantSalarie()).isFalse();
                });
    }
}
