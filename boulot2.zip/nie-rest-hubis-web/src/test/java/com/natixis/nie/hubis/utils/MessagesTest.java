package com.natixis.nie.hubis.utils;

import com.natixis.nie.hubis.core.Messages;
import org.assertj.core.api.Assertions;
import org.junit.Test;


public class MessagesTest {

    @Test
    public void shouldAddParametersToMessages() {
        Messages messages = new Messages();

        String result = messages.get("signup.errors.user.exists", "aParameter");

        Assertions.assertThat(result).contains("aParameter");
    }
}