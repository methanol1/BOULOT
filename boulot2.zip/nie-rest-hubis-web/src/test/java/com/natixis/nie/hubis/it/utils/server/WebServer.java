package com.natixis.nie.hubis.it.utils.server;

import javax.sql.DataSource;


public interface WebServer {

    DataSource getDatasource();

    int getPort();
}