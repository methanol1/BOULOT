package com.natixis.nie.hubis.utils;

import com.natixis.nie.hubis.core.Datas;
import com.natixis.nie.hubis.core.domain.FormeJuridique;
import com.natixis.nie.hubis.core.domain.Nace;

import java.util.List;

import static com.google.common.collect.Lists.newArrayList;

public class StubbedDatas implements Datas {

    private final List<FormeJuridique> formes;
    private final List<Nace> naces;

    public StubbedDatas(FormeJuridique forme, Nace nace) {
        this.formes = newArrayList(forme);
        this.naces = newArrayList(nace);
    }

    private StubbedDatas() {
        this.formes = newArrayList();
        this.naces = newArrayList();
    }

    @Override
    public List<FormeJuridique> findAllFormesJuridiques() {
        return formes;
    }

    @Override
    public List<Nace> findAllNaces() {
        return naces;
    }

    public static StubbedDatas nodata() {
        return new StubbedDatas();
    }

    public static StubbedDatas defaultDatas() {
        FormeJuridique formeJuridique = new FormeJuridique(1500, "Affaire personnelle profession libérale", true);
        Nace nace = new Nace("8621Z", "Activité des médecins généralistes", true);
        return new StubbedDatas(formeJuridique, nace);
    }
}