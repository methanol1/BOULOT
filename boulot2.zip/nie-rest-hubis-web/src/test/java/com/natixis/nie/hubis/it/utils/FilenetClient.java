package com.natixis.nie.hubis.it.utils;

import com.natixis.nie.hubis.core.db.DataSourceHandler;
import com.natixis.nie.hubis.core.db.UploadDAO;
import com.natixis.nie.hubis.core.domain.DocumentMetadatas;
import com.natixis.nie.hubis.core.domain.DocumentType;
import com.natixis.nie.hubis.core.domain.Id;
import com.natixis.nie.hubis.features.upload.filenet.GedTemplateFactory;
import com.natixis.sphinx.integration.filenet.ged.GedTemplate;
import com.natixis.sphinx.integration.filenet.ged.session.SessionFactory;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Arrays;


public class FilenetClient {

    private final static Logger logger = LoggerFactory.getLogger(FilenetClient.class);

    private final OkHttpClient client;
    private final GedTemplate gedTemplate;
    private final DataSourceHandler dataSourceHandler;
    private final UploadDAO uploadDAO;

    public FilenetClient(DataSourceHandler dataSourceHandler) {
        this.dataSourceHandler = dataSourceHandler;
        SessionFactory sessionFactory = GedTemplateFactory.createFallbackSessionFactory();
        gedTemplate = new GedTemplate(sessionFactory);
        client = new OkHttpClient.Builder().build();
        uploadDAO = new UploadDAO(dataSourceHandler);
    }

    public boolean canPingFilenet() throws IOException {
        try {
            Request request = new Request.Builder()
                    .url("http://sfb.gedworkplace.dev.intranatixis.com/wsi/FNCEWS40MTOM")
                    .get()
                    .build();

            Response response = client.newCall(request).execute();
            return response.isSuccessful();
        } catch (Exception e) {
            logger.error("Unable to reach filenet server due to " + e.getMessage());
            return false;
        }
    }

    public void removeAllDocuments(DocumentType... types) {

        Arrays.stream(types).forEach(type -> {

            dataSourceHandler.getJdbcTemplate().query(
                    "SELECT FILENET_ID FROM THUBUPLOAD WHERE FILE_TYPE <> ? ", new String[]{type.name()}, (rs, rowNum) -> {
                        return rs.getString("FILENET_ID");
                    })
                    .stream()
                    .forEach(gedId -> {
                        try {
                            gedTemplate.deleteDocument(gedId);
                        } catch (Exception e) {
                            logger.error("Unable to delete document " + gedId, e);
                        }
                    });
        });
    }

    public DocumentMetadatas getUploadedDocument(int entrepriseId, DocumentType documentType) {
        return uploadDAO.getMetadatas(new Id(entrepriseId), documentType);
    }

    public GedTemplate getGedTemplate() {
        return gedTemplate;
    }
}
