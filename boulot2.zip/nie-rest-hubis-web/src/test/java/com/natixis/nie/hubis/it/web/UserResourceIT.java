package com.natixis.nie.hubis.it.web;

import com.natixis.nie.hubis.features.simulation.web.dto.*;
import com.natixis.nie.hubis.features.user.dto.RawCredentialsDTO;
import com.natixis.nie.hubis.features.user.dto.UserDTO;
import com.natixis.nie.hubis.it.utils.IntegrationTestBase;
import org.junit.Test;

import static com.natixis.nie.hubis.it.utils.DataUtil.generateEmail;
import static org.assertj.core.api.Assertions.assertThat;

public class UserResourceIT extends IntegrationTestBase {

    @Test
    public void canGetUserDatas() throws Exception {

        SimulationCriteriaDTO criteria = new SimulationCriteriaDTO(true, true);
        CartDTO epargneAndCesuDTO = new CartDTO();
        epargneAndCesuDTO.setChosenEpargneVersement(5000);
        epargneAndCesuDTO.setChosenCesuVersement(1500);
        SignupDTO signupDTO = new SignupDTO(new NewUserDTO(generateEmail(), "Hubis123"), new NewSimulationDTO(criteria, epargneAndCesuDTO));
        NewUserDTO newUser = signupDTO.getNewUser();

        client
                .signup(signupDTO)
                .login(new RawCredentialsDTO(newUser.getEmail(), newUser.getPassword()))
                .getUserDatas(response -> {
                    assertThat(response.code()).isEqualTo(200);
                    UserDTO dto = client.asPojo(response.body(), UserDTO.class);
                    SimulationDTO simulation = dto.getSimulation();
                    assertThat(simulation.getSimulationCriteria().isDirigeantSalarie()).isTrue();
                    assertThat(simulation.getSimulationCriteria().hasSalaries()).isTrue();
                    assertThat(simulation.getEpargne().getVersement()).isEqualTo(5000);
                    assertThat(simulation.getCesu().getVersement()).isEqualTo(1500);
                    assertThat(simulation.getTotalVersement()).isEqualTo(6500);
                    assertThat(simulation.getOptimizedTotalVersement()).isEqualTo(12704);
                });
    }
}
