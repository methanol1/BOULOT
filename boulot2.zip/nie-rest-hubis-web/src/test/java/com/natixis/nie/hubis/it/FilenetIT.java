package com.natixis.nie.hubis.it;


import com.google.common.collect.Lists;
import com.natixis.nie.hubis.core.AppProperties;
import com.natixis.nie.hubis.core.SouscriptionService;
import com.natixis.nie.hubis.core.db.DataSourceHandler;
import com.natixis.nie.hubis.core.db.UserDAO;
import com.natixis.nie.hubis.core.domain.Document;
import com.natixis.nie.hubis.core.domain.DocumentMetadatas;
import com.natixis.nie.hubis.core.domain.User;
import com.natixis.nie.hubis.features.upload.filenet.FilenetDAO;
import com.natixis.nie.hubis.it.utils.DBTestBase;
import com.natixis.nie.hubis.it.utils.DataUtil;
import com.natixis.nie.hubis.it.utils.FilenetClient;
import com.natixis.sphinx.integration.filenet.ged.GedTemplate;
import org.apache.commons.io.IOUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.core.io.ClassPathResource;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static com.google.common.net.MediaType.PDF;
import static com.natixis.nie.hubis.core.domain.DocumentType.IDENTITY_RECTO;
import static com.natixis.nie.hubis.core.domain.DocumentType.INVOICE;
import static com.natixis.nie.hubis.it.utils.DataUtil.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assume.assumeTrue;

public class FilenetIT extends DBTestBase {

    private static FilenetClient filenetClient;

    private FilenetDAO filenetDAO;
    private GedTemplate gedTemplate;
    private List<String> ids;
    private UserDAO userDAO;
    private SouscriptionService souscriptionService;

    @BeforeClass
    public static void configureFilenetClient() throws Exception {
        filenetClient = new FilenetClient(new DataSourceHandler(dataSource));
        assumeTrue(filenetClient.canPingFilenet());
    }

    @Before
    public void setUp() throws Exception {
        gedTemplate = filenetClient.getGedTemplate();
        filenetDAO = new FilenetDAO(gedTemplate, new AppProperties());
        ids = new ArrayList<>();
        userDAO = DataUtil.createUserDAO(dataSource);
        souscriptionService = createSubscriptionManager(dataSource);
    }

    @Test
    public void shouldInsertDocumentsIntoFilenet() throws Exception {
        User user = userDAO.create(generateEmail(), generateSaltedPassword());
        souscriptionService.createEntreprise(user, createDummyEntreprise());
        byte[] bytes = IOUtils.toByteArray(new ClassPathResource("upload/api-pro-societe.com.pdf").getInputStream());
        Document identity = new Document(IDENTITY_RECTO, bytes, PDF);
        Document invoice = new Document(INVOICE, bytes, PDF);

        filenetDAO.save(identity, invoice);

        ids = extractIds(identity, invoice);
        assertThat(ids).hasSize(2);
        assertThat(filenetDAO.get(new DocumentMetadatas(ids.get(0), IDENTITY_RECTO, PDF)).getFilename()).isEqualTo("identity_recto.pdf");
        assertThat(filenetDAO.get(new DocumentMetadatas(ids.get(0), INVOICE, PDF)).getMediaType()).isEqualTo(PDF);
    }

    private List<String> extractIds(Document identity, Document invoice) {
        return Lists.newArrayList(identity, invoice).stream().map(f -> f.getId().get()).collect(Collectors.toList());
    }
}
