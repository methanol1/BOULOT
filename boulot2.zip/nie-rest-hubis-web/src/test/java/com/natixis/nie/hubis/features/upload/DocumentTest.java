package com.natixis.nie.hubis.features.upload;

import com.google.common.net.MediaType;
import com.natixis.nie.hubis.core.domain.Document;
import org.junit.Test;

import static com.natixis.nie.hubis.core.domain.DocumentType.IDENTITY_RECTO;
import static org.assertj.core.api.Assertions.assertThat;


public class DocumentTest {


    @Test
    public void shouldDetectImagePNG() throws Exception {

        Document document = new Document(IDENTITY_RECTO, new byte[0], MediaType.PNG);

        assertThat(document.isImage()).isTrue();
        assertThat(document.isPDF()).isFalse();

    }

    @Test
    public void shouldDetectImageJPEG() throws Exception {

        Document document = new Document(IDENTITY_RECTO, new byte[0], MediaType.JPEG);

        assertThat(document.isImage()).isTrue();
        assertThat(document.isPDF()).isFalse();
    }

    @Test
    public void shouldDetectPDF() throws Exception {

        Document document = new Document(IDENTITY_RECTO, new byte[0], MediaType.PDF);

        assertThat(document.isPDF()).isTrue();
        assertThat(document.isImage()).isFalse();
    }
}