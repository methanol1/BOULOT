package com.natixis.nie.hubis.it.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natixis.nie.hubis.core.domain.SignatureTransaction;
import com.natixis.nie.hubis.features.entreprise.web.dto.EntrepriseDTO;
import com.natixis.nie.hubis.features.simulation.web.dto.NewSimulationDTO;
import com.natixis.nie.hubis.features.simulation.web.dto.SignupDTO;
import com.natixis.nie.hubis.features.simulation.web.dto.SimulationCriteriaDTO;
import com.natixis.nie.hubis.features.user.dto.ForgottenPasswordDTO;
import com.natixis.nie.hubis.features.user.dto.RawCredentialsDTO;
import com.natixis.nie.hubis.features.user.dto.ResetPasswordDTO;
import com.natixis.nie.hubis.web.Errors;
import com.natixis.nie.hubis.web.JacksonProvider;
import okhttp3.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class RestClient {

    public static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    private final CustomCookieJar cookieJar;
    public final static Assertions IS_OK = response -> {
        assertThat(response.code()).isEqualTo(200);
    };
    public final static Assertions IS_UNAUTHORIZED = response -> {
        assertThat(response.code()).isEqualTo(401);
    };
    public final static Assertions IS_FORBIDDEN = response -> {
        assertThat(response.code()).isEqualTo(403);
    };
    public final static Assertions IS_BAD = response -> {
        assertThat(response.code()).isEqualTo(400);
    };


    private OkHttpClient client;
    private ObjectMapper mapper;
    private String restServiceUrl;

    public RestClient(String restServiceUrl) {
        this.restServiceUrl = restServiceUrl;
        this.mapper = JacksonProvider.MAPPER;
        cookieJar = new CustomCookieJar();
        this.client = new OkHttpClient.Builder()
                .cookieJar(cookieJar)
                .build();
    }

    public RestClient(int port) {
        this("http://localhost:" + port + "/nie-rest-hubis-web/rest/v1");
    }

    public RestClient pingAuth(Assertions assertions) throws Exception {
        Response response = get("/ping/auth");
        assertions.assertAll(response);
        return this;
    }

    public RestClient login(RawCredentialsDTO credentials) throws Exception {
        return login(credentials, IS_OK);
    }

    public RestClient login(RawCredentialsDTO credentials, Assertions assertions) throws Exception {
        Response response = post("/auth/login", credentials);
        assertions.assertAll(response);
        return this;
    }

    public RestClient logout() throws Exception {
        Response response = get("/auth/logout");
        assertThat(response.code()).isEqualTo(200);
        return this;
    }

    public RestClient forgottenPassword(ForgottenPasswordDTO dto, Assertions assertions) throws Exception {
        Response response = post("/auth/forgotten-password", dto);
        assertions.assertAll(response);
        return this;
    }

    public RestClient reset(ResetPasswordDTO dto, Assertions assertions) throws Exception {
        Response response = post("/auth/reset", dto);
        assertions.assertAll(response);
        return this;
    }

    public RestClient reset(ResetPasswordDTO dto) throws Exception {
        return reset(dto, IS_OK);
    }

    public RestClient getAppProperties(Assertions assertions) throws Exception {
        Response response = get("/data/properties/app");
        assertions.assertAll(response);
        return this;
    }

    public RestClient getSignatureProperties(Assertions assertions) throws Exception {
        Response response = get("/data/properties/signature");
        assertions.assertAll(response);
        return this;
    }

    public RestClient getSimulationItems(SimulationCriteriaDTO dto, Assertions assertions) throws Exception {
        Response response = get("/simulation/items?isDirigeantSalarie=" + dto.isDirigeantSalarie());
        assertions.assertAll(response);
        return this;
    }

    public RestClient signup(SignupDTO dto, Assertions assertions) throws Exception {
        Response response = post("/simulation/signup", dto);
        assertions.assertAll(response);
        return this;
    }

    public RestClient signup(SignupDTO dto) throws Exception {
        return signup(dto, IS_OK);
    }

    public RestClient signupAndLog(SignupDTO dto) throws Exception {
        return this.signup(dto).login(dto.asRawCredentialsDTO()).recapitulatif(IS_OK);
    }

    public RestClient updateSimulation(NewSimulationDTO dto, Assertions assertions) throws Exception {
        Response response = put("/simulation", dto);
        assertions.assertAll(response);
        return this;
    }

    public RestClient recapitulatif(Assertions assertions) throws Exception {
        Response response = post("/recapitulatif", new HashMap<>());
        assertions.assertAll(response);
        return this;
    }

    public RestClient getUserDatas(Assertions assertions) throws Exception {
        Response response = get("/user/datas");
        assertions.assertAll(response);
        return this;
    }

    public RestClient preloadEntreprise(String siret, Assertions assertions) throws Exception {
        Response response = get("/entreprise/preload?siret=" + siret);
        assertions.assertAll(response);
        return this;
    }

    public RestClient postEntreprise(EntrepriseDTO dto) throws Exception {
        return postEntreprise(dto, IS_OK);
    }

    public RestClient postEntreprise(EntrepriseDTO dto, Assertions... assertions) throws Exception {
        Response response = post("/entreprise", dto);
        assertAll(assertions, response);
        return this;
    }

    public RestClient signConvention() throws Exception {
        ResponseBodyCaptor<SignatureTransaction> captor = new ResponseBodyCaptor<>();
        this.createTransaction(response -> {
            assertThat(response.code()).isEqualTo(200);
            captor.set(asPojo(response.body(), SignatureTransaction.class));
        }).finishTransaction(captor.get(), IS_OK);
        return this;
    }

    public RestClient createTransaction(Assertions assertions) throws Exception {
        Response response = post("/signature/create", null);//TODO is it the right verb ?
        assertions.assertAll(response);
        return this;
    }

    public RestClient finishTransaction(SignatureTransaction transaction, Assertions assertions) throws Exception {
        Response response = post("/signature/finish?cancel=" + false, transaction);
        assertions.assertAll(response);
        return this;
    }

    public RestClient cancelTransaction(SignatureTransaction transaction, Assertions assertions) throws Exception {
        Response response = post("/signature/finish?cancel=" + true, transaction);
        assertions.assertAll(response);
        return this;
    }

    public RestClient upload(List<FormPart> parts, Assertions assertions) throws Exception {

        MultipartBody.Builder builder = new MultipartBody.Builder().setType(MultipartBody.FORM);
        parts.stream().forEach(p -> builder.addFormDataPart(p.name, p.filename, p.body));

        RequestBody requestBody = builder.build();

        Request request = new Request.Builder()
                .url(restServiceUrl + "/upload")
                .post(requestBody)
                .build();

        Response response = client.newCall(request).execute();

        assertions.assertAll(response);
        return this;
    }

    public RestClient upload(List<FormPart> parts) throws Exception {
        return upload(parts, IS_OK);
    }


    private void assertAll(Assertions[] assertions, Response response) {
        Arrays.stream(assertions).forEach(a -> {
            try {
                a.assertAll(response);
            } catch (Exception e) {
                throw new RuntimeException("Assertions errors", e);
            }
        });
    }

    public Response get(String path) throws Exception {
        Request request = new Request.Builder()
                .url(restServiceUrl + path)
                .get()
                .build();
        return client.newCall(request).execute();
    }

    public <T> T asPojo(ResponseBody body, Class<T> pojoClass) throws Exception {
        return mapper.readValue(body.string(), pojoClass);
    }

    public List<Cookie> getCookies() {
        return cookieJar.loadForRequest(null);//FIXME
    }

    public void assertResponseContainsErrors(Response response) throws Exception {
        Errors errors = asPojo(response.body(), Errors.class);
        assertThat(errors.getMessages()).isNotEmpty();
    }

    private Response post(String path, Object pojo) throws Exception {

        String json = asJson(pojo);
        RequestBody body = RequestBody.create(JSON, json);
        Request request = new Request.Builder()
                .url(restServiceUrl + path)
                .post(body)
                .build();
        return client.newCall(request).execute();
    }

    private Response put(String path, Object pojo) throws Exception {

        String json = asJson(pojo);
        RequestBody body = RequestBody.create(JSON, json);
        Request request = new Request.Builder()
                .url(restServiceUrl + path)
                .put(body)
                .build();
        return client.newCall(request).execute();
    }

    private String asJson(Object pojo) throws JsonProcessingException {
        return mapper.writeValueAsString(pojo);
    }

    private class CustomCookieJar implements CookieJar {

        private List<Cookie> cookies = new ArrayList<>();

        @Override
        public void saveFromResponse(HttpUrl url, List<Cookie> cookiesFromResponse) {
            cookies.clear();
            cookies.addAll(cookiesFromResponse);
        }

        @Override
        public List<Cookie> loadForRequest(HttpUrl url) {
            return cookies;
        }
    }

    @FunctionalInterface
    public interface Assertions {
        void assertAll(Response response) throws Exception;
    }

    public static class FormPart {
        private final String name;
        private final String filename;
        private final RequestBody body;

        public FormPart(String name, String filename, RequestBody body) {
            this.name = name;
            this.filename = filename;
            this.body = body;
        }
    }
}
