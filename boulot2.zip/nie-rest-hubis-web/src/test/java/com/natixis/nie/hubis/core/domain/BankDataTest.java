package com.natixis.nie.hubis.core.domain;

import com.natixis.nie.hubis.it.utils.DataUtil;
import org.assertj.core.api.Assertions;
import org.junit.Test;

public class BankDataTest {

    @Test
    public void shouldMaskIban() throws Exception {
        BankData bankData = DataUtil.createDummyBankData();

        String iban = bankData.getEncryptedIban();

        Assertions.assertThat(iban).isEqualTo("FR14200**010**0500013M0****");

    }
}