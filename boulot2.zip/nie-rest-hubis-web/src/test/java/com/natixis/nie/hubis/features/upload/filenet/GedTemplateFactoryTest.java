package com.natixis.nie.hubis.features.upload.filenet;

import com.natixis.nie.hubis.core.AppProperties;
import com.natixis.nie.hubis.core.exception.AppException;
import org.junit.Before;
import org.junit.Test;

import java.util.Properties;


public class GedTemplateFactoryTest {

    private GedTemplateFactory templateFactory;

    @Before
    public void setUp() throws Exception {

        Properties properties = new Properties();
        properties.put("app.env", "prod");

        AppProperties prodProperties = new AppProperties(properties);

        templateFactory = new GedTemplateFactory(prodProperties);

    }

    @Test(expected = AppException.class)
    public void shouldFailWhenLookupFailsInANonDevEnv() throws Exception {
        templateFactory.createGedTemplate();
    }
}