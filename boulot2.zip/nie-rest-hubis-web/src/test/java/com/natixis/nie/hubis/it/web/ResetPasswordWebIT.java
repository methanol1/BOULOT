package com.natixis.nie.hubis.it.web;

import com.natixis.nie.hubis.features.simulation.web.dto.NewSimulationDTO;
import com.natixis.nie.hubis.features.simulation.web.dto.NewUserDTO;
import com.natixis.nie.hubis.features.simulation.web.dto.SignupDTO;
import com.natixis.nie.hubis.features.simulation.web.dto.SimulationCriteriaDTO;
import com.natixis.nie.hubis.features.user.dto.ForgottenPasswordDTO;
import com.natixis.nie.hubis.features.user.dto.RawCredentialsDTO;
import com.natixis.nie.hubis.features.user.dto.ResetPasswordDTO;
import com.natixis.nie.hubis.it.utils.DataUtil;
import com.natixis.nie.hubis.it.utils.IntegrationTestBase;
import org.junit.Test;

import java.util.UUID;

import static com.natixis.nie.hubis.it.utils.DataUtil.createDefaultCartDTO;
import static com.natixis.nie.hubis.it.utils.DataUtil.createDefaultSignupDTO;
import static com.natixis.nie.hubis.it.utils.RestClient.*;
import static org.assertj.core.api.Assertions.assertThat;

public class ResetPasswordWebIT extends IntegrationTestBase {

    @Test
    public void canResetAForgottenPassword() throws Exception {

        String email = DataUtil.generateEmail();
        String password = "Hubis123";

        NewSimulationDTO newSimulationDTO = new NewSimulationDTO(new SimulationCriteriaDTO(), createDefaultCartDTO());

        client
                .signup(new SignupDTO(new NewUserDTO(email, password), newSimulationDTO))
                .forgottenPassword(new ForgottenPasswordDTO(email), response -> {
                    assertThat(response.code()).isEqualTo(200);
                    ForgottenPasswordDTO request = client.asPojo(response.body(), ForgottenPasswordDTO.class);
                    assertThat(request.getEmail()).isEqualTo(email);
                });


        UUID resetKey = mailServer.extractResetKeyFromEmail();
        String newPassword = "Hubis12345";

        client
                .reset(new ResetPasswordDTO(resetKey.toString(), newPassword, new RawCredentialsDTO(email, newPassword)), IS_OK)
                .login(new RawCredentialsDTO(email, newPassword), IS_OK);

    }

    @Test
    public void canResetAPasswordForLockedAccount() throws Exception {

        SignupDTO dto = createDefaultSignupDTO();
        String email = dto.getNewUser().getEmail();
        client
                .signup(dto)
                .login(new RawCredentialsDTO(email, "INVALID"), IS_BAD)
                .login(new RawCredentialsDTO(email, "INVALID"), IS_BAD)
                .login(new RawCredentialsDTO(email, "INVALID"), IS_BAD)
                .login(new RawCredentialsDTO(email, "INVALID"), IS_FORBIDDEN)
                .forgottenPassword(new ForgottenPasswordDTO(email), IS_OK);

        UUID resetKey = mailServer.extractResetKeyFromEmail();
        String newPassword = "Hubis12345";

        client
                .reset(new ResetPasswordDTO(resetKey.toString(), newPassword, new RawCredentialsDTO(email, newPassword)), IS_OK)
                .login(new RawCredentialsDTO(email, newPassword), IS_OK);
    }


    @Test
    public void cannotRequestAResetWithAnInvalidEmail() throws Exception {

        client
                .signup(createDefaultSignupDTO())
                .forgottenPassword(new ForgottenPasswordDTO("INVALID@gmail.com"), response -> {
                    assertThat(response.code()).isEqualTo(400);
                    client.assertResponseContainsErrors(response);
                });
    }

    @Test
    public void canNotResetPasswordWithAMismatchingPassword() throws Exception {


        SignupDTO signupDTO = createDefaultSignupDTO();
        signupDTO.getNewUser().setPassword("Hubis123");
        String email = signupDTO.getNewUser().getEmail();

        client
                .signup(signupDTO)
                .forgottenPassword(new ForgottenPasswordDTO(email), IS_OK);

        UUID resetKey = mailServer.extractResetKeyFromEmail();

        client
                .reset(new ResetPasswordDTO(resetKey.toString(), "MISMATCH", new RawCredentialsDTO(email, "Hubis12345")), response -> {
                    assertThat(response.code()).isEqualTo(400);
                    client.assertResponseContainsErrors(response);
                });
    }

}
