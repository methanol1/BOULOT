package com.natixis.nie.hubis.it.utils;


import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.init.DatabasePopulatorUtils;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;

import javax.sql.DataSource;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

public class DBUtil {

    public static BasicDataSource createDatasource() {

        if (Objects.equals(System.getProperty("hubis.test.oracle"), "true")) {
            return createOracleDataSource();
        } else {
            BasicDataSource ds = createH2DataSource();
            runH2InitScript(ds);
            return ds;
        }
    }

    public static BasicDataSource createOracleDataSource() {
        BasicDataSource dataSource = new BasicDataSource();
        dataSource.setUrl("jdbc:oracle:thin:@sldora301a:10302/ORAD_TP_EAF");
        dataSource.setDriverClassName("oracle.jdbc.xa.OracleXADataSource");
        dataSource.setUsername("EAFOA_MAJ");
        dataSource.setPassword("H735TE9PUMAJ");
        return dataSource;
    }

    public static BasicDataSource createH2DataSource() {
        BasicDataSource dataSource = new BasicDataSource();
        dataSource.setUrl("jdbc:h2:mem:hubis-test;USER=sa");
        return dataSource;
    }

    private static void runH2InitScript(DataSource ds) {
        ResourceDatabasePopulator populator = new ResourceDatabasePopulator();
        populator.setSqlScriptEncoding(StandardCharsets.UTF_8.name());
        populator.addScript(new ClassPathResource("database/h2.sql"));
        DatabasePopulatorUtils.execute(populator, ds);
    }
}
