package com.natixis.nie.hubis.it.web;

import com.natixis.nie.hubis.it.utils.IntegrationTestBase;
import com.natixis.nie.hubis.web.dto.AppPropertiesDTO;
import com.natixis.nie.hubis.web.dto.SignaturePropertiesDTO;
import org.junit.Test;

import static com.natixis.nie.hubis.it.utils.DataUtil.createDefaultSignupDTO;
import static org.assertj.core.api.Assertions.assertThat;

public class DataResourceIT extends IntegrationTestBase {


    @Test
    public void canGetAppProperties() throws Exception {

        client.getAppProperties(response -> {
            assertThat(response.code()).isEqualTo(200);
            AppPropertiesDTO dto = client.asPojo(response.body(), AppPropertiesDTO.class);
            assertThat(dto.getAppEnv()).isEqualTo("test");
            assertThat(dto.isAuthenticated()).isFalse();
        });
    }

    @Test
    public void canGetAppPropertiesWhenUserIsAuthenticated() throws Exception {

        client
                .signupAndLog(createDefaultSignupDTO())
                .getAppProperties(response -> {
                    assertThat(response.code()).isEqualTo(200);
                    AppPropertiesDTO dto = client.asPojo(response.body(), AppPropertiesDTO.class);
                    assertThat(dto.isAuthenticated()).isTrue();
                });
    }

    @Test
    public void canGetSignatureProperties() throws Exception {

        client.getSignatureProperties(response -> {
            assertThat(response.code()).isEqualTo(200);
            SignaturePropertiesDTO dto = client.asPojo(response.body(), SignaturePropertiesDTO.class);
            assertThat(dto.getIframeUrl()).isNotNull();
        });
    }

}
