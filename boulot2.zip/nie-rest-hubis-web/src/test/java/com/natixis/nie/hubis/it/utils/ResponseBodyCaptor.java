package com.natixis.nie.hubis.it.utils;

public class ResponseBodyCaptor<T> {

    T captured;

    public T get() {
        return captured;
    }

    public void set(T captured) {
        this.captured = captured;
    }
}
