package com.natixis.nie.hubis.it;

import com.natixis.nie.hubis.core.AppProperties;
import com.natixis.nie.hubis.core.CacheFactory;
import com.natixis.nie.hubis.core.Datas;
import com.natixis.nie.hubis.core.db.DataDAO;
import com.natixis.nie.hubis.core.db.DataSourceHandler;
import com.natixis.nie.hubis.core.domain.FormeJuridique;
import com.natixis.nie.hubis.core.domain.Nace;
import com.natixis.nie.hubis.it.utils.DBTestBase;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class DatasRetrievalIT extends DBTestBase {

    private Datas datas;

    @Before
    public void setUp() throws Exception {
        datas = new DataDAO(new DataSourceHandler(dataSource), new CacheFactory(), new AppProperties());
    }

    @Test
    public void canRetrieveAllFormesJuridiques() throws Exception {

        List<FormeJuridique> all = datas.findAllFormesJuridiques();

        assertThat(all).isNotEmpty();
        assertThat(all.get(0).getId()).isEqualTo(1100);
        assertThat(all.get(0).getLabel()).isEqualTo("Affaire personnelle artisan commerçant");
    }

    @Test
    public void canRetrieveAllNaces() throws Exception {

        List<Nace> all = datas.findAllNaces();

        assertThat(all).isNotEmpty();
        assertThat(all.get(0).getCode()).isEqualTo("111Z");
        assertThat(all.get(0).getLabel()).isEqualTo("Culture de céréales (à l'exception du riz), de légumineuses et de graines oléagineuses");
    }
}