package com.natixis.nie.hubis.features.simulation.web.dto;


import com.natixis.nie.hubis.core.domain.simulation.Epargne;

public class EpargneDTO {

    private int versement;
    private int abondementBrut;
    private int forfaitSocial;
    private int abondementNet;
    private int cotisationsSociales;
    private EpargnantDTO epargnant;

    public int getVersement() {
        return versement;
    }

    public void setVersement(int versement) {
        this.versement = versement;
    }

    public int getAbondementBrut() {
        return abondementBrut;
    }

    public void setAbondementBrut(int abondementBrut) {
        this.abondementBrut = abondementBrut;
    }

    public int getForfaitSocial() {
        return forfaitSocial;
    }

    public void setForfaitSocial(int forfaitSocial) {
        this.forfaitSocial = forfaitSocial;
    }

    public EpargnantDTO getEpargnant() {
        return epargnant;
    }

    public void setEpargnant(EpargnantDTO epargnant) {
        this.epargnant = epargnant;
    }

    public int getAbondementNet() {
        return abondementNet;
    }

    public void setAbondementNet(int abondementNet) {
        this.abondementNet = abondementNet;
    }

    public int getCotisationsSociales() {
        return cotisationsSociales;
    }

    public void setCotisationsSociales(int cotisationsSociales) {
        this.cotisationsSociales = cotisationsSociales;
    }

    public static EpargneDTO fromModel(Epargne e) {
        EpargneDTO dto = new EpargneDTO();
        dto.setVersement(e.getVersement());
        dto.setForfaitSocial(e.getForfaitSocial());
        dto.setAbondementBrut(e.getAbondementBrut());
        dto.setEpargnant(EpargnantDTO.fromModel(e.getEpargnant()));
        dto.setAbondementNet(e.getAbondementNet());
        dto.setCotisationsSociales(e.getCotisationSociales());
        return dto;
    }

    @Override
    public String toString() {
        return "EpargneDTO{" +
                "versement=" + versement +
                ", abondementBrut=" + abondementBrut +
                ", forfaitSocial=" + forfaitSocial +
                ", epargnant=" + epargnant +
                '}';
    }
}
