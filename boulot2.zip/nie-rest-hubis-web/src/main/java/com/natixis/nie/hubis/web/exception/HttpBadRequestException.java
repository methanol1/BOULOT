package com.natixis.nie.hubis.web.exception;

import com.natixis.nie.hubis.web.Errors;

import javax.ws.rs.core.Response;

import static javax.ws.rs.core.Response.Status.BAD_REQUEST;

public class HttpBadRequestException extends HttpException {

    public HttpBadRequestException(String message, Errors errors) {
        super(message, errors);
    }

    public HttpBadRequestException(String message, Throwable cause, Errors errors) {
        super(message, cause, errors);
    }

    public Response.Status getStatus() {
        return BAD_REQUEST;
    }
}
