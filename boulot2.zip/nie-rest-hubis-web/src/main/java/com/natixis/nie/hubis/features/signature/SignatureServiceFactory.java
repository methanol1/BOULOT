package com.natixis.nie.hubis.features.signature;

import com.natixis.nie.hubis.core.AppProperties;
import com.natixis.nie.hubis.core.Env;
import com.natixis.nie.hubis.core.SignatureService;
import com.natixis.nie.hubis.features.signature.dictao.SoapSignatureService;

import javax.enterprise.inject.Produces;
import javax.inject.Singleton;

@Singleton
class SignatureServiceFactory {

    @Produces
    @Singleton
    @Env
    public SignatureService create(AppProperties appProperties) {

        if (appProperties.isTest()) {
            return new FakeSignatureService();
        }
        return new SoapSignatureService(appProperties);
    }
}
