package com.natixis.nie.hubis.web.exception;

import com.natixis.nie.hubis.core.exception.AppException;
import com.natixis.nie.hubis.web.Errors;

import javax.ws.rs.core.Response;

public abstract class HttpException extends AppException {

    private final Errors errors;

    public HttpException(String message, Errors errors) {
        super(message);
        this.errors = errors;
    }

    public HttpException(String message, Throwable cause, Errors errors) {
        super(message, cause);
        this.errors = errors;
    }

    public Errors getErrors() {
        return errors;
    }

    public abstract Response.Status getStatus();
}
