package com.natixis.nie.hubis.features.user.dto;


import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.hibernate.validator.constraints.NotEmpty;

public class RawCredentialsDTO {

    @NotEmpty
    private String email;

    @NotEmpty
    private String password;


    @JsonCreator
    public RawCredentialsDTO(@JsonProperty("email") String email, @JsonProperty("password") String password) {
        this.email = email;
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }
}
