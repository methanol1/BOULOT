package com.natixis.nie.hubis.web;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

public class Errors {

    private final Type type;
    private List<String> messages = new ArrayList<>();

    @JsonCreator
    public Errors(@JsonProperty("code") Type type) {
        this.type = type;
    }

    public void add(String message) {
        messages.add(message);
    }

    public List<String> getMessages() {
        return messages;
    }

    public Type getType() {
        return type;
    }

    public static Errors error(Type type, String message) {
        Errors errors = new Errors(type);
        errors.add(message);
        return errors;
    }

    public enum Type {
        INVALID_PARAMS, MISSING_FILES, INVALID_CONTENT, AUTH, INVALID_STATE, UNKNOWN, LOCKED
    }
}
