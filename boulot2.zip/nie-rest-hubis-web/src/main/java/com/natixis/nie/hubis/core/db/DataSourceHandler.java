package com.natixis.nie.hubis.core.db;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import javax.annotation.Resource;
import javax.inject.Singleton;
import javax.sql.DataSource;

@Singleton
public class DataSourceHandler {

    @Resource(name = "jdbc/hubis")
    protected DataSource hubisDS;

    private DataSourceHandler() {
        //Needs by CDI...
    }

    public DataSourceHandler(DataSource ds) {
        this.hubisDS = ds;
    }

    public JdbcTemplate getJdbcTemplate() {
        return new JdbcTemplate(hubisDS);
    }

    public NamedParameterJdbcTemplate getNamedJdbcTemplate() {
        return new NamedParameterJdbcTemplate(hubisDS);
    }

    public DataSource getDataSourceDS() {
        return hubisDS;
    }
}
