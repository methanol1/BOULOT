package com.natixis.nie.hubis.core.domain;

public enum DocumentType {

    IDENTITY_RECTO, IDENTITY_VERSO, PASSPORT, CONVENTION, INVOICE, LIASSE, STATUT;
}
