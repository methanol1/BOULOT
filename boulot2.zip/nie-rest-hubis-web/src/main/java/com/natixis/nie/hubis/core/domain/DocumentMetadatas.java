package com.natixis.nie.hubis.core.domain;


import com.google.common.net.MediaType;

public class DocumentMetadatas {

    private final String gedId;
    private final DocumentType type;
    private final MediaType mediaType;

    public DocumentMetadatas(String gedId, DocumentType type, MediaType mediaType) {
        this.gedId = gedId;
        this.type = type;
        this.mediaType = mediaType;
    }

    public String getGedId() {
        return gedId;
    }

    public DocumentType getType() {
        return type;
    }

    public MediaType getMediaType() {
        return mediaType;
    }

    public Document asDocument(byte[] bytes) {
        return new Document(type, bytes, mediaType);
    }
}
