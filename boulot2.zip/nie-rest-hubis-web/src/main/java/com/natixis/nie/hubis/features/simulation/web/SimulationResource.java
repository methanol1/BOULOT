package com.natixis.nie.hubis.features.simulation.web;

import com.natixis.nie.hubis.core.SouscriptionService;
import com.natixis.nie.hubis.core.db.TransactionManager;
import com.natixis.nie.hubis.core.db.UserDAO;
import com.natixis.nie.hubis.core.domain.State;
import com.natixis.nie.hubis.core.domain.User;
import com.natixis.nie.hubis.core.domain.simulation.Simulation;
import com.natixis.nie.hubis.core.domain.simulation.SimulationCriteria;
import com.natixis.nie.hubis.features.email.EmailService;
import com.natixis.nie.hubis.features.email.WelcomeEmailTemplate;
import com.natixis.nie.hubis.features.simulation.SimulationItems;
import com.natixis.nie.hubis.features.simulation.SimulationService;
import com.natixis.nie.hubis.features.simulation.web.dto.*;
import com.natixis.nie.hubis.web.AbstractRestResource;
import com.natixis.nie.hubis.web.Errors;
import com.natixis.nie.hubis.web.exception.HttpBadRequestException;
import io.swagger.annotations.Api;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;

import static com.natixis.nie.hubis.core.domain.State.SIMULATION;
import static com.natixis.nie.hubis.web.Errors.Type.INVALID_PARAMS;

@Path("/v1/simulation")
@Produces({MediaType.APPLICATION_JSON})
@Consumes(MediaType.APPLICATION_JSON)
@Api(value = "v1-simulation",
        description = "Exposes services to retrieve simulations",
        consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
public class SimulationResource extends AbstractRestResource {

    private final static Logger logger = LoggerFactory.getLogger(SimulationResource.class);

    @Inject
    UserDAO userDAO;

    @Inject
    SimulationService simulationService;

    @Inject
    TransactionManager transactionManager;

    @Inject
    SouscriptionService souscriptionService;

    @Inject
    EmailService emailService;

    @GET
    @Path("/items")
    public Response getSimulationItems(@BeanParam SimulationCriteriaDTO dto) throws IOException {

        SimulationCriteria criteria = dto.toModel(simulationService.getDefaultSimulationsDatas());

        SimulationItems items = simulationService.generateItems(criteria);

        return Response.ok(SimulationItemsDTO.fromModel(items)).build();
    }

    @POST
    @Path("/signup")
    public Response signup(SignupDTO dto) {

        NewUserDTO newUser = dto.getNewUser();
        NewSimulationDTO newSimulationDTO = dto.getSimulation();

        String email = newUser.getEmail();
        if (userDAO.exists(email)) {
            logger.warn("Unable to create a user with email {}", email);
            throw new HttpBadRequestException("Unable to create user with datas " + dto, Errors.error(INVALID_PARAMS, messages.get("signup.errors.user.exists", email)));
        }

        State state = transactionManager.execute(status -> {
            String saltedPassword = appSecurity.hashPassword(newUser.getPassword());
            User newOne = userDAO.create(email, saltedPassword);
            Simulation simulation = NewSimulationDTO.toModel(newSimulationDTO, simulationService);
            return souscriptionService.createSimulation(newOne, simulation);
        });

        emailService.sendEmailAsync(email, new WelcomeEmailTemplate(email, appProperties));

        return sendState(state);
    }

    @PUT
    public Response updateSimulation(NewSimulationDTO dto) {

        User user = appSecurity.getCurrentUserForState(SIMULATION);

        Simulation simulation = NewSimulationDTO.toModel(dto, simulationService);
        State state = souscriptionService.createSimulation(user, simulation);

        return sendState(state);
    }
}
