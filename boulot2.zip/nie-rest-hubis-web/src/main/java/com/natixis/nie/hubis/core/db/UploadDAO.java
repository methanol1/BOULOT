package com.natixis.nie.hubis.core.db;


import com.google.common.net.MediaType;
import com.natixis.nie.hubis.core.domain.DocumentMetadatas;
import com.natixis.nie.hubis.core.domain.DocumentType;
import com.natixis.nie.hubis.core.domain.Id;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class UploadDAO {

    private final static Logger logger = LoggerFactory.getLogger(UploadDAO.class);

    private final DataSourceHandler dataSourceHandler;

    @Inject
    public UploadDAO(DataSourceHandler dataSourceHandler) {
        this.dataSourceHandler = dataSourceHandler;
    }

    public DocumentMetadatas getMetadatas(Id entrepriseId, DocumentType type) {

        return dataSourceHandler.getJdbcTemplate().queryForObject(
                "SELECT * FROM THUBENTREPRISE " +
                        "INNER JOIN THUBUPLOAD ON FK_THUB_UPLOAD_ENTREPRISE = ID_ENTREPRISE " +
                        "WHERE ID_ENTREPRISE = ? AND FILE_TYPE = ?", new Object[]{entrepriseId.asInt(), type.name()}, (rs, rowNum) -> {

                    String filenetId = rs.getString("FILENET_ID");
                    DocumentType documentType = DocumentType.valueOf(rs.getString("FILE_TYPE"));
                    MediaType mediaType = MediaType.parse((rs.getString("MEDIA_TYPE")));
                    return new DocumentMetadatas(filenetId, documentType, mediaType);
                });
    }

    public void saveMetadatas(Id entrepriseId, DocumentMetadatas metadata) {

        MapSqlParameterSource parameters = new MapSqlParameterSource();
        parameters.addValue("filenetId", metadata.getGedId());
        parameters.addValue("fileType", metadata.getType().name());
        parameters.addValue("mediaType", metadata.getMediaType().toString());
        parameters.addValue("entrepriseId", entrepriseId.asInt());

        int nbRowsAffected = dataSourceHandler.getNamedJdbcTemplate()
                .update("INSERT INTO THUBUPLOAD (FILENET_ID,FILE_TYPE,MEDIA_TYPE,FK_THUB_UPLOAD_ENTREPRISE)" +
                                " VALUES (:filenetId,:fileType,:mediaType,:entrepriseId)",
                        parameters);

        if (nbRowsAffected == 0) {
            throw new NoDataUpdatedException("Unable to add uploaded file " + metadata.getType() + " for entreprise " + entrepriseId);
        }
    }
}
