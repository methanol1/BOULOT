package com.natixis.nie.hubis.features.simulation.web.dto;


import com.natixis.nie.hubis.core.domain.simulation.Simulation;

public class SimulationDTO {

    private SimulationCriteriaDTO simulationCriteria;
    private EpargneDTO epargne;
    private CesuDTO cesu;
    private int totalVersement;
    private int optimizedTotalVersement;

    public EpargneDTO getEpargne() {
        return epargne;
    }

    public void setEpargne(EpargneDTO epargne) {
        this.epargne = epargne;
    }

    public CesuDTO getCesu() {
        return cesu;
    }

    public void setCesu(CesuDTO cesu) {
        this.cesu = cesu;
    }

    public int getTotalVersement() {
        return totalVersement;
    }

    public void setTotalVersement(int totalVersement) {
        this.totalVersement = totalVersement;
    }

    public int getOptimizedTotalVersement() {
        return optimizedTotalVersement;
    }

    public void setOptimizedTotalVersement(int optimizedTotalVersement) {
        this.optimizedTotalVersement = optimizedTotalVersement;
    }

    public SimulationCriteriaDTO getSimulationCriteria() {
        return simulationCriteria;
    }

    public void setSimulationCriteria(SimulationCriteriaDTO simulationCriteria) {
        this.simulationCriteria = simulationCriteria;
    }

    public static SimulationDTO fromModel(Simulation simulation) {

        SimulationDTO dto = new SimulationDTO();
        dto.setSimulationCriteria(SimulationCriteriaDTO.fromModel(simulation.getSimulationCriteria()));
        dto.setTotalVersement(simulation.getTotalVersement());
        dto.setOptimizedTotalVersement(simulation.getOptimizedTotalVersement());

        if (simulation.getEpargne().isPresent()) {
            dto.setEpargne(EpargneDTO.fromModel(simulation.getEpargne().get()));
        }

        if (simulation.getCesu().isPresent()) {
            dto.setCesu(CesuDTO.fromModel(simulation.getCesu().get()));
        }

        return dto;
    }
}
