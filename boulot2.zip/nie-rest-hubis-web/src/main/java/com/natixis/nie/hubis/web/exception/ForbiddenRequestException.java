package com.natixis.nie.hubis.web.exception;

import com.natixis.nie.hubis.web.Errors;

import javax.ws.rs.core.Response;

import static javax.ws.rs.core.Response.Status.FORBIDDEN;

public class ForbiddenRequestException extends HttpException {

    public ForbiddenRequestException(String message, Errors errors) {
        super(message, errors);
    }

    public ForbiddenRequestException(String message, Throwable cause, Errors errors) {
        super(message, cause, errors);
    }

    @Override
    public Response.Status getStatus() {
        return FORBIDDEN;
    }
}
