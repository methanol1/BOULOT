package com.natixis.nie.hubis;

import org.jboss.resteasy.plugins.providers.ServerFormUrlEncodedProvider;
import org.jboss.resteasy.plugins.providers.jackson.ResteasyJackson2Provider;
import org.reflections.Reflections;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.Path;
import javax.ws.rs.core.Application;
import javax.ws.rs.ext.Provider;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.toSet;

@ApplicationPath("/rest")
public class HubisApplication extends Application {

    private final static Logger logger = LoggerFactory.getLogger(HubisApplication.class);
    private final static Reflections REFLECTIONS = new Reflections("com.natixis.nie.hubis");
    private Set<Class<?>> classes = new HashSet<>();

    @PostConstruct
    public void init() throws IOException {
        logSystemProperties();

        Set<Class<?>> builtins = findBuiltInProviders();
        logger.info("Adding builtins {}", builtins);
        classes.addAll(builtins);

        Set<Class<?>> resources = findAppClassesAnnotatedWith(Path.class);
        logger.info("Adding resources {}", resources);
        classes.addAll(resources);

        Set<Class<?>> providers = findAppClassesAnnotatedWith(Provider.class);
        logger.info("Adding providers {}", providers);
        classes.addAll(providers);
    }

    @Override
    public Set<Class<?>> getClasses() {
        return classes;
    }

    private void logSystemProperties() {

        List<String> properties = System.getProperties().entrySet().stream()
                .map(e -> e.getKey() + ": " + e.getValue() + "\n")
                .collect(Collectors.toList());

        logger.debug("System properties {}", properties);
    }

    public static Set<Class<?>> findAppClassesAnnotatedWith(Class<? extends Annotation> clazz) {
        return REFLECTIONS.getTypesAnnotatedWith(clazz);
    }

    private static Set<Class<?>> findBuiltInProviders() {
        Reflections reflections = new Reflections("org.jboss.resteasy.plugins");

        return reflections.getTypesAnnotatedWith(Provider.class).stream()
                .filter(c -> !ServerFormUrlEncodedProvider.class.isAssignableFrom(c))//needs to be overridden with a custom constructor
                .filter(c -> !ResteasyJackson2Provider.class.isAssignableFrom(c))
                .collect(toSet());

    }

}
