package com.natixis.nie.hubis.core.db;

import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class TransactionManager {

    private final DataSourceTransactionManager transactionManager;
    private final DataSourceHandler dataSourceHandler;

    @Inject
    public TransactionManager(DataSourceHandler dataSourceHandler) {
        this.dataSourceHandler = dataSourceHandler;
        this.transactionManager = new DataSourceTransactionManager(this.dataSourceHandler.getDataSourceDS());
    }

    public <T> T execute(TransactionCallback<T> action) {
        return new TransactionTemplate(transactionManager).execute(action);
    }

    public DataSourceHandler getDataSourceHandler() {
        return dataSourceHandler;
    }
}
