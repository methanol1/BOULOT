package com.natixis.nie.hubis.core;


import com.natixis.nie.hubis.core.domain.User;

public interface EditiqueService {

    public byte[] generatePdf(User user);

}
