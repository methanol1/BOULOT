package com.natixis.nie.hubis.features.signature.dictao;

import com.natixis.nie.hubis.core.AppProperties;
import com.natixis.nie.hubis.core.exception.AppException;
import org.springframework.core.io.ClassPathResource;

import javax.net.ssl.*;
import java.io.File;
import java.io.FileInputStream;
import java.security.*;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

class SSLSocketFactoryGenerator {

    private final DictaoKeyStoreLoader dictaoKeyStoreLoader;

    public SSLSocketFactoryGenerator(AppProperties appProperties) {
        this.dictaoKeyStoreLoader = new DictaoKeyStoreLoader(appProperties);
    }

    public SSLSocketFactory createSSLFactoryWithEmbdedKeyStore() {

        try {
            SSLContext sslContext = SSLContext.getInstance("SSL");
            KeyManager[] kms = getKeyManagers();
            TrustManager[] tms = getTrustManagers();
            sslContext.init(kms, tms, null);
            return sslContext.getSocketFactory();
        } catch (GeneralSecurityException e) {
            throw new AppException("Unable to init ssl socket factory", e);
        }
    }

    private KeyManager[] getKeyManagers() throws NoSuchAlgorithmException, UnrecoverableKeyException, KeyStoreException {

        String algorithm = KeyManagerFactory.getDefaultAlgorithm();
        KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(algorithm);
        keyManagerFactory.init(dictaoKeyStoreLoader.loadKeyStore(), dictaoKeyStoreLoader.getKeyStorePassword().toCharArray());

        return keyManagerFactory.getKeyManagers();
    }

    private TrustManager[] getTrustManagers() throws NoSuchAlgorithmException, KeyStoreException {

        TrustManager tm = new X509TrustManager() {
            public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
            }

            public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
            }

            public X509Certificate[] getAcceptedIssuers() {
                return null;
            }
        };

        return new TrustManager[]{tm};
    }

    private static class DictaoKeyStoreLoader {


        private final AppProperties appProperties;

        public DictaoKeyStoreLoader(AppProperties appProperties) {

            this.appProperties = appProperties;
        }

        public KeyStore loadKeyStore() {
            try {
                File file = new ClassPathResource(appProperties.get("signature.ws.pfx")).getFile();

                KeyStore keyStore = KeyStore.getInstance("PKCS12");
                keyStore.load(new FileInputStream(file), getKeyStorePassword().toCharArray());
                return keyStore;

            } catch (Exception e) {
                throw new RuntimeException("Unable to init keystore", e);
            }
        }

        public String getKeyStorePassword() {
            return "password";
        }
    }
}
