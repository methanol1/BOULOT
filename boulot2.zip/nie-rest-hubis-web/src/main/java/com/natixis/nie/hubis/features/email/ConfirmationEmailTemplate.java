package com.natixis.nie.hubis.features.email;

import com.natixis.nie.hubis.core.AppProperties;
import com.natixis.nie.hubis.core.domain.Entreprise;
import com.natixis.nie.hubis.core.domain.User;
import com.natixis.nie.hubis.core.domain.simulation.Cesu;
import com.natixis.nie.hubis.core.domain.simulation.Epargne;
import com.natixis.nie.hubis.core.exception.AppException;

import freemarker.template.Configuration;
import freemarker.template.Template;

import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

public class ConfirmationEmailTemplate implements EmailTemplate {

    private final AppProperties appProperties;
    private final User user;


    public ConfirmationEmailTemplate(User user, AppProperties appProperties) {
        this.user = user;
        this.appProperties = appProperties;
    }

    @Override
    public String getSubject() {
        return "Confirmation";
    }

    @Override
    public String getHtmlContent(Configuration config) {

        Entreprise entreprise = user.getEntreprise();

        Map<String, String> model = new HashMap<>();
        model.put("redirectUrl", appProperties.get("app.url") + "/optimisation-fiscale.html#/entreprise");
        model.put("imageUrl", appProperties.get("app.url") + "/images");
        model.put("username", entreprise.getDirigeant().getFullname());
        model.put("plafondepargnesalariale", ""+user.getSimulation().getEpargne().map(Epargne::getAbondementBrut).orElse(0));
        model.put("montantcommande",""+user.getSimulation().getCesu().map(Cesu::getVersement).orElse(0));
        model.put("adresse","" + entreprise.getDirigeant().getAdresse().getRue());
        model.put("codepostal","" + entreprise.getDirigeant().getAdresse().getCodePostal());
        model.put("ville","" + entreprise.getDirigeant().getAdresse().getVille());
        
        try {
            Template template = config.getTemplate("confirmation.ftl");
            StringWriter output = new StringWriter();
            template.process(model, output);
            return output.toString();

        } catch (Exception e) {
            throw new AppException("Unable to generate HTML content for reset email", e);
        }
    }
}
