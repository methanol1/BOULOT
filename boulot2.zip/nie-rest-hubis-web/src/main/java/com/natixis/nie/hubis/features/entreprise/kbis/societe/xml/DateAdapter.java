package com.natixis.nie.hubis.features.entreprise.kbis.societe.xml;

import javax.xml.bind.annotation.adapters.XmlAdapter;
import java.text.SimpleDateFormat;
import java.util.Date;

class DateAdapter extends XmlAdapter<String, Date> {

    public static SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd-MM-yyyy");

    @Override
    public String marshal(Date v) throws Exception {
        return DATE_FORMAT.format(v);
    }

    @Override
    public Date unmarshal(String v) throws Exception {
        return DATE_FORMAT.parse(v);
    }

}