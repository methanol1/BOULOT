package com.natixis.nie.hubis.features.user.dto;


import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.natixis.nie.hubis.features.entreprise.web.dto.EntrepriseDTO;
import com.natixis.nie.hubis.features.simulation.web.dto.SimulationDTO;

public class UserDTO {

    private SimulationDTO simulation;
    private EntrepriseDTO entreprise;

    @JsonCreator
    public UserDTO(@JsonProperty("simulation") SimulationDTO simulation, @JsonProperty("entreprise") EntrepriseDTO entreprise) {
        this.simulation = simulation;
        this.entreprise = entreprise;
    }

    public SimulationDTO getSimulation() {
        return simulation;
    }

    public EntrepriseDTO getEntreprise() {
        return entreprise;
    }
}
