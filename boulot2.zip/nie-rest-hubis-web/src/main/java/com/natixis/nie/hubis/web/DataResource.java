package com.natixis.nie.hubis.web;

import com.natixis.nie.hubis.core.AppProperties;
import com.natixis.nie.hubis.core.db.DataDAO;
import com.natixis.nie.hubis.security.AppSecurity;
import com.natixis.nie.hubis.web.dto.AppPropertiesDTO;
import com.natixis.nie.hubis.web.dto.SignaturePropertiesDTO;
import io.swagger.annotations.Api;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/v1/data")
@Produces({MediaType.APPLICATION_JSON})
@Consumes(MediaType.APPLICATION_JSON)
@Api(value = "v1-data",
        description = "Exposes services to retrieve datas",
        consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
public class DataResource extends AbstractRestResource{

    @Inject
    DataDAO dataDAO;

    @GET
    @Path("/formesJuridiques")
    public Response getFormesJuridiques() {
        return Response.ok(dataDAO.findAllFormesJuridiques()).build();
    }

    @GET
    @Path("/naces")
    public Response getNaces() {
        return Response.ok(dataDAO.findAllNaces()).build();
    }

    @GET
    @Path("/properties/app")
    public Response getAppProperties() {
        boolean authenticated = appSecurity.isAuthenticated();
        return Response.ok(new AppPropertiesDTO(appProperties, authenticated)).build();
    }

    @GET
    @Path("/properties/signature")
    public Response getSignatureProperties() {
        return Response.ok(new SignaturePropertiesDTO(appProperties)).build();
    }

}
