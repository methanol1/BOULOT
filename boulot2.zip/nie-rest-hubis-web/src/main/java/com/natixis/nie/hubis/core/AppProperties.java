package com.natixis.nie.hubis.core;

import com.natixis.nie.hubis.core.exception.AppException;
import org.springframework.core.io.support.PropertiesLoaderUtils;

import javax.inject.Singleton;
import java.io.IOException;
import java.util.Properties;

@Singleton
public class AppProperties {

    public static AppProperties APP_PROPERTIES = new AppProperties();
    private Properties defaults;
    private Properties xldeploy;
    private final Properties env;

    public AppProperties() {
        this(load("application.properties"));
    }

    public AppProperties(Properties defaults) {
        this(defaults, load("xldeploy.properties"), System.getProperties());
    }

    public AppProperties(Properties defaults, Properties xldeploy, Properties env) {
        this.defaults = defaults;
        this.xldeploy = xldeploy;
        this.env = env;
    }

    public String get(String key) {
        if (availableInEnv(key)) {
            return env.getProperty(key);
        } else if (availableInXLDeploy(key)) {
            return xldeploy.getProperty(key);
        }
        return defaults.getProperty(key);
    }

    public int getInt(String key) {
        return Integer.valueOf(get(key));
    }

    public double getDouble(String key) {
        return Double.valueOf(get(key));
    }

    public boolean isTest() {
        return "test".equals(getEnv());
    }

    public boolean isLocal() {
        return "local".equals(getEnv()) || isTest();
    }

    public boolean isDev() {
        return "dev1".equals(getEnv());
    }
    public boolean isQua() {
        return "qua".equals(getEnv());
    }

    public String getEnv() {
        return get("app.env");
    }

    private boolean availableInXLDeploy(String key) {
        return xldeploy.containsKey(key) && !xldeploy.getProperty(key).startsWith("{{");
    }

    private boolean availableInEnv(String key) {
        return env.containsKey(key);
    }

    private static Properties load(String resourceName) {
        try {
            return PropertiesLoaderUtils.loadAllProperties(resourceName);
        } catch (IOException e) {
            throw new AppException("Unable to read application properties from " + resourceName, e);
        }
    }
}
