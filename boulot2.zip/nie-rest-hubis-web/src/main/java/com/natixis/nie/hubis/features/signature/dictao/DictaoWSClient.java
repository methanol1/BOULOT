package com.natixis.nie.hubis.features.signature.dictao;

import com.natixis.nie.hubis.core.AppProperties;
import com.natixis.nie.hubis.core.exception.AppException;
import com.natixis.nie.hubis.signature.DocumentPort;
import com.natixis.nie.hubis.signature.FrontOfficeService;
import com.natixis.nie.hubis.signature.TransactionPort;
import org.springframework.core.io.ClassPathResource;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import java.io.IOException;
import java.net.URL;
import java.util.Map;


class DictaoWSClient {

    private final TransactionPort transactionPort;
    private final DocumentPort documentPort;
    private final FrontOfficeService service;
    private final AppProperties appProperties;

    public DictaoWSClient(AppProperties appProperties) {

        this.service = createFrontOfficeService();
        this.appProperties = appProperties;
        this.transactionPort = createPort("ws/v5/transaction", TransactionPort.class);
        this.documentPort = createPort("ws/v5/document", DocumentPort.class);
        HttpsURLConnection.setDefaultHostnameVerifier(new NullHostnameVerifier());

        if (appProperties.isLocal()) {
            SSLSocketFactory sslSocketFactory = new SSLSocketFactoryGenerator(appProperties).createSSLFactoryWithEmbdedKeyStore();
            HttpsURLConnection.setDefaultSSLSocketFactory(sslSocketFactory);
            ((BindingProvider) transactionPort).getRequestContext().put("com.sun.xml.internal.ws.transport.https.client.SSLSocketFactory", sslSocketFactory);
            ((BindingProvider) documentPort).getRequestContext().put("com.sun.xml.internal.ws.transport.https.client.SSLSocketFactory", sslSocketFactory);
        }
    }

    private <T> T createPort(String endpointUrl, Class<T> clazz) {

        T port = service.getPort(clazz);
        Map<String, Object> context = ((BindingProvider) port).getRequestContext();
        context.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, appProperties.get("signature.ws.url") + endpointUrl);

        return port;
    }

    public TransactionPort getTransactionPort() {
        return transactionPort;
    }

    public DocumentPort getDocumentPort() {
        return documentPort;
    }

    private static FrontOfficeService createFrontOfficeService() {
        QName qName = new QName("http://dictao.com/wsdl/dtp/frontoffice/v5", "FrontOfficeService");
        try {
            URL wsdlLocation = new ClassPathResource("signature/dtp-frontoffice-v5u3.wsdl").getURL();
            return new FrontOfficeService(wsdlLocation, qName);
        } catch (IOException e) {
            throw new AppException("Unable to find wsdl", e);
        }
    }

    private static class NullHostnameVerifier implements HostnameVerifier {

        public boolean verify(String hostname, SSLSession session) {
            return true;
        }
    }
}
