package com.natixis.nie.hubis.features.email;

import com.natixis.nie.hubis.core.AppProperties;
import com.natixis.nie.hubis.core.exception.AppException;
import freemarker.template.Configuration;
import freemarker.template.Template;

import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

public class WelcomeEmailTemplate implements EmailTemplate {

    private final AppProperties appProperties;
    private final String email;

    public WelcomeEmailTemplate(String email, AppProperties appProperties) {
        this.email = email;
        this.appProperties = appProperties;
    }

    @Override
    public String getSubject() {
        return "Bienvenue";
    }

    @Override
    public String getHtmlContent(Configuration config) {

        Map<String, String> model = new HashMap<>();
        model.put("redirectUrl", appProperties.get("app.url") + "/optimisation-fiscale.html#/login");
        model.put("imageUrl", appProperties.get("app.url") + "/images");
        model.put("email", email);

        try {
            Template template = config.getTemplate("welcome.ftl");
            StringWriter output = new StringWriter();
            template.process(model, output);
            return output.toString();

        } catch (Exception e) {
            throw new AppException("Unable to generate HTML content for reset email", e);
        }
    }
}
