package com.natixis.nie.hubis.core.domain;

public class ChannelDimelo {
	private String id;
	private String name;
	private String status;
	private String busyness;
	
	public String getId() {
		return id;
	}
	public void setId(String aId) {
		id = aId;
	}
	public String getName() {
		return name;
	}
	public void setName(String aName) {
		name = aName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String aStatus) {
		status = aStatus;
	}
	public String getBusyness() {
		return busyness;
	}
	public void setBusyness(String aBusyness) {
		busyness = aBusyness;
	}
	
	
	
}
