package com.natixis.nie.hubis.features.entreprise.web.validation;

import org.iban4j.BicUtil;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class BICValidator implements ConstraintValidator<BIC, String> {

    @Override
    public void initialize(BIC constraintAnnotation) {
    }

    @Override
    public boolean isValid(String object, ConstraintValidatorContext constraintContext) {
        try {
            String bic = object != null ? object.toUpperCase() : null;
            BicUtil.validate(bic);
        } catch (Exception e) {
            return false;
        }
        return true;
    }
}
