package com.natixis.nie.hubis.core.domain;

import java.util.List;

public class AgentDimelo {
	private String agent_id;
	
	private List<ChannelDimelo> channels;
	
	private CustomStatusDimelo custom_status;
	
	public AgentDimelo() {
		// TODO Auto-generated constructor stub
	}

	public String getAgent_id() {
		return agent_id;
	}

	public void setAgent_id(String aAgent_id) {
		agent_id = aAgent_id;
	}

	public List<ChannelDimelo> getChannels() {
		return channels;
	}

	public void setChannels(List<ChannelDimelo> aChannels) {
		channels = aChannels;
	}

	public CustomStatusDimelo getCustom_status() {
		return custom_status;
	}

	public void setCustom_status(CustomStatusDimelo aCustom_status) {
		custom_status = aCustom_status;
	}

	
}
