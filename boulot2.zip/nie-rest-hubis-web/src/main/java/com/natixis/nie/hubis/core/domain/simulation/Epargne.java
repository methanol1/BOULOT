package com.natixis.nie.hubis.core.domain.simulation;

import static com.natixis.nie.hubis.features.simulation.SimulationItems.asInt;

public class Epargne {

    private final static double MAX_PLAFOND = 999999.99;

    private final int versement;
    private final SimulationsDatas datas;
    private final int abondementBrut;
    private final Epargnant epargnant;

    public Epargne(int versement, SimulationCriteria criteria) {
        this.versement = versement;
        this.datas = criteria.getDatas();
        this.abondementBrut = computeAbondementBrut();
        this.epargnant = new Epargnant(versement, abondementBrut, criteria);
    }

    public int getVersement() {
        return versement;
    }

    public int getAbondementBrut() {
        return abondementBrut;
    }

    public int getAbondementNet() {
        return asInt(abondementBrut * (1 - datas.getTauxCSG_CRDS()));
    }

    public int getForfaitSocial() {

        if (needPEIOnly()) {
            return asInt(abondementBrut * datas.getForfaitSocialPEI());
        } else {
            return asInt((datas.getPlafondPEI() * datas.getPASS() * datas.getForfaitSocialPEI()) + ((abondementBrut - datas.getPlafondPEI() * datas.getPASS()) * datas.getForfaitSocialPERCOI()));
        }
    }

    public int getCotisationSociales() {
        return abondementBrut - getAbondementNet();
    }

    public Epargnant getEpargnant() {
        return epargnant;
    }

    public SimulationsDatas getDatas() {
        return datas;
    }

    public double getMontantPlafondPEI() {
        if (abondementBrut < datas.getPASS() * datas.getPlafondPEI()) {
            return abondementBrut;
        } else {
            return MAX_PLAFOND;
        }
    }

    public double getMontantPlafondPERCOI() {
        if (abondementBrut < datas.getPASS() * datas.getPlafondPEI()) {
            return 0;
        } else if (abondementBrut < datas.getPASS() * (datas.getPlafondPEI() + datas.getPlafondPERCOI())) {
            return (abondementBrut - (datas.getPASS() * datas.getPlafondPEI()));
        } else {
            return MAX_PLAFOND;
        }
    }

    private int computeAbondementBrut() {

        if (needPEIOnly()) {
            return asInt(versement / (1 + datas.getForfaitSocialPEI()));
        } else {
            return asInt(((datas.getPASS() * datas.getPlafondPEI() * (1 + datas.getForfaitSocialPEI())) / (1 + datas.getForfaitSocialPEI()))
                    + ((versement - (datas.getPASS() * datas.getPlafondPEI() * (1 + datas.getForfaitSocialPEI()))) / (1 + datas.getForfaitSocialPERCOI())));
        }
    }

    private boolean needPEIOnly() {
        return versement <= (datas.getPASS() * datas.getPlafondPEI()) * (1 + datas.getForfaitSocialPEI());
    }
}
