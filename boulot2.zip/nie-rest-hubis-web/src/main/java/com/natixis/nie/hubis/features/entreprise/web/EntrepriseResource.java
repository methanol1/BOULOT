package com.natixis.nie.hubis.features.entreprise.web;

import com.natixis.nie.hubis.core.Datas;
import com.natixis.nie.hubis.core.Env;
import com.natixis.nie.hubis.core.SouscriptionService;
import com.natixis.nie.hubis.core.domain.Entreprise;
import com.natixis.nie.hubis.core.domain.Siret;
import com.natixis.nie.hubis.core.domain.State;
import com.natixis.nie.hubis.core.domain.User;
import com.natixis.nie.hubis.core.domain.kbis.Kbis;
import com.natixis.nie.hubis.features.entreprise.kbis.KbisException;
import com.natixis.nie.hubis.features.entreprise.kbis.KbisFetcher;
import com.natixis.nie.hubis.features.entreprise.web.dto.EntrepriseDTO;
import com.natixis.nie.hubis.features.entreprise.web.validation.IBANValidator;
import com.natixis.nie.hubis.web.AbstractRestResource;
import com.natixis.nie.hubis.web.Errors;
import com.natixis.nie.hubis.web.exception.HttpBadRequestException;
import io.swagger.annotations.Api;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.Optional;

import static com.natixis.nie.hubis.core.domain.State.ENTREPRISE;
import static com.natixis.nie.hubis.web.Errors.Type.INVALID_PARAMS;
import static com.natixis.nie.hubis.web.Errors.error;

@Path("/v1/entreprise")
@Produces({MediaType.APPLICATION_JSON})
@Consumes(MediaType.APPLICATION_JSON)
@Api(value = "v1-entreprise",
        description = "Exposes services to handle entreprise",
        consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
public class EntrepriseResource extends AbstractRestResource {

    private final static Logger logger = LoggerFactory.getLogger(EntrepriseResource.class);

    @Inject
    Datas datas;

    @Inject
    SouscriptionService souscriptionService;

    @Inject
    @Env
    KbisFetcher kbisFetcher;
    private final IBANValidator ibanValidator;

    public EntrepriseResource() {
        ibanValidator = new IBANValidator();
    }

    @POST
    public Response create(EntrepriseDTO dto, @Context HttpServletRequest request) {

        User user = appSecurity.getCurrentUserForState(ENTREPRISE);
        dto = handleEncryptedIban(dto, user);

        Siret siret = new Siret(dto.getSiret());
        Entreprise entreprise;

        try {
            Optional<Kbis> kbis = kbisFetcher.fetch(siret);

            if (!kbis.isPresent()) {
                Errors errors = error(INVALID_PARAMS, messages.get("kbis.errors.invalid"));
                throw new HttpBadRequestException("Unable to find siret " + siret.asString(), errors);
            }
            entreprise = dto.toModel(datas, kbis.get());

        } catch (KbisException e) {
            logger.error("Unable to find kbis for entreprise with siret" + siret.asString());
            entreprise = dto.toModel(datas);
        }

        State state = souscriptionService.createEntreprise(user, entreprise);

        return sendState(state);
    }

    private EntrepriseDTO handleEncryptedIban(EntrepriseDTO dto, User user) {
        Optional<Entreprise> entreprise = user.getEntrepriseAsOptional();

        if (!entreprise.isPresent() || dto.getBankData().getIban() != null) {
            if (!ibanValidator.isValid(dto.getBankData().getIban(), null)) {
                throw new HttpBadRequestException("Unable to validate Iban", Errors.error(INVALID_PARAMS, messages.get("entreprise.iban.invalid")));
            }
        } else {
            dto.getBankData().setIban(entreprise.get().getBankData().getIban());
        }
        return dto;
    }
}
