package com.natixis.nie.hubis.features.entreprise.web.dto;


import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.natixis.nie.hubis.core.domain.kbis.Kbis;

import java.util.List;
import java.util.stream.Collectors;

public class KbisDTO {

    private List<DirigeantDTO> dirigeants;
    private EntrepriseInfosDTO entreprise;

    @JsonCreator
    public KbisDTO(@JsonProperty("entreprise") EntrepriseInfosDTO entreprise, @JsonProperty("dirigeants") List<DirigeantDTO> dirigeants) {
        this.entreprise = entreprise;
        this.dirigeants = dirigeants;
    }

    public List<DirigeantDTO> getDirigeants() {
        return dirigeants;
    }

    public EntrepriseInfosDTO getEntreprise() {
        return entreprise;
    }

    public static KbisDTO fromModel(Kbis kbis) {
        EntrepriseInfosDTO entreprise = EntrepriseInfosDTO.fromModel(kbis.getEntreprise());
        List<DirigeantDTO> dirigeants = kbis.getDirigeants().stream().map(DirigeantDTO::fromModel).collect(Collectors.toList());
        return new KbisDTO(entreprise, dirigeants);
    }
}
