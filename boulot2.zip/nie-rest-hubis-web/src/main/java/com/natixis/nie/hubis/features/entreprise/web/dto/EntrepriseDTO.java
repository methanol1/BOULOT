package com.natixis.nie.hubis.features.entreprise.web.dto;

import com.natixis.nie.hubis.core.Datas;
import com.natixis.nie.hubis.core.domain.*;
import com.natixis.nie.hubis.core.domain.kbis.Kbis;
import com.natixis.nie.hubis.features.entreprise.web.validation.SIRET;
import com.natixis.nie.hubis.web.validation.Validable;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import java.time.Month;

public class EntrepriseDTO implements Validable {

    private Integer id;

    @NotEmpty
    @SIRET
    private String siret;

    @NotEmpty
    private String raisonSociale;

    @Max(250)
    private int effectif;

    @NotNull
    private Integer moisDeCloture;

    @NotNull
    @Valid
    private AdresseDTO adresse;

    @NotNull
    private Integer formeJuridique;

    @NotNull
    private String nace;

    @NotNull
    @Valid
    private BankDataDTO bankData;

    @NotNull
    @Valid
    private DirigeantDTO dirigeant;

    private String nomDispositif;

    private boolean isStatutRequired;

    private boolean isEtatFinRequired;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSiret() {
        return siret;
    }

    public void setSiret(String siret) {
        this.siret = siret;
    }

    public String getRaisonSociale() {
        return raisonSociale;
    }

    public void setRaisonSociale(String raisonSociale) {
        this.raisonSociale = raisonSociale;
    }

    public int getEffectif() {
        return effectif;
    }

    public void setEffectif(int effectif) {
        this.effectif = effectif;
    }

    public Integer getMoisDeCloture() {
        return moisDeCloture;
    }

    public void setMoisDeCloture(Integer moisDeCloture) {
        this.moisDeCloture = moisDeCloture;
    }

    public AdresseDTO getAdresse() {
        return adresse;
    }

    public void setAdresse(AdresseDTO adresse) {
        this.adresse = adresse;
    }

    public Integer getFormeJuridique() {
        return formeJuridique;
    }

    public void setFormeJuridique(Integer formeJuridique) {
        this.formeJuridique = formeJuridique;
    }

    public String getNace() {
        return nace;
    }

    public void setNace(String nace) {
        this.nace = nace;
    }

    public BankDataDTO getBankData() {
        return bankData;
    }

    public void setBankData(BankDataDTO bankData) {
        this.bankData = bankData;
    }

    public DirigeantDTO getDirigeant() {
        return dirigeant;
    }

    public void setDirigeant(DirigeantDTO dirigeant) {
        this.dirigeant = dirigeant;
    }

    public String getNomDispositif() {
        return nomDispositif;
    }

    public void setNomDispositif(String nomDispositif) {
        this.nomDispositif = nomDispositif;
    }

    public boolean isStatutRequired() {
        return isStatutRequired;
    }

    public void setStatutRequired(boolean statutRequired) {
        isStatutRequired = statutRequired;
    }

    public boolean isEtatFinRequired() {
        return isEtatFinRequired;
    }

    public void setEtatFinRequired(boolean etatFinRequired) {
        isEtatFinRequired = etatFinRequired;
    }

    public Entreprise toModel(Datas datas) {
        return toModel(datas, null);
    }

    public Entreprise toModel(Datas datas, Kbis kbis) {

        BankData bankData = getBankData().toModel();
        FormeJuridique formeJuridique = datas.findAllFormesJuridiques().stream()
                .filter(fj -> fj.getId() == this.formeJuridique)
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Unable to find Forme juridique with id " + this.formeJuridique));
        Nace nace = datas.findAllNaces().stream()
                .filter(n -> n.getCode().equals(this.nace))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Unable to find Nace with code " + this.nace));

        return new Entreprise(
                new Siret(siret),
                raisonSociale,
                formeJuridique,
                nace,
                this.adresse.toModel(),
                effectif,
                Month.of(moisDeCloture),
                dirigeant.toModel(),
                bankData,
                kbis,
                nomDispositif);
    }

    public static EntrepriseDTO fromModel(Entreprise entreprise) {
        EntrepriseDTO dto = new EntrepriseDTO();
        dto.setSiret(entreprise.getSiret().asString());
        dto.setRaisonSociale(entreprise.getRaisonSociale());
        dto.setEffectif(entreprise.getEffectif());
        dto.setMoisDeCloture(entreprise.getMoisDeCloture().getValue());
        dto.setFormeJuridique(entreprise.getFormeJuridique().getId());
        dto.setNace(entreprise.getNace().getCode());
        dto.setAdresse(AdresseDTO.fromModel(entreprise.getAdresse()));
        dto.setDirigeant(DirigeantDTO.fromModel(entreprise.getDirigeant()));
        dto.setBankData(BankDataDTO.fromModel(entreprise.getBankData()));
        dto.setNomDispositif(entreprise.getNomDispositif().orElse(null));
        dto.setStatutRequired(entreprise.getFormeJuridique().isStatutRequired());
        dto.setEtatFinRequired(entreprise.getNace().isEtatFinRequired());
        dto.setId(entreprise.getId().map(Id::asInt).orElse(null));
        return dto;
    }
}
