package com.natixis.nie.hubis.security;

import com.google.common.collect.Lists;
import org.apache.shiro.authc.pam.ModularRealmAuthenticator;
import org.apache.shiro.config.Ini;
import org.apache.shiro.realm.Realm;
import org.apache.shiro.web.config.IniFilterChainResolverFactory;
import org.apache.shiro.web.env.DefaultWebEnvironment;
import org.apache.shiro.web.env.EnvironmentLoader;
import org.apache.shiro.web.env.WebEnvironment;
import org.apache.shiro.web.filter.mgt.FilterChainResolver;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.springframework.core.io.ClassPathResource;

import javax.inject.Inject;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import java.io.IOException;


public class ShiroBootstrapListener extends EnvironmentLoader implements ServletContextListener {

    @Inject
    AppSecurity security;

    @Inject
    CredentialsDAO credentialsDAO;

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        initEnvironment(sce.getServletContext());
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        destroyEnvironment(sce.getServletContext());
    }

    @Override
    protected WebEnvironment createEnvironment(ServletContext sc) {

        Realm realm = new CredentialsJdbcRealm(credentialsDAO, security.getCredentialsMatcher());
        DefaultWebSecurityManager manager = new DefaultWebSecurityManager();
        manager.setAuthenticator(createAuthenticator());
        manager.setRememberMeManager(null);
        manager.setRealm(realm);

        DefaultWebEnvironment env = new DefaultWebEnvironment();
        env.setWebSecurityManager(manager);
        env.setServletContext(sc);

        FilterChainResolver filterChainResolver = createFilterChainResolver();
        env.setFilterChainResolver(filterChainResolver);

        return env;
    }

    private ModularRealmAuthenticator createAuthenticator() {
        ModularRealmAuthenticator authenticator = new ModularRealmAuthenticator();
        authenticator.setAuthenticationListeners(Lists.newArrayList(new LogAuthenticationListener()));
        return authenticator;
    }

    private FilterChainResolver createFilterChainResolver() {
        ClassPathResource resource = new ClassPathResource("shiro-filters.ini");
        Ini ini = new Ini();
        try {
            ini.load(resource.getInputStream());
        } catch (IOException e) {
            throw new RuntimeException("Unable to load Shiro ini file");
        }

        IniFilterChainResolverFactory factory = new IniFilterChainResolverFactory(ini);
        return factory.createInstance();
    }

}