package com.natixis.nie.hubis.features.entreprise.web;

import com.natixis.nie.hubis.core.Env;
import com.natixis.nie.hubis.core.domain.Siret;
import com.natixis.nie.hubis.core.domain.kbis.Kbis;
import com.natixis.nie.hubis.features.entreprise.kbis.KbisException;
import com.natixis.nie.hubis.features.entreprise.kbis.KbisFetcher;
import com.natixis.nie.hubis.features.entreprise.web.dto.KbisDTO;
import com.natixis.nie.hubis.web.ResourceBase;
import io.swagger.annotations.Api;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/v1/entreprise/preload")
@Produces({MediaType.APPLICATION_JSON})
@Consumes(MediaType.APPLICATION_JSON)
@Api(value = "v1-entreprise-preload",
        description = "Exposes services to preload entreprise dats",
        consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
public class PreloadResource extends ResourceBase {

    @Inject
    @Env
    KbisFetcher kbisFetcher;

    @GET
    public Response preload(@QueryParam("siret") String s, @Context HttpServletRequest request) {

        Siret siret = new Siret(s);

        try {

            Kbis kbis = kbisFetcher.fetch(siret)
                    .orElseThrow(() -> _400("Unable to find siret " + siret, "kbis.errors.invalid"));

            KbisDTO dto = KbisDTO.fromModel(kbis);
            return Response.ok(dto).build();

        } catch (KbisException e) {
            throw _500(String.format("Unable to preload siret %s", siret), e, "kbis.errors.technical");
        }

    }

}
