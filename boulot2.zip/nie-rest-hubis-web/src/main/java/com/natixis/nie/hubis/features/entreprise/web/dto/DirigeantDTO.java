package com.natixis.nie.hubis.features.entreprise.web.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.natixis.nie.hubis.core.domain.Dirigeant;
import com.natixis.nie.hubis.core.domain.kbis.DirigeantInfos;
import com.natixis.nie.hubis.web.validation.Validable;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.time.LocalDate;

public class DirigeantDTO implements Validable {

    @NotEmpty
    private String fullname;

    @NotEmpty
    private String fonction;

    @Pattern(regexp = "(^$|[0]{1}[6-7]{1}[0-9]{8})")
    private String telephone;

    @NotNull
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate datenaiss;

    @NotNull
    private AdresseDTO adresse;


    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getFonction() {
        return fonction;
    }

    public void setFonction(String fonction) {
        this.fonction = fonction;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public LocalDate getDatenaiss() {
        return datenaiss;
    }

    public void setDatenaiss(LocalDate datenaiss) {
        this.datenaiss = datenaiss;
    }

    public AdresseDTO getAdresse() {
        return adresse;
    }

    public void setAdresse(AdresseDTO adresse) {
        this.adresse = adresse;
    }

    public Dirigeant toModel() {
        return Dirigeant.newDirigeant(fullname, fonction, telephone, datenaiss, adresse.toModel(), null);
    }

    public static DirigeantDTO fromModel(Dirigeant dirigeant) {
        DirigeantDTO dto = new DirigeantDTO();
        dto.setFullname(dirigeant.getFullname());
        dto.setFonction(dirigeant.getFonction());
        dto.setTelephone(dirigeant.getTelephone());
        dto.setDatenaiss(dirigeant.getDatenaiss());
        dto.setAdresse(AdresseDTO.fromModel(dirigeant.getAdresse()));
        return dto;
    }

    public static DirigeantDTO fromModel(DirigeantInfos infos) {
        DirigeantDTO dto = new DirigeantDTO();
        dto.setFullname(infos.getFullname());
        dto.setFonction(infos.getFonction());
        return dto;
    }
}
