package com.natixis.nie.hubis.core.domain.kbis;


import com.natixis.nie.hubis.core.domain.Adresse;
import com.natixis.nie.hubis.core.domain.FormeJuridique;
import com.natixis.nie.hubis.core.domain.Nace;
import com.natixis.nie.hubis.core.domain.Siret;

import java.time.Month;

public class EntrepriseInfos {

    private final Siret siret;
    private final String raisonSociale;
    private final FormeJuridique formeJuridique;
    private final Nace nace;
    private final Adresse adresse;
    private final DirigeantInfos dirigeantInfos;
    private final Month moisDeCloture;

    public EntrepriseInfos(Siret siret, String raisonSociale, FormeJuridique formeJuridique, Nace nace, Adresse adresse, DirigeantInfos dirigeantInfos, Month moisDeCloture) {
        this.siret = siret;
        this.raisonSociale = raisonSociale;
        this.formeJuridique = formeJuridique;
        this.nace = nace;
        this.adresse = adresse;
        this.dirigeantInfos = dirigeantInfos;
        this.moisDeCloture = moisDeCloture;
    }

    public Siret getSiret() {
        return siret;
    }

    public String getRaisonSociale() {
        return raisonSociale;
    }

    public FormeJuridique getFormeJuridique() {
        return formeJuridique;
    }

    public Nace getNace() {
        return nace;
    }

    public Adresse getAdresse() {
        return adresse;
    }

    public DirigeantInfos getDirigeantInfos() {
        return dirigeantInfos;
    }

    public Month getMoisDeCloture() {
        return moisDeCloture;
    }
}
