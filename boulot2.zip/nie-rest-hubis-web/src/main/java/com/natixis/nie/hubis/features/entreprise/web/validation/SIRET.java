package com.natixis.nie.hubis.features.entreprise.web.validation;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Target({FIELD, METHOD, PARAMETER, ANNOTATION_TYPE})
@Retention(RUNTIME)
@Constraint(validatedBy = SIRETValidator.class)
public @interface SIRET {

    String message() default "This ²SIRET is not valid";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
