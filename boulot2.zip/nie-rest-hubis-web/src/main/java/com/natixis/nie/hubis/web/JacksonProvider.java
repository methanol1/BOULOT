package com.natixis.nie.hubis.web;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.InjectableValues;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.natixis.nie.hubis.core.AppProperties;
import org.jboss.resteasy.plugins.providers.jackson.ResteasyJackson2Provider;

import javax.ws.rs.ext.Provider;

import static com.natixis.nie.hubis.core.AppProperties.APP_PROPERTIES;

@Provider
public class JacksonProvider extends ResteasyJackson2Provider {

    public static final ObjectMapper MAPPER = createObjectMapper();

    public JacksonProvider() {
        super();
        setMapper(MAPPER);
    }

    private static ObjectMapper createObjectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        return withInjectablesValues(mapper);
    }

    private static ObjectMapper withInjectablesValues(ObjectMapper mapper) {
        InjectableValues injectableValues = new InjectableValues.Std().addValue(AppProperties.class, APP_PROPERTIES);
        mapper.setInjectableValues(injectableValues);
        return mapper;
    }
}
