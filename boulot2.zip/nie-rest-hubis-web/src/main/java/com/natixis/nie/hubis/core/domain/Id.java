package com.natixis.nie.hubis.core.domain;


public class Id {

    private int id;

    public Id(int id) {
        this.id = id;
    }

    public boolean isEmpty() {
        return id == 0;
    }

    public int asInt() {
        return id;
    }

    public String asString() {
        return Integer.toString(id);
    }

    public String toString() {
        return asString();
    }
}
