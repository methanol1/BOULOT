package com.natixis.nie.hubis.security;

import com.natixis.nie.hubis.core.Messages;
import com.natixis.nie.hubis.core.db.UserDAO;
import com.natixis.nie.hubis.core.domain.State;
import com.natixis.nie.hubis.core.domain.User;
import com.natixis.nie.hubis.core.exception.AppException;
import com.natixis.nie.hubis.web.Errors;
import com.natixis.nie.hubis.web.exception.ForbiddenRequestException;
import com.natixis.nie.hubis.web.exception.UnauthorizedRequestException;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authc.credential.CredentialsMatcher;
import org.apache.shiro.subject.Subject;

import javax.inject.Inject;
import javax.inject.Singleton;

import static com.natixis.nie.hubis.web.Errors.Type.AUTH;
import static com.natixis.nie.hubis.web.Errors.Type.INVALID_STATE;

@Singleton
public class AppSecurity {

    private final UserDAO userDAO;
    private final BCryptPasswordService passwordService;
    private final CredentialsMatcher credentialsMatcher;
    private final Messages messages;


    @Inject
    public AppSecurity(UserDAO userDAO, Messages messages) {
        this.messages = messages;
        this.passwordService = new BCryptPasswordService();
        this.credentialsMatcher = new BCryptCredentialsMatcher();
        this.userDAO = userDAO;
    }

    public String login(String email, String password) {

        UsernamePasswordToken token = new UsernamePasswordToken(email, password);
        token.setRememberMe(false);

        Subject subject = SecurityUtils.getSubject();
        try {
            subject.login(token);
        } catch (LockAuthenticationException e) {
            throw new LockedUserException("User " + email + " is locked", e);

        } catch (AuthenticationException e) {
            throw new InvalidCredentials(email, e);
        }

        return (String) subject.getPrincipal();
    }

    public User getCurrentUser() {
        Errors error = Errors.error(AUTH, messages.get("auth.invalid.session"));
        if (!isAuthenticated()) {

            throw new UnauthorizedRequestException("Current user is not authenticated", error);
        }
        try {
            Subject subject = SecurityUtils.getSubject();
            String username = (String) subject.getPrincipal();
            return userDAO.get(username);
        } catch (Exception e) {
            throw new UnauthorizedRequestException("Unable to retrieve current user from DAO", e, error);
        }
    }

    public User getCurrentUserForState(State state) {
        User currentUser = getCurrentUser();
        throwIfNotAllowed(currentUser, state);
        return currentUser;
    }

    public void logout() {
        SecurityUtils.getSubject().logout();
    }

    public String hashPassword(String password) {
        if (password == null) {
            throw new IllegalArgumentException("Unable to create credentials from null parameters");
        }

        return passwordService.encryptPassword(password);
    }

    public boolean isAuthenticated() {
        return SecurityUtils.getSubject().isAuthenticated();
    }

    CredentialsMatcher getCredentialsMatcher() {
        return credentialsMatcher;
    }

    private void throwIfNotAllowed(User user, State stateToCheck) throws AppException {
        State currentState = user.getCurrentState();
        if (!currentState.allowedStates().contains(stateToCheck)) {
            Errors error = Errors.error(INVALID_STATE, "invalid state");
            throw new ForbiddenRequestException("User is not allowed to request resource " + stateToCheck + " with a state " + currentState, error);
        }
    }

}
