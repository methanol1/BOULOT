package com.natixis.nie.hubis.features.simulation.web.dto;


import com.natixis.nie.hubis.core.domain.simulation.Remuneration;

public class RemunerationDTO {

    private int montantNet;
    private int chargesPatronales;
    private int chargesSociales;
    private int csgCrds;
    private int impotsRevenu;

    public int getMontantNet() {
        return montantNet;
    }

    public void setMontantNet(int montantNet) {
        this.montantNet = montantNet;
    }

    public int getChargesPatronales() {
        return chargesPatronales;
    }

    public void setChargesPatronales(int chargesPatronales) {
        this.chargesPatronales = chargesPatronales;
    }

    public int getChargesSociales() {
        return chargesSociales;
    }

    public void setChargesSociales(int chargesSalariales) {
        this.chargesSociales = chargesSalariales;
    }

    public int getCsgCrds() {
        return csgCrds;
    }

    public void setCsgCrds(int cotisationsSociales) {
        this.csgCrds = cotisationsSociales;
    }

    public int getImpotsRevenu() {
        return impotsRevenu;
    }

    public void setImpotsRevenu(int impotsRevenu) {
        this.impotsRevenu = impotsRevenu;
    }

    public static RemunerationDTO fromModel(Remuneration r) {
        RemunerationDTO dto = new RemunerationDTO();
        dto.setChargesPatronales(r.getChargesPatronales());
        dto.setChargesSociales(r.getChargesSociales());
        dto.setChargesPatronales(r.getChargesPatronales());
        dto.setCsgCrds(r.getCsgCrds());
        dto.setImpotsRevenu(r.getImpotsRevenu());
        dto.setMontantNet(r.getMontantNet());
        return dto;
    }
}
