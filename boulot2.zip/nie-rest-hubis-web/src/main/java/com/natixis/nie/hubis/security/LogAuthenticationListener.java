package com.natixis.nie.hubis.security;

import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationListener;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.subject.PrincipalCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


class LogAuthenticationListener implements AuthenticationListener {

    private final static Logger logger = LoggerFactory.getLogger(LogAuthenticationListener.class);

    @Override
    public void onSuccess(AuthenticationToken token, AuthenticationInfo info) {
        logger.info("User {} has been successfully authenticated", token.getPrincipal());

    }

    @Override
    public void onFailure(AuthenticationToken token, AuthenticationException ae) {

    }

    @Override
    public void onLogout(PrincipalCollection principals) {
        logger.info("User {} been has logged out", principals.getPrimaryPrincipal());
    }
}
