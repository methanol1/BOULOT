package com.natixis.nie.hubis.core;

import com.natixis.nie.hubis.core.domain.Document;
import com.natixis.nie.hubis.core.domain.SignatureTransaction;
import com.natixis.nie.hubis.core.domain.User;

public interface SignatureService {

    SignatureTransaction createTransactionSignature(User user, byte[] docToSign);

    Document finishTransaction(SignatureTransaction signatureTransaction);
}
