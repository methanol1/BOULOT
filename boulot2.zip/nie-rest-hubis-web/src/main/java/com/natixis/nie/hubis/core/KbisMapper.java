package com.natixis.nie.hubis.core;

import com.natixis.nie.hubis.core.domain.kbis.Kbis;

import java.util.Optional;


public interface KbisMapper {

    Optional<Kbis> map(String xml);
}
