package com.natixis.nie.hubis.features.simulation.web.dto;


import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.natixis.nie.hubis.core.domain.simulation.Cesu;
import com.natixis.nie.hubis.core.domain.simulation.Epargne;
import com.natixis.nie.hubis.core.domain.simulation.Simulation;
import com.natixis.nie.hubis.core.domain.simulation.SimulationCriteria;
import com.natixis.nie.hubis.features.simulation.SimulationService;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

public class NewSimulationDTO {

    @NotNull
    @Valid
    private final CartDTO cart;

    @NotNull
    @Valid
    private final SimulationCriteriaDTO simulationCriteria;

    @JsonCreator
    public NewSimulationDTO(@JsonProperty("simulationCriteria") SimulationCriteriaDTO simulationCriteria, @JsonProperty("cart") CartDTO cart) {
        this.cart = cart;
        this.simulationCriteria = simulationCriteria;
    }

    public CartDTO getCart() {
        return cart;
    }

    public SimulationCriteriaDTO getSimulationCriteria() {
        return simulationCriteria;
    }

    @Override
    public String toString() {
        return "ContratDTO{" +
                "cart=" + cart +
                ", simulationCriteria=" + simulationCriteria +
                '}';
    }

    public static NewSimulationDTO fromModel(Simulation simulation) {
        SimulationCriteria criteria = simulation.getSimulationCriteria();
        SimulationCriteriaDTO simulationCriteriaDTO = new SimulationCriteriaDTO(criteria.isDirigeantSalarie(), criteria.hasSalaries());
        CartDTO cartDTO = new CartDTO();
        cartDTO.setChosenEpargneVersement(simulation.getEpargne().map(Epargne::getVersement).orElse(0));
        cartDTO.setChosenCesuVersement(simulation.getCesu().map(Cesu::getVersement).orElse(0));
        return new NewSimulationDTO(simulationCriteriaDTO, cartDTO);

    }

    public static Simulation toModel(NewSimulationDTO dto, SimulationService simulationService) {
        CartDTO cart = dto.getCart();
        SimulationCriteriaDTO criteriaDTO = dto.getSimulationCriteria();
        SimulationCriteria criteria = criteriaDTO.toModel(simulationService.getDefaultSimulationsDatas());
        return simulationService.build(criteria, cart.getChosenEpargneVersement(), cart.getChosenCesuVersement());
    }
}
