package com.natixis.nie.hubis.core.domain.simulation;

import com.natixis.nie.hubis.core.AppProperties;


public class SimulationsDatas {

    private double forfaitSocialPEI;
    private double forfaitSocialPERCOI;
    private double plafondPEI;
    private double plafondPERCOI;
    private int plafondSecuPASS;
    private double tauxCSG_CRDS;
    private double deductionCSG_CRDS;
    private double assieteCSG_CRDS;
    private double chargesPatronales;
    private double chargesSociales;
    private double chargesSalariales;
    private double tauxAbattement;
    private double tauxImposition;
    private double tauxAbondement;
    private double tauxCreditImpot;

    public double getForfaitSocialPEI() {
        return forfaitSocialPEI;
    }

    public double getForfaitSocialPERCOI() {
        return forfaitSocialPERCOI;
    }

    public double getPlafondPEI() {
        return plafondPEI;
    }

    public double getPlafondPERCOI() {
        return plafondPERCOI;
    }

    public int getPASS() {
        return plafondSecuPASS;
    }

    public double getTauxCSG_CRDS() {
        return tauxCSG_CRDS;
    }

    public double getDeductionCSG_CRDS() {
        return deductionCSG_CRDS;
    }

    public double getAssieteCSG_CRDS() {
        return assieteCSG_CRDS;
    }

    public double getChargesPatronales() {
        return chargesPatronales;
    }

    public double getChargesSociales() {
        return chargesSociales;
    }

    public double getChargesSalariales() {
        return chargesSalariales;
    }

    public double getTauxAbattement() {
        return tauxAbattement;
    }

    public double getTauxImposition() {
        return tauxImposition;
    }

    public double getTauxAbondement() {
        return tauxAbondement;
    }

    public double getTauxCreditImpot() {
        return tauxCreditImpot;
    }

    private SimulationsDatas() {
    }

    public static class Builder {

        private final double plafondPERCOI;
        private double forfaitSocialPEI;
        private double forfaitSocialPERCOI;
        private double plafondPEI;
        private int plafondSecuPASS;
        private double tauxCSG_CRDS;
        private double deductionCSG_CRDS;
        private double assieteCSG_CRDS;
        private double chargesPatronales;
        private double chargesSociales;
        private double chargesSalariales;
        private double tauxAbattement;
        private double tauxImposition;
        private double tauxAbondement;
        private double tauxCreditImpot;

        public Builder(AppProperties props) {
            this.forfaitSocialPEI = props.getDouble("simulation.forfait.social.pei");
            this.forfaitSocialPERCOI = props.getDouble("simulation.forfait.social.percoi");
            this.plafondPEI = props.getDouble("simulation.plafond.pei");
            this.plafondPERCOI = props.getDouble("simulation.plafond.percoi");
            this.plafondSecuPASS = props.getInt("simulation.pass.montant");
            this.tauxCSG_CRDS = props.getDouble("simulation.taux.csg.crds");
            this.assieteCSG_CRDS = props.getDouble("simulation.assiette.csg.crds");
            this.deductionCSG_CRDS = props.getDouble("simulation.taux.deduction.csg.crds");
            this.chargesPatronales = props.getDouble("simulation.charges.patronales");
            this.chargesSociales = props.getDouble("simulation.charges.sociales");
            this.chargesSalariales = props.getDouble("simulation.charges.salariales");
            this.tauxAbattement = props.getDouble("simulation.taux.abattement");
            this.tauxImposition = props.getDouble("simulation.taux.imposition");
            this.tauxAbondement = props.getDouble("simulation.taux.abondement");
            this.tauxCreditImpot = props.getDouble("simulation.credit.impots.cesu");
        }

        public SimulationsDatas build() {
            SimulationsDatas datas = new SimulationsDatas();
            datas.forfaitSocialPEI = forfaitSocialPEI;
            datas.forfaitSocialPERCOI = forfaitSocialPERCOI;
            datas.plafondPEI = plafondPEI;
            datas.plafondPERCOI = plafondPERCOI;
            datas.plafondSecuPASS = plafondSecuPASS;
            datas.tauxCSG_CRDS = tauxCSG_CRDS;
            datas.deductionCSG_CRDS = deductionCSG_CRDS;
            datas.assieteCSG_CRDS = assieteCSG_CRDS;
            datas.chargesPatronales = chargesPatronales;
            datas.chargesSociales = chargesSociales;
            datas.chargesSalariales = chargesSalariales;
            datas.tauxAbattement = tauxAbattement;
            datas.tauxImposition = tauxImposition;
            datas.tauxAbondement = tauxAbondement;
            datas.tauxCreditImpot = tauxCreditImpot;
            return datas;
        }
    }
}
