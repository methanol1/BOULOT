package com.natixis.nie.hubis.security;

import org.apache.shiro.authc.AuthenticationException;

class LockAuthenticationException extends AuthenticationException {
    public LockAuthenticationException(String message) {
        super(message);
    }
}
