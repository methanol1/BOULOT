package com.natixis.nie.hubis.web;


import com.natixis.nie.hubis.core.AppProperties;

import javax.inject.Inject;
import javax.servlet.*;
import java.io.IOException;

public class MDCFilter implements Filter {

    @Inject
    AppProperties appProperties;

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

        try {
            chain.doFilter(request, response);
        } finally {
        }
    }

    @Override
    public void destroy() {
    }

    @Override
    public void init(FilterConfig arg0) throws ServletException {
    }

}