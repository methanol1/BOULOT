package com.natixis.nie.hubis.web;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.HashMap;

@Path("/v1/ping")
@Produces({MediaType.APPLICATION_JSON})
@Api(value = "v1-ping",
        description = "A ping service to be able to check is server is alive")
public class PingResource extends AbstractRestResource {

    @GET
    @Path("/auth")
    @ApiOperation(value = "Test if server is alive with a pre-authenticated user")
    public Response authenticatedPing() {
        return Response.ok(new HashMap<String, String>()).build();
    }

    @GET
    @Path("/anonymous")
    @ApiOperation(value = "Test if server is alive with an anonymous")
    public Response anonymousPing() {
        HashMap<String, String> props = new HashMap<>();
        props.put("env", appProperties.getEnv());
        return Response.ok(props).build();
    }
}
