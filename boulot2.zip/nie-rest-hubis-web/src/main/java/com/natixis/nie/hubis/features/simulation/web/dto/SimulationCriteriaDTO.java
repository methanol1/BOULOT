package com.natixis.nie.hubis.features.simulation.web.dto;


import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.natixis.nie.hubis.core.domain.simulation.SimulationCriteria;
import com.natixis.nie.hubis.core.domain.simulation.SimulationsDatas;

import javax.ws.rs.QueryParam;

public class SimulationCriteriaDTO {

    @QueryParam("isDirigeantSalarie")
    private boolean isDirigeantSalarie;

    @QueryParam("hasSalaries")
    private boolean hasSalaries;

    public SimulationCriteriaDTO() {
        //Required by BeanParam annotation
    }

    @JsonCreator
    public SimulationCriteriaDTO(@JsonProperty("isDirigeantSalarie") boolean isDirigeantSalarie,
                                 @JsonProperty("hasSalaries") boolean hasSalaries) {
        this.isDirigeantSalarie = isDirigeantSalarie;
        this.hasSalaries = hasSalaries;
    }

    @JsonProperty("isDirigeantSalarie")
    public boolean isDirigeantSalarie() {
        return isDirigeantSalarie;
    }

    @JsonProperty("hasSalaries")
    public boolean hasSalaries() {
        return hasSalaries;
    }

    public SimulationCriteria toModel(SimulationsDatas simulationsDatas) {
        return new SimulationCriteria(isDirigeantSalarie, hasSalaries, simulationsDatas);
    }

    public static SimulationCriteriaDTO fromModel(SimulationCriteria c) {
        return new SimulationCriteriaDTO(c.isDirigeantSalarie(), c.hasSalaries());

    }
}
