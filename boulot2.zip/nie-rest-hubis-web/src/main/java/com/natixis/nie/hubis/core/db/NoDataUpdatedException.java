package com.natixis.nie.hubis.core.db;

import com.natixis.nie.hubis.core.exception.AppException;

public class NoDataUpdatedException extends AppException {

    public NoDataUpdatedException(String message) {
        super(message);
    }

    public NoDataUpdatedException(String message, Throwable cause) {
        super(message, cause);
    }
}
