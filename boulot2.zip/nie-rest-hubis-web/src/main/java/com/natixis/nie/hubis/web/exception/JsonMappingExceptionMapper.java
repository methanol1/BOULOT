package com.natixis.nie.hubis.web.exception;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.natixis.nie.hubis.web.Errors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;

import static com.natixis.nie.hubis.web.Errors.Type.INVALID_PARAMS;
import static javax.ws.rs.core.Response.Status.BAD_REQUEST;

@Provider
public class JsonMappingExceptionMapper extends com.fasterxml.jackson.jaxrs.base.JsonMappingExceptionMapper {

    private final static Logger logger = LoggerFactory.getLogger(JsonMappingExceptionMapper.class);

    @Override
    public Response toResponse(JsonMappingException exception) {

        String message = "An error has occurred when processing your parameters";

        logger.error(message, exception);

        return Response
                .status(BAD_REQUEST)
                .entity(Errors.error(INVALID_PARAMS, message))
                .build();
    }
}