package com.natixis.nie.hubis.core.domain.simulation;


public class Cesu {

    private final Integer versement;
    private final Remuneration remuneration;
    private final SimulationsDatas datas;
    private final SimulationCriteria criteria;

    public Cesu(int versement, SimulationCriteria criteria) {
        this.versement = versement;
        this.datas = criteria.getDatas();
        this.criteria = criteria;
        this.remuneration = new Remuneration(versement, criteria);
    }

    public int getVersement() {
        return versement;
    }

    public int getCreditImpot() {
        if (criteria.hasSalaries()) {
            return asInt(versement * datas.getTauxCreditImpot());
        }
        return 0;
    }

    public Remuneration getRemuneration() {
        return remuneration;
    }

    private int asInt(double d) {
        return Double.valueOf(d).intValue();
    }
}

