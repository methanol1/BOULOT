package com.natixis.nie.hubis.features.dimelo;

import com.natixis.nie.hubis.core.AppProperties;
import com.natixis.nie.hubis.core.Messages;
import com.natixis.nie.hubis.core.domain.User;
import com.natixis.nie.hubis.core.exception.AppException;
import com.natixis.nie.hubis.features.email.DimeloEmailTemplate;
import com.natixis.nie.hubis.features.email.EmailService;
import com.natixis.nie.hubis.security.AppSecurity;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import static com.natixis.nie.hubis.web.Errors.Type.INVALID_PARAMS;
import static com.natixis.nie.hubis.web.Errors.error;
import static javax.ws.rs.core.Response.Status.BAD_REQUEST;

@Path("/v1/dimelo")
@Produces({MediaType.APPLICATION_JSON})
@Consumes(MediaType.APPLICATION_JSON)
@Api(value = "v1-dimelo",
        description = "gstion formulaire de contact Dimelo",
        consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
public class DimeloResource {

    private final static Logger logger = LoggerFactory.getLogger(DimeloResource.class);

    @Inject
    AppProperties appProperties;

    @Inject
    EmailService emailService;

    @Inject
    Messages messages;

    @Inject
    AppSecurity appSecurity;

    @POST
    @Path("/webcallback")
    @ApiOperation(value = "Send a phone number to a web call back")
    public Response webcallback(DimeloDTO dimeloDTO) {
    	boolean isTempsReel;
        try {
            User user = null;
            if (appSecurity.isAuthenticated()) {
                user = appSecurity.getCurrentUser();
            }
            
            DimeloApiFetcher dimeloApiFetcher = new DimeloApiFetcher(appProperties);
            isTempsReel = dimeloApiFetcher.isTempsReel();
            
            if (isTempsReel) {
            	emailService.sendEmail(appProperties.get("dimelo.email.tpsreel"), new DimeloEmailTemplate(user, dimeloDTO.getTelephone()));
            } else {
            	emailService.sendEmail(appProperties.get("dimelo.email.differe"), new DimeloEmailTemplate(user, dimeloDTO.getTelephone()));
            }
            
        } catch (AppException e) {
            logger.error("Impossible d'envoyer un webcallback", e);
            return Response
                    .status(BAD_REQUEST)
                    .entity(error(INVALID_PARAMS, messages.get("dimelo.errors.sendmail")))
                    .build();
        }

        return Response.ok(isTempsReel).build();
    }

}
