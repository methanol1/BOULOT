package com.natixis.nie.hubis.features.dimelo;


import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.natixis.nie.hubis.web.validation.Validable;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

public class DimeloDTO implements Validable {

    @NotEmpty
    private final String telephone;

    @JsonCreator
    public DimeloDTO(@JsonProperty("telephone") String telephone) {
        this.telephone = telephone;
    }

    public String getTelephone() {
        return telephone;
    }
}
