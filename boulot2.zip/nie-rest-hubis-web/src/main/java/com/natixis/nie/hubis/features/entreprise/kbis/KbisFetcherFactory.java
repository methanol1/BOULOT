package com.natixis.nie.hubis.features.entreprise.kbis;

import com.natixis.nie.hubis.core.AppProperties;
import com.natixis.nie.hubis.core.CacheFactory;
import com.natixis.nie.hubis.core.Env;
import com.natixis.nie.hubis.core.KbisMapper;
import com.natixis.nie.hubis.features.entreprise.kbis.societe.ClasspathKbisFetcher;
import com.natixis.nie.hubis.features.entreprise.kbis.societe.HttpKbisFetcher;

import javax.enterprise.inject.Produces;
import javax.inject.Singleton;

@Singleton
class KbisFetcherFactory {

    @Produces
    @Singleton
    @Env
    public KbisFetcher createFetcher(AppProperties appProperties, CacheFactory cacheFactory, KbisMapper mapper) {

        if (appProperties.isLocal()) {
            return new ClasspathKbisFetcher(mapper);
        }
        return new HttpKbisFetcher(appProperties, cacheFactory, mapper);
    }
}
