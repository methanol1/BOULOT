package com.natixis.nie.hubis.security;

import com.natixis.nie.hubis.core.exception.AppException;

public class LockedUserException extends AppException {

    public LockedUserException(String message) {
        super(message);
    }

    public LockedUserException(String message, Throwable cause) {
        super(message, cause);
    }
}
