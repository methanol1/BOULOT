package com.natixis.nie.hubis.features.email;


import freemarker.template.Configuration;

public interface EmailTemplate {

    String getSubject();

    String getHtmlContent(Configuration config);
}
