package com.natixis.nie.hubis.security;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.natixis.nie.hubis.core.Messages;
import com.natixis.nie.hubis.web.Errors;
import com.natixis.nie.hubis.web.JacksonProvider;
import org.apache.shiro.web.filter.authc.AuthenticationFilter;
import org.apache.shiro.web.util.WebUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletResponse;

import static com.natixis.nie.hubis.web.Errors.Type.AUTH;
import static org.apache.shiro.web.util.WebUtils.toHttp;


public class AppSecurityFilter extends AuthenticationFilter {

    private final static Logger logger = LoggerFactory.getLogger(AppSecurityFilter.class);
    private final Messages messages;

    public AppSecurityFilter() {
        setLoginUrl("/rest/v1/auth/login");
        messages = new Messages();
    }

    @Override
    protected boolean onAccessDenied(javax.servlet.ServletRequest req, javax.servlet.ServletResponse resp) throws Exception {

        logger.error("User is not authorized to access to {}", WebUtils.toHttp(req).getRequestURL());

        HttpServletResponse response = toHttp(resp);
        response.setStatus(401);
        response.getWriter().write(createJsonManually());
        return false;
    }

    private String createJsonManually() throws JsonProcessingException {

        Errors error = Errors.error(AUTH, messages.get("auth.invalid.session"));
        return getMapper().writeValueAsString(error);
    }

    private ObjectMapper getMapper() {
        //This filter is instanciated outside Resteasy/CDI context.
        return JacksonProvider.MAPPER;
    }
}
