package com.natixis.nie.hubis.core.log;


import org.slf4j.MDC;

import java.util.Map;

/**
 * see http://logogin.blogspot.fr/2013/04/logback-mdc-and-executorservice.html
 */
public abstract class MDCAwareCallable implements Runnable {

    private final Map<String, String> parentContext;

    public MDCAwareCallable() {
        this.parentContext = MDC.getCopyOfContextMap();
    }

    @Override
    public void run() {

        Map<String, String> currentContext = MDC.getCopyOfContextMap();
        if (parentContext != null) {
            MDC.setContextMap(parentContext);
        }
        try {
            runWithMDC();
        } finally {
            if (currentContext != null) {
                MDC.setContextMap(currentContext);
            }
        }
    }

    public abstract void runWithMDC();
}