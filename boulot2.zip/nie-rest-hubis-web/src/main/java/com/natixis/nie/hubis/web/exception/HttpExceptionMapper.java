package com.natixis.nie.hubis.web.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

@Provider
public class HttpExceptionMapper implements ExceptionMapper<HttpException> {

    private final static Logger logger = LoggerFactory.getLogger(HttpExceptionMapper.class);

    @Override
    public Response toResponse(HttpException ex) {

        logger.error("Sending back a " + ex.getStatus() + " HTTP status code due to ", ex);

        return Response
                .status(ex.getStatus())
                .entity(ex.getErrors())
                .build();
    }
}