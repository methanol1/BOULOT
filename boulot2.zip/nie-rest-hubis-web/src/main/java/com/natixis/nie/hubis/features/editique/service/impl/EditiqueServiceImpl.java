package com.natixis.nie.hubis.features.editique.service.impl;

import com.natixis.nie.hubis.core.AppProperties;
import com.natixis.nie.hubis.core.EditiqueService;
import com.natixis.nie.hubis.core.domain.Entreprise;
import com.natixis.nie.hubis.core.domain.User;
import com.natixis.nie.hubis.core.domain.simulation.Cesu;
import com.natixis.nie.hubis.core.domain.simulation.Epargne;
import com.natixis.nie.hubis.core.domain.simulation.Simulation;
import com.natixis.nie.hubis.features.editique.bean.EditiqueBean;
import com.natixis.nie.hubis.features.editique.converter.EditiqueDocumentConverter;
import com.natixis.sphinx.reports.template.engine.sefas.SefasTemplate;
import com.natixis.sphinx.reports.template.engine.sefas.SefasTemplateEngine;
import nbp.framework.print.sefas.enveloppe_1.XMLElement;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.time.format.TextStyle;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

@Singleton
public class EditiqueServiceImpl implements EditiqueService {

    private static Logger logger = LoggerFactory.getLogger(EditiqueServiceImpl.class);
    private static final String YES = "O";
    private static final String NO = "N";
    private static String CODEMODELE = "tfeafb01";
    private static final String DOMAINE = "f";
    private static final String CODE_APPLICATION = "eaf";
    private static SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");
    private final AppProperties appProperties;

    @Inject
    public EditiqueServiceImpl(AppProperties appProperties) {
        this.appProperties = appProperties;
    }

    @Override
    public byte[] generatePdf(User user) {

        EditiqueBean aEditiqueBean = new EditiqueBean();
        buildEditiqueBean(aEditiqueBean, user);
        //getEditiqueBean(aEditiqueBean);

        final ByteArrayOutputStream lOutputStream = new ByteArrayOutputStream();

        XMLElement lElement = EditiqueDocumentConverter.convert(aEditiqueBean, CODEMODELE);

        // code pour générer le flux xml envoyer à Open print
//        try {
//            File file = new File("C:\\work\\test.xml");
//            JAXBContext jaxbContext = JAXBContext.newInstance(XMLElement.class);
//            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
//
//            // output pretty printed
//            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
//
//            jaxbMarshaller.marshal(lElement, file);
//            //jaxbMarshaller.marshal(lElement, System.out);
//
//        } catch (JAXBException e) {
//            e.printStackTrace();
//        }

        logger.info("Appel sefas : " + lElement);

        // Genere le PDF
        String lSefasUrl = appProperties.get("editique.wsdl.endpoint");
        SefasTemplateEngine lSefasTemplateEngine = new SefasTemplateEngine(lSefasUrl, null, "iso-8859-1", "iso-8859-1");
        Map<String, Object> technicalProperties = new HashMap<String, Object>();
        technicalProperties.put("V(codeDomaine)", DOMAINE);
        technicalProperties.put("V(codeApplication)", CODE_APPLICATION);
        technicalProperties.put("V(doubleComposition)", false);
        technicalProperties.put("V(batch)", false);
        lSefasTemplateEngine.setDebugMode(true);

        SefasTemplate sefasTemplate = new SefasTemplate(appProperties.get("editique.sefastemplate"), lSefasTemplateEngine, technicalProperties);

        sefasTemplate.generate(lOutputStream, Collections.<String, Object>singletonMap("model", lElement));
        return lOutputStream.toByteArray();
    }


    /**
     * Remplissage de l'objet editique Bean
     *
     * @param user
     */
    private void buildEditiqueBean(EditiqueBean aEditiqueBean, User user) {


        aEditiqueBean.setModel(CODEMODELE);
        Entreprise entreprise = user.getEntreprise();

        //Entreprise
        aEditiqueBean.setSiret(entreprise.getSiret().asString());
        aEditiqueBean.setRaisonSociale(entreprise.getRaisonSociale());
        aEditiqueBean.setFormeJuridique(entreprise.getFormeJuridique().getLabel());
        aEditiqueBean.setCodeNAF(entreprise.getNace().getCode());
        aEditiqueBean.setEffectifs(entreprise.getEffectif() + "");
        aEditiqueBean.setMoisCloture(entreprise.getMoisDeCloture().getDisplayName(TextStyle.FULL, Locale.FRANCE));
        aEditiqueBean.setAdresseEntreprise(entreprise.getAdresse().getRue());
        aEditiqueBean.setCodePostalEntreprise(entreprise.getAdresse().getCodePostal() + "");
        aEditiqueBean.setVilleEntreprise(entreprise.getAdresse().getVille());

        //Responsable légal
        aEditiqueBean.setDenomRespLegal(entreprise.getDirigeant().getFullname());
        aEditiqueBean.setFonction(entreprise.getDirigeant().getFonction());
        aEditiqueBean.setTelephone(entreprise.getDirigeant().getTelephone());
        aEditiqueBean.setAdresseRespLegal(entreprise.getDirigeant().getAdresse().getRue());
        aEditiqueBean.setCodePostalRespLegal(entreprise.getDirigeant().getAdresse().getCodePostal() + "");
        aEditiqueBean.setVilleRespLegal(entreprise.getDirigeant().getAdresse().getVille());
        aEditiqueBean.setEmail(user.getEmail());

        //Contrat
        aEditiqueBean.setAutreTeneur(entreprise.getNomDispositif().map(n -> YES).orElse(NO));
        if (entreprise.getNomDispositif().isPresent()) {
            aEditiqueBean.setNomAutreTeneur(entreprise.getNomDispositif().get());
        }

        //Simulation
        Simulation simulation = user.getSimulation();
        aEditiqueBean.setEpargneSalariale(simulation.getEpargne().map(e -> YES).orElse(NO));
        if (simulation.getEpargne().isPresent()) {
            Epargne epargne = simulation.getEpargne().get();
            aEditiqueBean.setPlafondPASS(epargne.getDatas().getPASS() / epargne.getVersement() + "");
            aEditiqueBean.setPlafondMontant(epargne.getAbondementBrut() + StringUtils.EMPTY);
        }

        aEditiqueBean.setCESU(simulation.getCesu().map(e -> YES).orElse(NO));
        if (simulation.getCesu().isPresent()) {
            Cesu cesu = simulation.getCesu().get();
            aEditiqueBean.setVersementMensuel("XXX");
            aEditiqueBean.setValeurCESU(cesu.getVersement() + StringUtils.EMPTY);
            aEditiqueBean.setDateSignature(DATE_FORMAT.format(simulation.getDateSignature()));
        }

        //Coordonnées bancaires
        aEditiqueBean.setBIC(entreprise.getBankData().getBic());
        aEditiqueBean.setIBAN(entreprise.getBankData().getIban());

        //Liens
        aEditiqueBean.setLienRatification(appProperties.get("editique.lien1"));
        aEditiqueBean.setLienReglementPlan(appProperties.get("editique.lien2"));
        aEditiqueBean.setLienReglementFonds(appProperties.get("editique.lien3"));
        aEditiqueBean.setLienConditionsGeneralesES(appProperties.get("editique.lien4"));
        aEditiqueBean.setLienAnnexeTarifaire(appProperties.get("editique.lien5"));
        aEditiqueBean.setLienContratEchange(appProperties.get("editique.lien6"));
        aEditiqueBean.setLienConditionsGeneralesCESU(appProperties.get("editique.lien7"));
        aEditiqueBean.setLibLienRatification(appProperties.get("editique.lien1lib"));
        aEditiqueBean.setLibLienReglementPlan(appProperties.get("editique.lien2lib"));
        aEditiqueBean.setLibLienReglementFonds(appProperties.get("editique.lien3lib"));
        aEditiqueBean.setLibLienConditionsGeneralesES(appProperties.get("editique.lien4lib"));
        aEditiqueBean.setLibLienAnnexeTarifaire(appProperties.get("editique.lien5lib"));
        aEditiqueBean.setLibLienContratEchange(appProperties.get("editique.lien6lib"));
        aEditiqueBean.setLibLienConditionsGeneralesCESU(appProperties.get("editique.lien7lib"));
    }


    /**
     * Méthode pour tester l'éditique
     * TODO à supprimer
     *
     * @param aEditiqueBean
     */
    private void getEditiqueBean(EditiqueBean aEditiqueBean) {
        aEditiqueBean.setModel(CODEMODELE);

        //Entreprise
        aEditiqueBean.setSiret("12345678901234");
        aEditiqueBean.setRaisonSociale("Blanchisserie Martin");
        aEditiqueBean.setFormeJuridique("Blanchisserie");
        aEditiqueBean.setCodeNAF("1234Z");
        aEditiqueBean.setEffectifs("14");
        aEditiqueBean.setMoisCloture("Décembre");
        aEditiqueBean.setAdresseEntreprise("1 avenue du mesnil");
        aEditiqueBean.setCodePostalEntreprise("99999");
        aEditiqueBean.setVilleEntreprise("Grande ville");

        //Responsable légal
        aEditiqueBean.setDenomRespLegal("Monsieur Jean-Luc Chollot");
        aEditiqueBean.setFonction("Gérant");
        aEditiqueBean.setTelephone("0612134547");
        aEditiqueBean.setAdresseRespLegal("1 avenue du mesnil domicile");
        aEditiqueBean.setCodePostalRespLegal("99999");
        aEditiqueBean.setVilleRespLegal("Grande ville");
        aEditiqueBean.setEmail("jeanluc.chollot@gmail.com");

        //Contrat
        aEditiqueBean.setAutreTeneur("O");
        aEditiqueBean.setNomAutreTeneur("Yomoni");
        aEditiqueBean.setPlafondMontant("9500");
        aEditiqueBean.setPlafondPASS("16");
        aEditiqueBean.setVersementMensuel("200");
        aEditiqueBean.setValeurCESU("1830");
        //TODO formatage date
        aEditiqueBean.setDateSignature("12/04/2016");
        aEditiqueBean.setEpargneSalariale("O");
        aEditiqueBean.setCESU("O");

        //Coordonnées bancaires
        aEditiqueBean.setBIC("DABAIE2D");
        aEditiqueBean.setIBAN("FR1420041010050500013M02606");

        //Liens
        aEditiqueBean.setLienRatification(appProperties.get("editique.lien1"));
        aEditiqueBean.setLienReglementPlan(appProperties.get("editique.lien2"));
        aEditiqueBean.setLienReglementFonds(appProperties.get("editique.lien3"));
        aEditiqueBean.setLienConditionsGeneralesES(appProperties.get("editique.lien4"));
        aEditiqueBean.setLienAnnexeTarifaire(appProperties.get("editique.lien5"));
        aEditiqueBean.setLienContratEchange(appProperties.get("editique.lien6"));
        aEditiqueBean.setLienConditionsGeneralesCESU(appProperties.get("editique.lien7"));
        aEditiqueBean.setLibLienRatification(appProperties.get("editique.lien1lib"));
        aEditiqueBean.setLibLienReglementPlan(appProperties.get("editique.lien2lib"));
        aEditiqueBean.setLibLienReglementFonds(appProperties.get("editique.lien3lib"));
        aEditiqueBean.setLibLienConditionsGeneralesES(appProperties.get("editique.lien4lib"));
        aEditiqueBean.setLibLienAnnexeTarifaire(appProperties.get("editique.lien5lib"));
        aEditiqueBean.setLibLienContratEchange(appProperties.get("editique.lien6lib"));
        aEditiqueBean.setLibLienConditionsGeneralesCESU(appProperties.get("editique.lien7lib"));

    }


}
