package com.natixis.nie.hubis.web;

import io.swagger.annotations.Api;
import io.swagger.jaxrs.Reader;
import io.swagger.jaxrs.config.ReaderConfigUtils;
import io.swagger.jaxrs.config.SwaggerContextService;
import io.swagger.models.Swagger;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import static com.natixis.nie.hubis.HubisApplication.findAppClassesAnnotatedWith;

@Path("/swagger")
public class SwaggerResource {

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    @Path("/swagger.json")
    public Response generateSwaggerJson(@Context ServletConfig sc, @Context ServletContext context) {

        Swagger swagger = new SwaggerContextService().withServletConfig(sc).getSwagger();
        swagger = getSwaggerForApi(swagger, context);

        if (swagger != null) {
            return Response.ok().entity(swagger).build();
        } else {
            return Response.status(404).build();
        }
    }

    private Swagger getSwaggerForApi(Swagger s, ServletContext context) {
        Reader reader = new Reader(s, ReaderConfigUtils.getReaderConfig(context));
        Swagger swagger = reader.read(findAppClassesAnnotatedWith(Api.class));
        swagger.setBasePath(context.getContextPath() + "/rest");
        return swagger;
    }
}
