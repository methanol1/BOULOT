package com.natixis.nie.hubis.web.exception;

import com.natixis.nie.hubis.web.Errors;

import javax.ws.rs.core.Response;

import static javax.ws.rs.core.Response.Status.INTERNAL_SERVER_ERROR;

public class HttpUnexpectedRequestException extends HttpException {

    public HttpUnexpectedRequestException(String message, Errors errors) {
        super(message, errors);
    }

    public HttpUnexpectedRequestException(String message, Throwable cause, Errors errors) {
        super(message, cause, errors);
    }

    public Response.Status getStatus() {
        return INTERNAL_SERVER_ERROR;
    }
}
