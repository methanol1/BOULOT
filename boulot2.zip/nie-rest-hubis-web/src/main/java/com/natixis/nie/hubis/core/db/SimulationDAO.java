package com.natixis.nie.hubis.core.db;


import com.natixis.nie.hubis.core.domain.StatutContrat;
import com.natixis.nie.hubis.core.domain.User;
import com.natixis.nie.hubis.core.domain.simulation.Cesu;
import com.natixis.nie.hubis.core.domain.simulation.Epargne;
import com.natixis.nie.hubis.core.domain.simulation.Simulation;
import com.natixis.nie.hubis.core.domain.simulation.SimulationCriteria;
import com.natixis.nie.hubis.features.simulation.SimulationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;

import javax.inject.Inject;
import javax.inject.Singleton;


@Singleton
public class SimulationDAO {

    private final static Logger logger = LoggerFactory.getLogger(SimulationDAO.class);

    private final DataSourceHandler dataSourceHandler;
    private final TransactionManager transactionManager;
    private final SimulationService simulationService;


    @Inject
    public SimulationDAO(TransactionManager transactionManager, SimulationService simulationService) {
        this.dataSourceHandler = transactionManager.getDataSourceHandler();
        this.transactionManager = transactionManager;
        this.simulationService = simulationService;
    }

    public Simulation findByUser(User user) {

        int userId = user.getId().asInt();

        return dataSourceHandler.getJdbcTemplate().queryForObject(
                "SELECT * " +
                        "FROM THUBCONTRAT " +
                        "INNER JOIN THUBUSER ON FK_THUB_CONTRAT_USER = ID_USER " +
                        "WHERE ID_USER = ?",
                new Object[]{userId},
                createSimulationRowMapper());
    }

    public RowMapper<Simulation> createSimulationRowMapper() {
        return (rs, rowNum) -> {
            SimulationCriteria criteria = new SimulationCriteria(rs.getBoolean("DIRIGEANT_SALARIE"), rs.getBoolean("SALARIE"), simulationService.getDefaultSimulationsDatas());
            return simulationService.build(criteria, rs.getInt("ES_VALEUR"), rs.getInt("CESU_VALEUR"));
        };
    }

    public void createOrUpdate(User user, Simulation simulation) {

        transactionManager.execute(new TransactionCallbackWithoutResult() {
            @Override
            protected void doInTransactionWithoutResult(TransactionStatus status) {

                int userId = user.getId().asInt();

                dataSourceHandler.getJdbcTemplate().update("DELETE FROM THUBCONTRAT WHERE FK_THUB_CONTRAT_USER = ?", new Object[]{userId});

                MapSqlParameterSource parameters = new MapSqlParameterSource();
                parameters.addValue("mntPlafond", simulation.getEpargne().map(Epargne::getVersement).orElse(0));
                parameters.addValue("valeurCESU", simulation.getCesu().map(Cesu::getVersement).orElse(0));
                parameters.addValue("mntPlafondPEI", simulation.getEpargne().map(Epargne::getMontantPlafondPEI).orElse(0.0));
                parameters.addValue("mntPlafondPERCOI", simulation.getEpargne().map(Epargne::getMontantPlafondPERCOI).orElse(0.0));
                parameters.addValue("dirigeantSalarie", simulation.getSimulationCriteria().isDirigeantSalarie());
                parameters.addValue("salarie", simulation.getSimulationCriteria().hasSalaries());
                parameters.addValue("dateSign", simulation.getDateSignature());
                parameters.addValue("statut", StatutContrat.NOUVEAU.name());
                parameters.addValue("userId", userId);

                int nbRowsAffected = dataSourceHandler.getNamedJdbcTemplate()
                        .update("INSERT INTO THUBCONTRAT (ES_VALEUR,CESU_VALEUR,PLF_PEI, PLF_PERCOI, DATE_SIGN,DIRIGEANT_SALARIE, SALARIE, STATE, FK_THUB_CONTRAT_USER)" +
                                        " VALUES (:mntPlafond,:valeurCESU,:mntPlafondPEI,:mntPlafondPERCOI,:dateSign,:dirigeantSalarie,:salarie,:statut, :userId)",
                                parameters);

                if (nbRowsAffected == 0) {
                    throw new NoDataUpdatedException("Unable to create contracte " + simulation.toString());
                }
            }
        });
    }
}
