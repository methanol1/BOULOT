package com.natixis.nie.hubis.features.signature;

import com.google.common.net.MediaType;
import com.natixis.nie.hubis.core.SignatureService;
import com.natixis.nie.hubis.core.domain.Document;
import com.natixis.nie.hubis.core.domain.SignatureTransaction;
import com.natixis.nie.hubis.core.domain.User;

import java.util.UUID;

import static com.natixis.nie.hubis.core.domain.DocumentType.CONVENTION;


public class FakeSignatureService implements SignatureService {

    @Override
    public SignatureTransaction createTransactionSignature(User user, byte[] docToSign) {
        return new SignatureTransaction(UUID.randomUUID().toString(), UUID.randomUUID().toString(), UUID.randomUUID().toString());
    }

    @Override
    public Document finishTransaction(SignatureTransaction signatureTransaction) {
        return new Document(CONVENTION, new byte[0], MediaType.PDF);
    }
}
