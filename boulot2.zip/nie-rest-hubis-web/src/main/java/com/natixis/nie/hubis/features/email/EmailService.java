package com.natixis.nie.hubis.features.email;


import com.natixis.nie.hubis.core.AppProperties;
import com.natixis.nie.hubis.core.Messages;
import com.natixis.nie.hubis.core.exception.AppException;
import com.natixis.nie.hubis.core.log.MDCAwareCallable;
import freemarker.template.Configuration;
import freemarker.template.TemplateExceptionHandler;
import org.apache.commons.mail.HtmlEmail;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.inject.Inject;
import javax.inject.Singleton;
import javax.mail.Session;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Singleton
public class EmailService {

    private final static Logger logger = LoggerFactory.getLogger(EmailService.class);

    @Resource(name = "mail/session")
    private Session mailSession;

    @Inject
    private Messages messages;

    @Inject
    private AppProperties appProperties;

    private Configuration cfg;
    private ExecutorService executorService;

    @PostConstruct
    public void init() throws IOException {
        cfg = new Configuration(Configuration.VERSION_2_3_22);
        cfg.setDirectoryForTemplateLoading(new ClassPathResource("emails").getFile());
        cfg.setDefaultEncoding("UTF-8");
        cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
        executorService = Executors.newSingleThreadExecutor();
    }

    public void sendEmail(String to, EmailTemplate template) {

        if (appProperties.isLocal() || appProperties.isDev()) {
            to = "test.nie.dev2@natixis.net";
        }
        if (appProperties.isQua() && !(template instanceof DimeloEmailTemplate)) {
            to = "hubishubishubis@gmail.com";
        }       

        logger.info("Sending email with subject {} to {}", template.getSubject(), to);

        try {
            HtmlEmail email = new HtmlEmail();
            email.setMailSession(mailSession);
            email.setSubject(template.getSubject());
            email.addTo(to);
            email.setHtmlMsg(template.getHtmlContent(cfg));
            email.setFrom(appProperties.get("smtp.emet"));
            email.send();
        } catch (Exception e) {
            throw new AppException("Unable to send email to " + to, e);
        }
    }

    public void sendEmailAsync(String to, EmailTemplate template) {

        executorService.submit(new MDCAwareCallable() {
            @Override
            public void runWithMDC() {
                try {
                    sendEmail(to, template);
                } catch (Exception e) {
                    logger.error("Unable send email {} for user {}", template.getSubject(), to, e);
                }
            }
        });
    }
}
