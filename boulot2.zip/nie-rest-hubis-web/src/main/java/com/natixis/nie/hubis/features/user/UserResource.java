package com.natixis.nie.hubis.features.user;

import com.natixis.nie.hubis.core.domain.User;
import com.natixis.nie.hubis.features.entreprise.web.dto.EntrepriseDTO;
import com.natixis.nie.hubis.features.simulation.web.dto.SimulationDTO;
import com.natixis.nie.hubis.features.user.dto.UserDTO;
import com.natixis.nie.hubis.web.AbstractRestResource;
import io.swagger.annotations.Api;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;

@Path("/v1/user")
@Produces({MediaType.APPLICATION_JSON})
@Consumes(MediaType.APPLICATION_JSON)
@Api(value = "v1-user",
        description = "Exposes services to retrieve user data",
        consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
public class UserResource extends AbstractRestResource {

    @GET
    @Path("/datas")
    public Response getUserDatas() throws IOException {

        User user = appSecurity.getCurrentUser();

        SimulationDTO simulationDTO = SimulationDTO.fromModel(user.getSimulation());
        EntrepriseDTO entrepriseDTO = user.getEntrepriseAsOptional()
                .map(EntrepriseDTO::fromModel)
                .orElse(null);

        return Response.ok(new UserDTO(simulationDTO, entrepriseDTO)).build();
    }
}
