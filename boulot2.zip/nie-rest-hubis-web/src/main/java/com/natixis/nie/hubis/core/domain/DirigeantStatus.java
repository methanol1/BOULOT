package com.natixis.nie.hubis.core.domain;


public enum DirigeantStatus {

    TNS, SALARIE;
}
