package com.natixis.nie.hubis.features.upload;

import com.natixis.nie.hubis.core.domain.Document;
import com.natixis.nie.hubis.core.domain.DocumentType;
import com.natixis.nie.hubis.core.exception.AppException;
import org.apache.commons.io.IOUtils;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

class MultipartFormDTO {

    public static Document toModel(DocumentType fileType, MultipartFormDataInput input) {

        Map<String, List<InputPart>> formDataMap = input.getFormDataMap();
        InputPart inputPart = formDataMap.get(fileType.name().toLowerCase()).get(0);
        InputStream inputStream;
        try {
            inputStream = inputPart.getBody(InputStream.class, null);
            byte[] bytes = IOUtils.toByteArray(inputStream);
            com.google.common.net.MediaType type = getMediaType(inputPart);
            return new Document(fileType, bytes, type);
        } catch (IOException e) {
            throw new AppException("Unable to read body for input part named " + fileType, e);
        }
    }

    public static com.google.common.net.MediaType getMediaType(InputPart inputPart) {
        return com.google.common.net.MediaType.parse(inputPart.getMediaType().toString());
    }
}
