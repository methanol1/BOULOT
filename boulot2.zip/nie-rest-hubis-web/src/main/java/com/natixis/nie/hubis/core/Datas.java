package com.natixis.nie.hubis.core;


import com.natixis.nie.hubis.core.domain.FormeJuridique;
import com.natixis.nie.hubis.core.domain.Nace;

import java.util.List;

public interface Datas {

    List<FormeJuridique> findAllFormesJuridiques();

    List<Nace> findAllNaces();

}
