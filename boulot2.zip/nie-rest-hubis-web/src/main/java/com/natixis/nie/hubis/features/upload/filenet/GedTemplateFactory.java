package com.natixis.nie.hubis.features.upload.filenet;

import com.natixis.filenet.ged.j2c.ConnectionFactory;
import com.natixis.nie.hubis.core.AppProperties;
import com.natixis.nie.hubis.core.exception.AppException;
import com.natixis.sphinx.integration.filenet.ged.GedTemplate;
import com.natixis.sphinx.integration.filenet.ged.session.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.inject.Singleton;
import javax.naming.InitialContext;
import javax.naming.NamingException;

@Singleton
public class GedTemplateFactory {

    private final static Logger logger = LoggerFactory.getLogger(GedTemplateFactory.class);
    public static final String FILENET_CONNECTOR_JNDI_NAME = "eis/BizGed";

    AppProperties appProperties;

    @Inject
    public GedTemplateFactory(AppProperties appProperties) {
        this.appProperties = appProperties;
    }

    @Produces
    @Singleton
    public GedTemplate createGedTemplate() {
        return new GedTemplate(findSessionFactory());
    }

    private SessionFactory findSessionFactory() {
        try {
            Object lookup = new InitialContext().lookup(FILENET_CONNECTOR_JNDI_NAME);
            J2cSessionFactory sessionFactory = new J2cSessionFactory((ConnectionFactory) lookup);
            return sessionFactory;
        } catch (NamingException e) {
            logger.warn("Unable to find jndi resource " + FILENET_CONNECTOR_JNDI_NAME);
        }

        if (appProperties.isLocal()) {
            return createFallbackSessionFactory();
        } else {
            throw new AppException("Unable a fallback SessionFactory in a non dev environment");
        }
    }

    public static SessionFactory createFallbackSessionFactory() {
        DefaultSessionFactoryInfo info = new DefaultSessionFactoryInfo();
        info.setRemoteServerUrl("http://sfb.gedworkplace.dev.intranatixis.com/wsi/FNCEWS40MTOM");
        info.setRemoteServerUploadUrl("http://sfb.gedworkplace.dev.intranatixis.com/wsi/FNCEWS40MTOM");
        info.setRemoteServerDownloadUrl("http://sfb.gedworkplace.dev.intranatixis.com/wsi/FNCEWS40MTOM");
        info.setAuthenticationMethod("FileNetP8WSI");
        info.setUser("ugp_v26_filenet");
        info.setAppId("hubis");
        info.setPassword("pctG;K45");
        info.setObjectStoreName("DEM_000");
        info.setDomainName("SFB-SOCLEGED-DEV");
        info.setStateHolder(new JseStateHolder());
        return new DefaultSessionFactory(info);
    }
}
