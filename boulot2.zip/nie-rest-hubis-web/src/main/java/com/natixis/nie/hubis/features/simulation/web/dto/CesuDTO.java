package com.natixis.nie.hubis.features.simulation.web.dto;


import com.natixis.nie.hubis.core.domain.simulation.Cesu;

public class CesuDTO {

    private int versement;
    private int creditImpot;
    private RemunerationDTO remuneration;

    public int getVersement() {
        return versement;
    }

    public void setVersement(int versement) {
        this.versement = versement;
    }

    public int getCreditImpot() {
        return creditImpot;
    }

    public void setCreditImpot(int creditImpot) {
        this.creditImpot = creditImpot;
    }

    public RemunerationDTO getRemuneration() {
        return remuneration;
    }

    public void setRemuneration(RemunerationDTO remuneration) {
        this.remuneration = remuneration;
    }

    public static CesuDTO fromModel(Cesu cesu) {
        CesuDTO dto = new CesuDTO();
        dto.setVersement(cesu.getVersement());
        dto.setRemuneration(RemunerationDTO.fromModel(cesu.getRemuneration()));
        dto.setCreditImpot(cesu.getCreditImpot());
        return dto;
    }

    @Override
    public String toString() {
        return "CesuDTO{" +
                "versement=" + versement +
                ", remuneration=" + remuneration +
                ", creditImpot=" + creditImpot +
                '}';
    }
}
