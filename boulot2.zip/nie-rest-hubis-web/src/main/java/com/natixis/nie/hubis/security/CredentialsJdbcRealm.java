package com.natixis.nie.hubis.security;

import org.apache.shiro.authc.*;
import org.apache.shiro.authc.credential.CredentialsMatcher;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CredentialsJdbcRealm extends AuthorizingRealm {

    private final static Logger logger = LoggerFactory.getLogger(CredentialsJdbcRealm.class);
    private final CredentialsDAO credentialsDAO;

    public CredentialsJdbcRealm(CredentialsDAO credentialsDAO, CredentialsMatcher credentialsMatcher) {
        this.credentialsDAO = credentialsDAO;
        setCredentialsMatcher(credentialsMatcher);
        setAuthenticationCachingEnabled(false);
        setAuthorizationCachingEnabled(false);
    }

    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken t) throws AuthenticationException {

        String email = extractEmail(t);

        UserStatus status = credentialsDAO.findSaltedPassword(email);

        if (status.isLocked()) {
            throw new LockAuthenticationException("User is locked");
        }
        return createAuthenticationInfo(email, status.getSaltedPassword());
    }

    @Override
    protected void assertCredentialsMatch(AuthenticationToken token, AuthenticationInfo info) throws AuthenticationException {
        String email = extractEmail(token);
        try {
            super.assertCredentialsMatch(token, info);
        } catch (AuthenticationException e) {
            logger.info("Increment nb tries of user {}", email);
            credentialsDAO.incrementTries(email);
            throw e;
        }
    }

    private SimpleAuthenticationInfo createAuthenticationInfo(String username, String password) {
        return new SimpleAuthenticationInfo(username, password, getName());
    }

    private String extractEmail(AuthenticationToken t) {
        return ((UsernamePasswordToken) t).getUsername();
    }

}
