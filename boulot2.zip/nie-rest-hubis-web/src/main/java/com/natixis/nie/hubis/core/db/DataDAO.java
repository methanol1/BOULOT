package com.natixis.nie.hubis.core.db;


import com.google.common.cache.LoadingCache;
import com.natixis.nie.hubis.core.AppProperties;
import com.natixis.nie.hubis.core.CacheFactory;
import com.natixis.nie.hubis.core.Datas;
import com.natixis.nie.hubis.core.domain.FormeJuridique;
import com.natixis.nie.hubis.core.domain.Nace;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.util.List;
import java.util.concurrent.ExecutionException;

@Singleton
public class DataDAO implements Datas {

    private final static Logger logger = LoggerFactory.getLogger(Datas.class);

    private final DataSourceHandler dataSourceHandler;
    private final LoadingCache<String, List<FormeJuridique>> formesJuridiquesCache;
    private final LoadingCache<String, List<Nace>> nacesCache;

    @Inject
    public DataDAO(DataSourceHandler dataSourceHandler, CacheFactory cacheFactory, AppProperties appProperties) {
        String spec = appProperties.get("cache.spec.datas");

        this.dataSourceHandler = dataSourceHandler;

        this.formesJuridiquesCache = cacheFactory.createCache("formesJuridiques", spec, s -> {
            logger.debug("Trying to retrieve all formes juridiques...");
            List<FormeJuridique> results = this.dataSourceHandler.getJdbcTemplate().query("SELECT ID_FORME, LIBELLE_FORME, STATUT_OBLIG FROM THUBFORMEJURIDIQUE",
                    (rs, rowNum) -> {
                        return new FormeJuridique(rs.getInt("ID_FORME"), rs.getString("LIBELLE_FORME"), rs.getBoolean("STATUT_OBLIG"));
                    });
            logger.debug("{} formes juridiques has been found", results.size());
            return results;
        });

        this.nacesCache = cacheFactory.createCache("naces", spec, s -> {
            logger.debug("Trying to retrieve all nace codes...");
            List<Nace> results = this.dataSourceHandler.getJdbcTemplate().query("SELECT CODE_NACE, LIBELLE_NACE, ETATFIN_OBLIG FROM THUBNACE",
                    (rs, rowNum) -> {
                        return new Nace(rs.getString("CODE_NACE"), rs.getString("LIBELLE_NACE"), rs.getBoolean("ETATFIN_OBLIG"));
                    });
            logger.debug("{} naces codes has been found", results.size());
            return results;
        });
    }


    public List<FormeJuridique> findAllFormesJuridiques() {
        try {
            return formesJuridiquesCache.get("all");
        } catch (ExecutionException e) {
            throw new RuntimeException("Unable to load formes juridiques", e);
        }
    }

    public List<Nace> findAllNaces() {
        try {
            return nacesCache.get("all");
        } catch (ExecutionException e) {
            throw new RuntimeException("Unable to load formes juridiques", e);
        }
    }

}
