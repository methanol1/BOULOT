package com.natixis.nie.hubis.core.domain.kbis;

public class DirigeantInfos {

    private String fullname;
    private String fonction;

    public DirigeantInfos(String fullname, String fonction) {
        this.fullname = fullname;
        this.fonction = fonction;
    }

    public String getFullname() {
        return fullname;
    }

    public String getFonction() {
        return fonction;
    }
}
