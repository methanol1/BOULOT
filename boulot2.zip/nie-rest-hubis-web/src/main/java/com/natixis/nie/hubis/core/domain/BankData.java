package com.natixis.nie.hubis.core.domain;


import org.apache.commons.lang3.StringUtils;

public class BankData {

    private String bic;
    private String iban;
    private final String telephone;
    private final String agence;

    public BankData(String bic, String iban, String telephone, String agence) {
        this.bic = bic;
        this.iban = iban;
        this.telephone = telephone;
        this.agence = agence;
    }

    public String getBic() {
        return bic;
    }

    public String getIban() {
        return iban;
    }

    public String getEncryptedIban() {
        String overlay = StringUtils.overlay(iban, "**", 7, 9);
        overlay = StringUtils.overlay(overlay, "**", 12, 14);
        return StringUtils.overlay(overlay, StringUtils.repeat("*", iban.length() - 23), 23, iban.length());
    }

    public String getTelephone() {
        return telephone;
    }

    public String getAgence() {
        return agence;
    }

    public boolean isIbanEncrypted() {
        return iban.contains("*");
    }
}
