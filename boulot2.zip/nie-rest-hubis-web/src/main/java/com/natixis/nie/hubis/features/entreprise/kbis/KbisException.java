package com.natixis.nie.hubis.features.entreprise.kbis;


public class KbisException extends Exception {

    public KbisException(String message) {
        super(message);
    }

    public KbisException(String message, Throwable cause) {
        super(message, cause);
    }
}
