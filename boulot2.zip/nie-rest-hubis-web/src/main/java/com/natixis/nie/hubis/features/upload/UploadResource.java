package com.natixis.nie.hubis.features.upload;

import com.google.common.collect.Lists;
import com.natixis.nie.hubis.core.SouscriptionService;
import com.natixis.nie.hubis.core.domain.Document;
import com.natixis.nie.hubis.core.domain.DocumentType;
import com.natixis.nie.hubis.core.domain.State;
import com.natixis.nie.hubis.core.domain.User;
import com.natixis.nie.hubis.security.AppSecurity;
import com.natixis.nie.hubis.web.AbstractRestResource;
import com.natixis.nie.hubis.web.exception.HttpBadRequestException;
import io.swagger.annotations.Api;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.google.common.collect.Lists.newArrayList;
import static com.natixis.nie.hubis.core.domain.State.UPLOAD;
import static com.natixis.nie.hubis.web.Errors.Type.INVALID_CONTENT;
import static com.natixis.nie.hubis.web.Errors.Type.MISSING_FILES;
import static com.natixis.nie.hubis.web.Errors.error;


@Api(value = "v1-upload",
        description = "Allows user to upload documents",
        consumes = MediaType.MULTIPART_FORM_DATA,
        produces = MediaType.APPLICATION_JSON)
public class UploadResource extends AbstractRestResource {

    @Inject
    SouscriptionService souscriptionService;

    @Inject
    AppSecurity appSecurity;

    @POST
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces({MediaType.APPLICATION_JSON})
    public Response upload(MultipartFormDataInput input) throws IOException {

        User user = appSecurity.getCurrentUserForState(UPLOAD);

        if (input.getFormDataMap().containsKey("secu")) {

            if (!hasRequiredPartsSecu(input)) {
                throw new HttpBadRequestException("Few uploaded files are missing", error(MISSING_FILES, "Invalid files"));
            }

            StringBuilder builder = new StringBuilder();
            List<InputPart> inputParts = input.getFormDataMap().get("secu");

            for (InputPart inputPart : inputParts) {
                builder.append(inputPart.getBody(String.class, null));
            }

            souscriptionService.insertNumSecuDirigeant(user, builder.toString());
        }


        List<Document> documents = new ArrayList<>();

        if (input.getFormDataMap().containsKey("identity_verso")) {

            if (!hasRequiredPartsCI(input)) {
                throw new HttpBadRequestException("Few uploaded files are missing", error(MISSING_FILES, "Invalid files"));
            }

            Document identityRecto = MultipartFormDTO.toModel(DocumentType.IDENTITY_RECTO, input);
            Document identityVerso = MultipartFormDTO.toModel(DocumentType.IDENTITY_VERSO, input);
            Document invoice = MultipartFormDTO.toModel(DocumentType.INVOICE, input);

            if (!invoice.isValid() || !identityRecto.isValid() || !identityVerso.isValid()) {
                throw new HttpBadRequestException("Uploaded files seems not valid", error(INVALID_CONTENT, "Invalid files"));
            }

            documents.addAll(Lists.newArrayList(identityRecto, identityVerso, invoice));

        } else if (hasRequiredPartsPassport(input)) {

            if (!hasRequiredPartsPassport(input)) {
                throw new HttpBadRequestException("Few uploaded files are missing", error(MISSING_FILES, "Invalid files"));
            }

            Document passport = MultipartFormDTO.toModel(DocumentType.IDENTITY_RECTO, input);
            Document invoice = MultipartFormDTO.toModel(DocumentType.INVOICE, input);

            if (!invoice.isValid() || !passport.isValid()) {
                throw new HttpBadRequestException("Uploaded files seems not valid", error(INVALID_CONTENT, "Invalid files"));
            }

            documents.addAll(Lists.newArrayList(passport, invoice));
        } else {
            throw new HttpBadRequestException("Uploaded files seems not valid", error(MISSING_FILES, "Invalid files"));
        }

        if (hasRequiredPartsLiasse(input)) {

            Document liasse = MultipartFormDTO.toModel(DocumentType.LIASSE, input);

            if (!liasse.isValid()) {
                throw new HttpBadRequestException("Uploaded files seems not valid", error(INVALID_CONTENT, "Invalid files"));
            }

            documents.addAll(Lists.newArrayList(liasse));
        }

        if (hasRequiredPartsStatus(input)) {
            Document statut = MultipartFormDTO.toModel(DocumentType.STATUT, input);


            if (!statut.isValid()) {
                throw new HttpBadRequestException("Uploaded files seems not valid", error(INVALID_CONTENT, "Invalid files"));
            }

            documents.addAll(Lists.newArrayList(statut));
        }

        State state = souscriptionService.uploadFiles(user, documents.toArray(new Document[0]));

        return sendState(state);
    }

    private boolean hasRequiredPartsCI(MultipartFormDataInput input) {
        return newArrayList("identity_recto", "identity_verso", "invoice").stream().allMatch(k -> input.getFormDataMap().containsKey(k));
    }

    private boolean hasRequiredPartsPassport(MultipartFormDataInput input) {
        return newArrayList("identity_recto", "invoice").stream().allMatch(k -> input.getFormDataMap().containsKey(k));
    }

    private boolean hasRequiredPartsSecu(MultipartFormDataInput input) {
        return newArrayList("secu").stream().allMatch(k -> input.getFormDataMap().containsKey(k));
    }

    private boolean hasRequiredPartsLiasse(MultipartFormDataInput input) {
        return newArrayList("liasse").stream().allMatch(k -> input.getFormDataMap().containsKey(k));
    }

    private boolean hasRequiredPartsStatus(MultipartFormDataInput input) {
        return newArrayList("statut").stream().allMatch(k -> input.getFormDataMap().containsKey(k));
    }
}
