package com.natixis.nie.hubis.web.validation;


import org.jboss.resteasy.spi.HttpRequest;
import org.jboss.resteasy.spi.validation.GeneralValidator;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.ext.Provider;
import java.lang.reflect.Method;
import java.util.Set;
import java.util.stream.Collectors;

import static java.util.Arrays.stream;

@Provider
public class ValidatorContextResolver implements ContextResolver<GeneralValidator> {

    @Override
    public GeneralValidator getContext(Class<?> type) {
        return new CustomValidator();
    }

    private static class CustomValidator implements GeneralValidator {

        private final static String VIOLATIONS_REQUEST_ATTRIBUTE = CustomValidator.class.getName();
        public static final Class<Validable> MARKER_INTERFACE = Validable.class;

        @Override
        public void validate(HttpRequest request, Object object, Class<?>... groups) {
            validateAll(request, object);
        }

        @Override
        public void validateAllParameters(HttpRequest request, Object object, Method method, Object[] parameterValues, Class<?>... groups) {
            validateAll(request, parameterValues);
        }

        @Override
        public void validateReturnValue(HttpRequest request, Object object, Method method, Object returnValue, Class<?>... groups) {
            validateAll(request, object);
        }

        @Override
        public boolean isValidatable(Class<?> clazz) {
            return needValidation(clazz);
        }

        @Override
        public boolean isMethodValidatable(Method method) {
            return needValidation(method.getParameterTypes());
        }

        @Override
        @SuppressWarnings("unchecked")
        public void checkViolations(HttpRequest request) {
            Set<ConstraintViolation<Object>> violations = (Set<ConstraintViolation<Object>>) request.getAttribute(VIOLATIONS_REQUEST_ATTRIBUTE);
            if (violations.size() > 0) {
                throw new ConstraintViolationException("Validation error for request " + request.getUri().getAbsolutePath(), violations);
            }
        }

        private void validateAll(HttpRequest request, Object... parameterValues) {

            if (stream(parameterValues).anyMatch(o -> o == null)) {
                throw new IllegalArgumentException();
            }

            Set<ConstraintViolation<Object>> violations = stream(parameterValues)
                    .filter(o -> MARKER_INTERFACE.isAssignableFrom(o.getClass()))
                    .flatMap(o -> Validation.validator.validate(o).stream())
                    .collect(Collectors.toSet());

            request.setAttribute(VIOLATIONS_REQUEST_ATTRIBUTE, violations);
            checkViolations(request);
        }

        private boolean needValidation(Class<?>... classes) {
            return stream(classes).anyMatch(MARKER_INTERFACE::isAssignableFrom);
        }
    }
}
