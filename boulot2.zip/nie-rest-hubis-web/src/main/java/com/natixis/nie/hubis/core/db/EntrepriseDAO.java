package com.natixis.nie.hubis.core.db;


import com.natixis.nie.hubis.core.KbisMapper;
import com.natixis.nie.hubis.core.domain.*;
import com.natixis.nie.hubis.core.domain.kbis.Kbis;
import com.natixis.nie.hubis.core.exception.NoEntrepriseFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.jdbc.support.lob.DefaultLobHandler;
import org.springframework.jdbc.support.lob.LobHandler;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.time.*;
import java.util.Optional;

@Singleton
public class EntrepriseDAO {

    private final static Logger logger = LoggerFactory.getLogger(EntrepriseDAO.class);

    private final TransactionManager transactionManager;
    private final KbisMapper kbisMapper;
    private final DataSourceHandler dataSourceHandler;
    private final Ciphering ciphering;

    @Inject
    public EntrepriseDAO(TransactionManager transactionManager, KbisMapper kbisMapper) {
        this.dataSourceHandler = transactionManager.getDataSourceHandler();
        this.transactionManager = transactionManager;
        this.kbisMapper = kbisMapper;
        this.ciphering = new Ciphering();
    }

    public Entreprise findByUser(User user) {

        int userId = user.getId().asInt();
        logger.debug("Searching entreprise for user {}", userId);

        try {
            return dataSourceHandler.getJdbcTemplate().queryForObject(
                    "SELECT  e.RUE AS rue_entreprise, e.CODE_POSTAL AS code_postal_entreprise, e.VILLE AS ville_entreprise," +
                            "d.RUE AS rue_dirigeant, d.CODE_POSTAL AS code_postal_dirigeant ,d.VILLE AS ville_dirigeant," +
                            "e.*, d.*, n.*, f.* " +
                            "FROM THUBENTREPRISE e " +
                            "INNER JOIN THUBDIRIGEANT d ON FK_THUB_ENTREPRISE_DIRIGEANT = ID_DIRIGEANT " +
                            "INNER JOIN THUBNACE n ON FK_THUB_ENTREPRISE_NACE = CODE_NACE " +
                            "INNER JOIN THUBFORMEJURIDIQUE f ON FK_THUB_ENTREPRISE_FORME = ID_FORME " +
                            "INNER JOIN THUBUSER u ON FK_THUB_ENTREPRISE_USER = ID_USER " +
                            "WHERE ID_USER = ?",
                    new Object[]{userId},
                    createEntrepriseRowMapper());

        } catch (EmptyResultDataAccessException e) {
            throw new NoEntrepriseFoundException("Unable to find entreprise for user " + userId + ". Returning an empty optional", e);
        }
    }

    public void create(User user, Entreprise entreprise) {

        transactionManager.execute(new TransactionCallbackWithoutResult() {
            @Override
            protected void doInTransactionWithoutResult(TransactionStatus status) {

                BankData bankData = entreprise.getBankData();
                if (bankData.isIbanEncrypted()) {
                    bankData = findBankData(user);
                }
                deleteAll(user);
                Dirigeant dirigeant = entreprise.getDirigeant();
                insert(dirigeant);
                insert(entreprise, bankData, dirigeant.getIdOrFail(), user.getId());
            }
        });
    }

    private void insert(Entreprise entreprise, BankData bankData, Id dirigeantId, Id userId) {

        logger.debug("Adding new entreprise {}", entreprise);
        KeyHolder keyHolder = new GeneratedKeyHolder();
        Adresse adresse = entreprise.getAdresse();

        MapSqlParameterSource parameters = new MapSqlParameterSource();
        parameters.addValue("siret", entreprise.getSiret().asString());
        parameters.addValue("nomTeneurES", entreprise.getNomDispositif().orElse(null));
        parameters.addValue("effectif", entreprise.getEffectif());
        parameters.addValue("raisonSociale", entreprise.getRaisonSociale());
        parameters.addValue("formeJuridique", entreprise.getFormeJuridique().getId());
        parameters.addValue("nace", entreprise.getNace().getCode());
        parameters.addValue("moisCloture", entreprise.getMoisDeCloture().getValue());
        parameters.addValue("adresse", adresse.getRue());
        parameters.addValue("codePostal", adresse.getCodePostal());
        parameters.addValue("ville", adresse.getVille());
        parameters.addValue("kbis", entreprise.getKbis().map(Kbis::asXml).orElse(null), Types.CLOB);
        parameters.addValue("userId", userId.asInt());
        parameters.addValue("dirigeantId", dirigeantId.asInt());
        parameters.addValue("iban", ciphering.encrypt(bankData.getIban()));
        parameters.addValue("bic", ciphering.encrypt(bankData.getBic()));
        parameters.addValue("telAgence", bankData.getTelephone());
        parameters.addValue("nomAgence", bankData.getAgence());

        dataSourceHandler.getNamedJdbcTemplate()
                .update("INSERT INTO THUBENTREPRISE (SIRET,RAISON_SOCIALE,EFFECTIF,MOISCLOTURE,RUE,CODE_POSTAL,VILLE,IBAN,BIC,TEL_AGENCE,NOM_AGENCE,KBIS,TENEUR_ES,FK_THUB_ENTREPRISE_FORME,FK_THUB_ENTREPRISE_NACE,FK_THUB_ENTREPRISE_USER,FK_THUB_ENTREPRISE_DIRIGEANT)" +
                                " VALUES (:siret,:raisonSociale,:effectif,:moisCloture,:adresse,:codePostal,:ville,:iban,:bic,:telAgence,:nomAgence,:kbis,:nomTeneurES,:formeJuridique,:nace,:userId,:dirigeantId)",
                        parameters,
                        keyHolder, new String[]{"ID_ENTREPRISE"});
        entreprise.setId(new Id(keyHolder.getKey().intValue()));
    }

    private void insert(Dirigeant dirigeant) {
        logger.debug("Adding new dirigeant {}", dirigeant);

        KeyHolder keyHolder = new GeneratedKeyHolder();

        MapSqlParameterSource parameters = new MapSqlParameterSource();
        parameters.addValue("fullname", dirigeant.getFullname());
        parameters.addValue("fonction", dirigeant.getFonction());
        parameters.addValue("telephone", dirigeant.getTelephone());
        parameters.addValue("datenaiss", dirigeant.getDatenaissAsDate());
        Adresse adresse = dirigeant.getAdresse();
        parameters.addValue("adresse", adresse.getRue());
        parameters.addValue("codePostal", adresse.getCodePostal());
        parameters.addValue("ville", adresse.getVille());

        dataSourceHandler.getNamedJdbcTemplate()
                .update("INSERT INTO THUBDIRIGEANT (FULLNAME,FONCTION, TELEPHONE, DATENAISS,RUE,CODE_POSTAL,VILLE) VALUES (:fullname,:fonction,:telephone,:datenaiss,:adresse,:codePostal,:ville)",
                        parameters,
                        keyHolder, new String[]{"ID_DIRIGEANT"});

        dirigeant.setId(new Id(keyHolder.getKey().intValue()));
    }

    public void insertNumSecu(Integer idDirigent, String numSecu) {
        logger.debug("update  dirigeant with id  {}", idDirigent);

        MapSqlParameterSource parameters = new MapSqlParameterSource();
        parameters.addValue("numsecu", numSecu);
        parameters.addValue("iddirigeant", idDirigent);

        dataSourceHandler.getNamedJdbcTemplate()
                .update("UPDATE THUBDIRIGEANT SET NUMSECU = (:numsecu)  WHERE ID_DIRIGEANT = (:iddirigeant)",
                        parameters);
    }

    /**
     * This allow entreprise to be update with same method
     */
    private void deleteAll(User user) {
        logger.debug("Deleting old datas about entreprise for user {}", user.getId());
        Optional<Entreprise> entreprise = user.getEntrepriseAsOptional();
        if (entreprise.isPresent()) {
            Optional<Id> dirigeantId = entreprise.get().getDirigeant().getId();

            dataSourceHandler.getJdbcTemplate().update("DELETE FROM THUBENTREPRISE WHERE FK_THUB_ENTREPRISE_USER = ?", user.getId().asInt());
            dataSourceHandler.getJdbcTemplate().update("DELETE FROM THUBDIRIGEANT  WHERE ID_DIRIGEANT = ?", dirigeantId.get().asInt());
        }
    }

    private BankData findBankData(User user) {

        int userId = user.getId().asInt();

        try {
            return dataSourceHandler.getJdbcTemplate().queryForObject(
                    "SELECT IBAN,BIC,TEL_AGENCE,NOM_AGENCE " +
                            "FROM THUBENTREPRISE e " +
                            "INNER JOIN THUBUSER u ON FK_THUB_ENTREPRISE_USER = ID_USER " +
                            "WHERE ID_USER = ?",
                    new Object[]{userId},
                    createBankDataRowMapper());

        } catch (EmptyResultDataAccessException e) {
            throw new NoEntrepriseFoundException("Unable to find bank data for user " + userId + ". Returning an empty optional", e);
        }
    }

    private RowMapper<Dirigeant> createDirigeantRowMapper() {

        return (rs, rowNum) -> {

            java.sql.Date sqlDate = rs.getDate("DATENAISS");
            Instant instant = Instant.ofEpochMilli(sqlDate.getTime());
            LocalDate birthDate = LocalDateTime.ofInstant(instant, ZoneId.systemDefault()).toLocalDate();
            Adresse adresse = createAdresseRowMapper("dirigeant").mapRow(rs, rowNum);

            return Dirigeant.existingDirigeant(
                    rs.getInt("ID_DIRIGEANT"),
                    rs.getString("FULLNAME"),
                    rs.getString("FONCTION"),
                    rs.getString("TELEPHONE"),
                    birthDate,
                    adresse,
                    rs.getString("NUMSECU"));
        };
    }

    private RowMapper<Entreprise> createEntrepriseRowMapper() {


        return (rs, rowNum) -> {

            int id_entreprise = rs.getInt("ID_ENTREPRISE");
            Dirigeant dirigeant = createDirigeantRowMapper().mapRow(rs, rowNum);
            BankData bankData = createBankDataRowMapper().mapRow(rs, rowNum);
            Nace nace = new Nace(rs.getString("CODE_NACE"), rs.getString("LIBELLE_NACE"), rs.getBoolean("ETATFIN_OBLIG"));
            FormeJuridique formeJuridique = new FormeJuridique(rs.getInt("ID_FORME"), rs.getString("LIBELLE_FORME"), rs.getBoolean("STATUT_OBLIG"));
            Adresse adresse = createAdresseRowMapper("entreprise").mapRow(rs, rowNum);
            Month moiscloture = Month.of(rs.getInt("MOISCLOTURE"));
            Siret siret = new Siret(rs.getString("SIRET"));
            Kbis kbis = getKbis(rs);

            return new Entreprise(
                    new Id(id_entreprise),
                    siret,
                    rs.getString("RAISON_SOCIALE"),
                    formeJuridique,
                    nace,
                    adresse,
                    rs.getInt("EFFECTIF"),
                    moiscloture,
                    dirigeant,
                    bankData,
                    kbis,
                    rs.getString("TENEUR_ES"));
        };
    }

    private RowMapper<BankData> createBankDataRowMapper() {
        return (rs, rowNum) -> {
            return new BankData(ciphering.decrypt(rs.getBytes("BIC")), ciphering.decrypt(rs.getBytes("IBAN")), rs.getString("TEL_AGENCE"), rs.getString("NOM_AGENCE"));
        };
    }

    private RowMapper<Adresse> createAdresseRowMapper(String suffix) {
        return (rs, rowNum) -> {
            return new Adresse(rs.getString("rue_" + suffix), rs.getInt("code_postal_" + suffix), rs.getString("ville_" + suffix));
        };
    }


    private Kbis getKbis(ResultSet rs) throws SQLException {
        LobHandler lobHandler = new DefaultLobHandler();
        String xml = lobHandler.getClobAsString(rs, "KBIS");
        Kbis kbis = null;
        if (xml != null) {
            Optional<Kbis> mapped = kbisMapper.map(xml);
            if (mapped.isPresent()) {
                kbis = mapped.get();
            }
        }
        return kbis;
    }
}
