package com.natixis.nie.hubis.security;

import com.natixis.nie.hubis.core.exception.AppException;

public class InvalidCredentials extends AppException {

    public InvalidCredentials(String username) {
        super("Credentials for user " + username + " has been rejected");
    }

    public InvalidCredentials(String message, Throwable cause) {
        super(message, cause);
    }
}
