package com.natixis.nie.hubis.features.entreprise.kbis.societe;


import com.google.common.cache.LoadingCache;
import com.natixis.nie.hubis.core.AppProperties;
import com.natixis.nie.hubis.core.CacheFactory;
import com.natixis.nie.hubis.core.KbisMapper;
import com.natixis.nie.hubis.core.domain.Siret;
import com.natixis.nie.hubis.core.domain.kbis.Kbis;
import com.natixis.nie.hubis.features.entreprise.kbis.KbisException;
import com.natixis.nie.hubis.features.entreprise.kbis.KbisFetcher;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Optional;
import java.util.function.Function;

import static java.nio.charset.StandardCharsets.ISO_8859_1;

public class HttpKbisFetcher implements KbisFetcher {

    private final static Logger logger = LoggerFactory.getLogger(HttpKbisFetcher.class);

    private final LoadingCache<Siret, String> cache;
    private final KbisMapper mapper;
    private OkHttpClient client;
    private final String apiUrl;

    public HttpKbisFetcher(AppProperties appProperties, CacheFactory cacheFactory, KbisMapper mapper) {
        this.mapper = mapper;
        this.apiUrl = appProperties.get("societe.api.url");
        this.client = createClient(appProperties);

        String spec = appProperties.get("cache.spec.societe");
        this.cache = cacheFactory.createCache("societe", spec, createFetcherFunction());
    }

    @Override
    public Optional<Kbis> fetch(Siret siret) throws KbisException {
        try {
            String xml = cache.get(siret);
            return mapper.map(xml);
        } catch (Exception e) {
            throw new KbisException("Unable to resolve kbis for siret" + siret, e);
        }
    }

    private Function<Siret, String> createFetcherFunction() {
        return (Siret siret) -> {
            String siren = siret.getSiren();
            String url = apiUrl + "&siren=" + siren;

            logger.info("Requesting societe.com with siren {} and url {}", siren, url);
            Request request = new Request.Builder()
                    .url(url)
                    .get()
                    .build();

            try {
                Response response = client.newCall(request).execute();

                return new String(response.body().bytes(), ISO_8859_1);
            } catch (IOException e) {
                throw new RuntimeException("Unable to get xml reponse from societe.com for siren " + siret.asString(), e);
            }
        };
    }

    private OkHttpClient createClient(AppProperties appProperties) {
        String host = appProperties.get("proxy.host");
        int port = appProperties.getInt("proxy.port");

        OkHttpClient.Builder builder = new OkHttpClient.Builder().proxy(new Proxy(Proxy.Type.HTTP, new InetSocketAddress(host, port)));
        if (appProperties.isLocal()) {
            builder.sslSocketFactory(getUnsafeSSLSocketFactory());
        }

        return builder.build();
    }

    private static SSLSocketFactory getUnsafeSSLSocketFactory() {
        try {
            // Create a trust manager that does not validate certificate chains
            TrustManager tm = new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                }

                public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                }

                public X509Certificate[] getAcceptedIssuers() {
                    return null;
                }
            };

            // Install the all-trusting trust manager
            SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(null, new TrustManager[]{tm}, null);

            // Create an ssl socket factory with our all-trusting manager
            return sslContext.getSocketFactory();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
