package com.natixis.nie.hubis.core.db;

import com.natixis.nie.hubis.core.exception.AppException;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;


public class Ciphering {

    private static String IV = "AAAAAAAAAAAAAAAA";
    private static String encryptionKey = "hubis/sibuh!#;13";


    public byte[] encrypt(String plainText) {
        try {
            Cipher cipher = initCipher(Cipher.ENCRYPT_MODE);
            return cipher.doFinal(plainText.getBytes("UTF-8"));
        } catch (Exception e) {
            throw new AppException("Unable to encrypt value", e);
        }
    }

    public String decrypt(byte[] ciphered) {
        try {
            Cipher cipher = initCipher(Cipher.DECRYPT_MODE);
            return new String(cipher.doFinal(ciphered), "UTF-8");
        } catch (Exception e) {
            throw new AppException("Unable to decrypt value", e);
        }
    }

    private Cipher initCipher(int mode) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding", "SunJCE");
        SecretKeySpec key = new SecretKeySpec(encryptionKey.getBytes("UTF-8"), "AES");
        cipher.init(mode, key, new IvParameterSpec(IV.getBytes("UTF-8")));
        return cipher;
    }

}
