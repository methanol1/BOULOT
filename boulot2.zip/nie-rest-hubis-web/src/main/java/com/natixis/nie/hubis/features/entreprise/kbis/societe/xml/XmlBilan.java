package com.natixis.nie.hubis.features.entreprise.kbis.societe.xml;


import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.util.Date;

class XmlBilan {
    @XmlElement(name = "bildate")
    @XmlJavaTypeAdapter(DateAdapter.class)
    public Date dateFinExerc;
}
