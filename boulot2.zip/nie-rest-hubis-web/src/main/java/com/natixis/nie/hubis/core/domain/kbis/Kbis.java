package com.natixis.nie.hubis.core.domain.kbis;


import java.util.List;

public class Kbis {

    private String xml;
    private EntrepriseInfos entrepriseInfos;
    private List<DirigeantInfos> dirigeants;


    public Kbis(String xml, EntrepriseInfos entrepriseInfos, List<DirigeantInfos> dirigeants) {
        this.xml = xml;
        this.entrepriseInfos = entrepriseInfos;
        this.dirigeants = dirigeants;
    }

    public EntrepriseInfos getEntreprise() {
        return entrepriseInfos;
    }

    public List<DirigeantInfos> getDirigeants() {
        return dirigeants;
    }

    public String asXml() {
        return xml;
    }
}