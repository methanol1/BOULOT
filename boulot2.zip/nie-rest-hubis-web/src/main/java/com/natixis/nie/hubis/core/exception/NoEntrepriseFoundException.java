package com.natixis.nie.hubis.core.exception;

public class NoEntrepriseFoundException extends AppException {

    public NoEntrepriseFoundException(String message) {
        super(message);
    }

    public NoEntrepriseFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}
