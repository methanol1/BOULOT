package com.natixis.nie.hubis.web.dto;


import com.fasterxml.jackson.annotation.JacksonInject;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.natixis.nie.hubis.core.AppProperties;

public class AppPropertiesDTO {

    @JsonIgnore
    private AppProperties appProperties;
    private final boolean authenticated;

    @JsonCreator
    public AppPropertiesDTO(@JacksonInject AppProperties appProperties, @JsonProperty("authenticated") boolean authenticated) {
        this.appProperties = appProperties;
        this.authenticated = authenticated;
    }

    public String getAppEnv() {
        return appProperties.get("app.env");
    }

    public boolean isAuthenticated() {
        return authenticated;
    }
}
