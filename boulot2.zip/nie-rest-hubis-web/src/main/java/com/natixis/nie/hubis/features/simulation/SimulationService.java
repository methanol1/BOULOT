package com.natixis.nie.hubis.features.simulation;


import com.natixis.nie.hubis.core.AppProperties;
import com.natixis.nie.hubis.core.domain.simulation.*;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Singleton
public class SimulationService {

    private AppProperties appProperties;

    @Inject
    public SimulationService(AppProperties appProperties) {
        this.appProperties = appProperties;
    }

    public SimulationItems generateItems(SimulationCriteria criteria) {

        List<Epargne> epargnes = getAllowedVersementsForEpargne(criteria.getDatas())
                .stream()
                .map(versement -> computeEpargne(versement, criteria))
                .collect(Collectors.toList());

        List<Cesu> cesus = getAllowedVersementsForCESU()
                .stream()
                .map(versement -> computeCesu(versement, criteria))
                .collect(Collectors.toList());

        return new SimulationItems(epargnes, cesus);
    }

    public Simulation build(SimulationCriteria criteria, int epargneVersement, int cesuVersement) {

        SimulationItems results = generateItems(criteria);

        return new Simulation(criteria, results, epargneVersement, cesuVersement);
    }

    public SimulationsDatas getDefaultSimulationsDatas() {
        return new SimulationsDatas.Builder(appProperties).build();
    }

    private List<Integer> getAllowedVersementsForEpargne(SimulationsDatas datas) {
        return Arrays.stream(appProperties.get("simulation.epargne.allowed.versements").split(","))
                .map(v -> "Vmax".equals(v) ? computeVmax(datas) : Integer.valueOf(v))
                .collect(Collectors.toList());
    }

    private List<Integer> getAllowedVersementsForCESU() {
        return Arrays.stream(appProperties.get("simulation.cesu.allowed.versements").split(","))
                .map(Integer::valueOf)
                .collect(Collectors.toList());
    }

    private Epargne computeEpargne(int versement, SimulationCriteria criteria) {
        return new Epargne(versement, criteria);
    }

    private Cesu computeCesu(int versement, SimulationCriteria criteria) {
        return new Cesu(versement, criteria);
    }

    private static int computeVmax(SimulationsDatas datas) {
        double result = (datas.getPASS() * datas.getPlafondPEI()) * (1 + datas.getForfaitSocialPEI())
                + (datas.getPASS() * datas.getPlafondPERCOI()) * (1 + datas.getForfaitSocialPERCOI());

        return Double.valueOf(result).intValue();
    }
}
