package com.natixis.nie.hubis.features.user.dto;


import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.natixis.nie.hubis.web.validation.Validable;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class ResetPasswordDTO implements Validable {

    @NotEmpty
    private String resetKey;

    @NotEmpty
    @Size(min = 8)
    private String repeatPassword;

    @NotNull
    @Valid
    private RawCredentialsDTO credentials;

    @JsonCreator
    public ResetPasswordDTO(@JsonProperty("resetKey") String resetKey,
                            @JsonProperty("repeatPassword") String repeatPassword,
                            @JsonProperty("credentials") RawCredentialsDTO credentials) {
        this.resetKey = resetKey;
        this.repeatPassword = repeatPassword;
        this.credentials = credentials;
    }

    public String getResetKey() {
        return resetKey;
    }

    public RawCredentialsDTO getCredentials() {
        return credentials;
    }

    public String getRepeatPassword() {
        return repeatPassword;
    }

    @JsonIgnore
    public boolean isPasswordValid() {
        return credentials.getPassword().equals(repeatPassword);
    }
}
