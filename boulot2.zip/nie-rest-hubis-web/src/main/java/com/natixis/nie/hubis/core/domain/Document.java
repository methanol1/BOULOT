package com.natixis.nie.hubis.core.domain;


import com.google.common.net.MediaType;
import com.natixis.nie.hubis.web.validation.Validable;
import org.apache.commons.io.FileUtils;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.File;
import java.io.IOException;
import java.util.Optional;

import static com.google.common.net.MediaType.PDF;

public class Document implements Validable {

    private String id;

    @NotNull
    private final DocumentType fileType;

    @Size(max = 20480000)//20M
    private final byte[] bytes;

    @NotNull
    private final MediaType mediaType;

    public Document(DocumentType type, byte[] bytes, MediaType mediaType) {
        this.fileType = type;
        this.id = null;
        this.bytes = bytes;
        this.mediaType = mediaType;
    }

    public byte[] getBytes() {
        return bytes;
    }

    public int getSize() {
        return bytes.length;
    }

    public String getFilename() {
        return fileType.name().toLowerCase() + "." + mediaType.subtype();
    }

    public boolean isImage() {
        return mediaType.is(MediaType.ANY_IMAGE_TYPE);
    }

    public boolean isPDF() {
        return mediaType.is(PDF);
    }

    public void setId(String id) {
        this.id = id;
    }

    public Optional<String> getId() {
        return Optional.ofNullable(id);
    }

    public DocumentType getType() {
        return fileType;
    }

    public MediaType getMediaType() {
        return mediaType;
    }

    public File asFile() throws IOException {
        File asFile = new File(getFilename());
        FileUtils.writeByteArrayToFile(asFile, getBytes());
        return asFile;
    }

    public boolean hasBeenUploaded() {
        return id != null;
    }

    public DocumentMetadatas extractMetadatas() {
        if (!hasBeenUploaded()) {
            throw new IllegalStateException("Unable to build metadatas because document has not been uploaded yet. Please call hasBeenUploaded() before");
        }
        return new DocumentMetadatas(id, fileType, mediaType);
    }
}
