package com.natixis.nie.hubis.core;


import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Singleton;
import java.util.function.Function;

@Singleton
public class CacheFactory {

    private static final Logger logger = LoggerFactory.getLogger(CacheFactory.class);

    public <K, T> LoadingCache<K, T> createCache(String name, String spec, Function<K, T> loader) {

        logger.debug("Creating cache {} with spec {}", name, spec);

        return CacheBuilder
                .from(spec)
                .build(new CacheLoader<K, T>() {

                    @Override
                    public T load(K key) throws Exception {
                        return loader.apply(key);
                    }
                });
    }

}
