package com.natixis.nie.hubis.core.exception;


public class InvalidUserStateException extends AppException {

    public InvalidUserStateException(String message) {
        super(message);
    }

    public InvalidUserStateException(String message, Throwable cause) {
        super(message, cause);
    }
}
