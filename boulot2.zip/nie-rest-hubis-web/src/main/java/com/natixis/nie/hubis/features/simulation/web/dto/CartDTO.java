package com.natixis.nie.hubis.features.simulation.web.dto;

import com.natixis.nie.hubis.features.simulation.web.validation.NonEmptyCart;

@NonEmptyCart
public class CartDTO {

    private int chosenEpargneVersement;
    private int chosenCesuVersement;


    public int getChosenEpargneVersement() {
        return chosenEpargneVersement;
    }

    public int getChosenCesuVersement() {
        return chosenCesuVersement;
    }

    public void setChosenEpargneVersement(int chosenEpargneVersement) {
        this.chosenEpargneVersement = chosenEpargneVersement;
    }

    public void setChosenCesuVersement(int chosenCesuVersement) {
        this.chosenCesuVersement = chosenCesuVersement;
    }

    @Override
    public String toString() {
        return "CartDTO{" +
                "chosenEpargneVersement=" + chosenEpargneVersement +
                ", chosenCesuVersement=" + chosenCesuVersement +
                '}';
    }
}
