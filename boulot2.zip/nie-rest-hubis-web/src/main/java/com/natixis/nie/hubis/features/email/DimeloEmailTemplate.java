package com.natixis.nie.hubis.features.email;

import com.natixis.nie.hubis.core.domain.Entreprise;
import com.natixis.nie.hubis.core.domain.User;
import com.natixis.nie.hubis.core.exception.AppException;
import com.natixis.nie.hubis.core.exception.InvalidUserStateException;

import freemarker.template.Configuration;
import freemarker.template.Template;

import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

public class DimeloEmailTemplate implements EmailTemplate {

    private final User user;
    private final String telephone;

    public DimeloEmailTemplate(User user, String telephone) {
        this.user = user;
        this.telephone = telephone;
    }

    @Override
    public String getSubject() {
        return "Envoi mail Dimelo pour web call back";
    }

    @Override
    public String getHtmlContent(Configuration config) {
    	
        Map<String, String> model = new HashMap<>();
        
    	if (user != null) {
            model.put("email", user.getEmail());
            
            try {
                Entreprise entreprise = user.getEntreprise();
                model.put("company", entreprise.getRaisonSociale());
                model.put("username", entreprise.getDirigeant().getFullname());					
    		} catch (InvalidUserStateException lE) {
            	model.put("company", "");
            	model.put("username", "");
    		}
        } else {
        	model.put("email", "");
        	model.put("company", "");
        	model.put("username", "");
        }
        
        model.put("mobile_phone", telephone);
        
        try {
            Template template = config.getTemplate("dimelo.ftl");
            StringWriter output = new StringWriter();
            template.process(model, output);
            return output.toString();

        } catch (Exception e) {
            throw new AppException("Unable to generate dimelo email", e);
        }
    }
}
