package com.natixis.nie.hubis.core;


import com.natixis.nie.hubis.core.db.*;
import com.natixis.nie.hubis.core.domain.*;
import com.natixis.nie.hubis.core.domain.simulation.Simulation;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;

import javax.inject.Inject;

import static java.util.Arrays.stream;

public class SouscriptionService {

    private final StateDAO stateDAO;
    private final TransactionManager transactionManager;
    private Ged ged;
    private UploadDAO uploadDAO;
    private SimulationDAO simulationDAO;
    private final EntrepriseDAO entrepriseDAO;

    @Inject
    public SouscriptionService(TransactionManager transactionManager, StateDAO stateDAO, SimulationDAO simulationDAO, EntrepriseDAO entrepriseDAO, UploadDAO uploadDAO, Ged ged) {
        this.uploadDAO = uploadDAO;
        this.stateDAO = stateDAO;
        this.transactionManager = transactionManager;
        this.ged = ged;
        this.simulationDAO = simulationDAO;
        this.entrepriseDAO = entrepriseDAO;
    }

    public State createSimulation(User user, Simulation simulation) {
        simulationDAO.createOrUpdate(user, simulation);
        return State.SIMULATION;
    }

    public State validateSimulation(User user) {
        State newState = State.RECAPITULATIF;
        stateDAO.updateState(user, newState);
        return newState;
    }

    public State createEntreprise(User user, Entreprise entreprise) {
        State newState = State.ENTREPRISE;
        transactionManager.execute(new TransactionCallbackWithoutResult() {
            @Override
            protected void doInTransactionWithoutResult(TransactionStatus status) {
                entrepriseDAO.create(user, entreprise);
                stateDAO.updateState(user, newState);
            }
        });
        return newState;
    }

    public void insertNumSecuDirigeant(User user, String numSecu) {

        transactionManager.execute(new TransactionCallbackWithoutResult() {
            @Override
            protected void doInTransactionWithoutResult(TransactionStatus status) {
                entrepriseDAO.insertNumSecu(user.getEntreprise().getDirigeant().getId().get().asInt(), numSecu);
            }
        });
    }

    public State sign(User user, Document signedConvention) {

        Id entrepriseId = user.getEntreprise().getIdOrFail();
        State newState = State.SIGNATURE;

        ged.save(signedConvention); //TODO This must be included into a transaction !!!!!

        transactionManager.execute(new TransactionCallbackWithoutResult() {
            @Override
            protected void doInTransactionWithoutResult(TransactionStatus status) {
                uploadDAO.saveMetadatas(entrepriseId, signedConvention.extractMetadatas());
                stateDAO.updateState(user, newState);
                stateDAO.updateStateContract(user, StatutContrat.SIGNE);
            }
        });

        return newState;
    }

    public State uploadFiles(User user, Document... documents) {

        State newState = State.UPLOAD;
        StatutContrat newStateContract = StatutContrat.UPLOAD;
        Id entrepriseId = user.getEntreprise().getIdOrFail();

        ged.save(documents); //TODO This must be included into a transaction !!!!!

        transactionManager.execute(new TransactionCallbackWithoutResult() {
            @Override
            protected void doInTransactionWithoutResult(TransactionStatus status) {
                stream(documents).map(d -> {
                    return d.extractMetadatas();
                }).forEach(m -> {
                    uploadDAO.saveMetadatas(entrepriseId, m);
                });
                stateDAO.updateState(user, newState);
                stateDAO.updateStateContract(user, newStateContract);

            }
        });

        return newState;
    }
}
