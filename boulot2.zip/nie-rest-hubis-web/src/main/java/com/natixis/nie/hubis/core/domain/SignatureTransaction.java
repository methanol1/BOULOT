package com.natixis.nie.hubis.core.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;


public class SignatureTransaction {

    private String accessId;
    private String transactionId;
    private String numTelDirigent;

    @JsonCreator
    public SignatureTransaction(@JsonProperty("aAccessId") String aAccessId, @JsonProperty("aTransactionId") String aTransactionId, @JsonProperty("aNumTelDirigent") String aNumTelDirigent) {
        super();
        accessId = aAccessId;
        transactionId = aTransactionId;
        numTelDirigent = aNumTelDirigent;
    }

    public String getAccessId() {
        return accessId;
    }

    public void setAccessId(String aAccessId) {
        accessId = aAccessId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String aTransactionId) {
        transactionId = aTransactionId;
    }

    public String getNumTelDirigent() {
        return numTelDirigent;
    }

    public void setNumTelDirigent(String numTelDirigent) {
        this.numTelDirigent = numTelDirigent;
    }

    @Override
    public String toString() {
        return "SignatureTransaction [accessId=" + accessId
                + ", transactionId=" + transactionId + "]";
    }


}
