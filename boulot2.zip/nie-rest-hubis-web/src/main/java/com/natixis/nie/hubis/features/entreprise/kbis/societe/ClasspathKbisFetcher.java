package com.natixis.nie.hubis.features.entreprise.kbis.societe;


import com.natixis.nie.hubis.core.KbisMapper;
import com.natixis.nie.hubis.core.domain.Siret;
import com.natixis.nie.hubis.core.domain.kbis.Kbis;
import com.natixis.nie.hubis.features.entreprise.kbis.KbisException;
import com.natixis.nie.hubis.features.entreprise.kbis.KbisFetcher;
import org.apache.commons.io.IOUtils;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Optional;

/**
 * For test purpose only
 */
public class ClasspathKbisFetcher implements KbisFetcher {

    private final KbisMapper mapper;

    public ClasspathKbisFetcher(KbisMapper mapper) {
        this.mapper = mapper;
    }

    @Override
    public Optional<Kbis> fetch(Siret siret) throws KbisException {

        String path = "siren/" + siret.getSiren() + ".xml";
        ClassPathResource resource = new ClassPathResource(path);

        if (siret.asString().equals("81456211200015")) {
            throw new KbisException("81456211200015 is a mocked siret that throw RuntimeException");
        }

        String xml;
        try {
            xml = getResourceAsString(resource);
        } catch (IOException e) {
            xml = loadNoResponse();
        }

        return mapper.map(xml);
    }

    private String loadNoResponse() {
        try {
            ClassPathResource classPathResource = new ClassPathResource("siren/noresponse.xml");
            return getResourceAsString(classPathResource);
        } catch (IOException e) {
            throw new RuntimeException("Unable to load no response file", e);
        }
    }

    private String getResourceAsString(ClassPathResource classPathResource) throws IOException {
        return IOUtils.toString(classPathResource.getInputStream(), StandardCharsets.UTF_8.name());
    }
}
