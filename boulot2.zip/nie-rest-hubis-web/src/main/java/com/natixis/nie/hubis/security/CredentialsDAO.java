package com.natixis.nie.hubis.security;

import com.natixis.nie.hubis.core.db.DataSourceHandler;
import com.natixis.nie.hubis.core.db.NoDataUpdatedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
class CredentialsDAO {

    private final static Logger logger = LoggerFactory.getLogger(CredentialsDAO.class);

    private final DataSourceHandler dataSourceHandler;

    @Inject
    public CredentialsDAO(DataSourceHandler dataSourceHandler) {
        this.dataSourceHandler = dataSourceHandler;
    }

    public UserStatus findSaltedPassword(String email) {
        return dataSourceHandler.getJdbcTemplate().queryForObject(
                "SELECT PASSWORD, NBECHEC FROM THUBUSER WHERE EMAIL = ?",
                new Object[]{email},
                (rs, rowNum) -> {
                    return new UserStatus(rs.getString("PASSWORD"), rs.getInt("NBECHEC"));
                });
    }

    public void incrementTries(String email) {
        logger.info("Increment nb tries for user {}", email);

        int nbRowsAffected = dataSourceHandler.getJdbcTemplate()
                .update("UPDATE THUBUSER SET NBECHEC =  Coalesce(NBECHEC, 0) + 1 WHERE EMAIL = ?", email);

        if (nbRowsAffected == 0) {
            throw new NoDataUpdatedException("Unable to add reset key for user " + email);
        }
    }
}
