package com.natixis.nie.hubis.security;

class UserStatus {

    private String saltedPassword;
    private int nbTries;

    public UserStatus(String saltedPassword, int nbTries) {
        this.saltedPassword = saltedPassword;
        this.nbTries = nbTries;
    }

    public String getSaltedPassword() {
        return saltedPassword;
    }

    public boolean isLocked() {
        return nbTries >= 3;
    }
}
