package com.natixis.nie.hubis.features.email;

import com.natixis.nie.hubis.core.AppProperties;
import com.natixis.nie.hubis.core.exception.AppException;
import freemarker.template.Configuration;
import freemarker.template.Template;

import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ResetEmailTemplate implements EmailTemplate {

    private final UUID key;
    private final AppProperties appProperties;

    public ResetEmailTemplate(UUID key, AppProperties appProperties) {
        this.key = key;
        this.appProperties = appProperties;
    }

    @Override
    public String getSubject() {
        return "Regénération de mot de passe";
    }

    @Override
    public String getHtmlContent(Configuration config) {

        Map<String, String> model = new HashMap<>();
        model.put("key", key.toString());
        model.put("baseUrl", appProperties.get("app.url"));

        try {
            Template template = config.getTemplate("reset.ftl");
            StringWriter output = new StringWriter();
            template.process(model, output);
            return output.toString();

        } catch (Exception e) {
            throw new AppException("Unable to generate HTML content for reset email", e);
        }
    }
}
