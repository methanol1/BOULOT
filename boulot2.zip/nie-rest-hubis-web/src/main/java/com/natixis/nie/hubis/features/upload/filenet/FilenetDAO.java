package com.natixis.nie.hubis.features.upload.filenet;

import com.natixis.nie.hubis.core.AppProperties;
import com.natixis.nie.hubis.core.Ged;
import com.natixis.nie.hubis.core.domain.Document;
import com.natixis.nie.hubis.core.domain.DocumentMetadatas;
import com.natixis.sphinx.integration.filenet.ged.GedTemplate;
import nbp.fwk.ged.modele.IDocument;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.io.ByteArrayInputStream;

import static com.google.common.collect.Lists.newArrayList;


@Singleton
public class FilenetDAO implements Ged {

    private final static Logger logger = LoggerFactory.getLogger(FilenetDAO.class);
    public static final String DOCUMENT_TYPE = "DocumentDEM";
    public static final String ENTREPRISE_PROPERTY_NAME = "Entreprise";

    private final GedTemplate gedTemplate;
    private final AppProperties appProperties;

    @Inject
    public FilenetDAO(GedTemplate gedTemplate, AppProperties appProperties) {
        this.gedTemplate = gedTemplate;
        this.appProperties = appProperties;
    }

    @Override
    public Document get(DocumentMetadatas metadatas) {
        byte[] content = gedTemplate.getContentAsByteArray(metadatas.getGedId());
        return metadatas.asDocument(content);
    }

    @Override
    public void save(Document... documents) {

        String parentFolderId = appProperties.get("filenet.parent.folder.id");
        newArrayList(documents).stream().forEach(file -> {
            String filename = file.getFilename();

            String id = gedTemplate.createDocument(DOCUMENT_TYPE, filename, parentFolderId, new ByteArrayInputStream(file.getBytes()), IDocument::getId);

            logger.info("File {} has been saved into into filenet with id {}", filename, id);
            file.setId(id);
        });
    }

}
