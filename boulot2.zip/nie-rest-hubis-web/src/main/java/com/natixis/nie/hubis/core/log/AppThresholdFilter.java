package com.natixis.nie.hubis.core.log;

import ch.qos.logback.classic.filter.ThresholdFilter;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.spi.FilterReply;

import static com.natixis.nie.hubis.core.AppProperties.APP_PROPERTIES;

public class AppThresholdFilter extends ThresholdFilter {

    @Override
    public FilterReply decide(ILoggingEvent event) {
        if (!APP_PROPERTIES.isLocal()) {
            return FilterReply.DENY;
        }
        return super.decide(event);
    }
}
