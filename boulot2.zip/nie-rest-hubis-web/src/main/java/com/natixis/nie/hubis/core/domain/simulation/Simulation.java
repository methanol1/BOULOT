package com.natixis.nie.hubis.core.domain.simulation;

import com.natixis.nie.hubis.core.exception.AppException;
import com.natixis.nie.hubis.features.simulation.SimulationItems;

import java.util.Date;
import java.util.Optional;


public class Simulation {

    private Epargne epargne;
    private Cesu cesu;
    private SimulationCriteria simulationCriteria;
    private final SimulationItems availablesItems;
    private Date dateSignature;

    public Simulation(SimulationCriteria criteria, SimulationItems availablesItems, int epargneVersement, int cesuVersement) {

        this.simulationCriteria = criteria;
        this.availablesItems = availablesItems;
        this.epargne = availablesItems.findEpargneByVersement(epargneVersement).orElse(null);
        this.cesu = availablesItems.findCesuByVersement(cesuVersement).orElse(null);
        this.dateSignature = new Date();

        if (epargne == null && cesu == null) {
            throw new AppException("A simulation required at least a valid epargne or a cesu item");
        }
    }

    public Date getDateSignature() {
        return dateSignature;
    }

    public Optional<Epargne> getEpargne() {
        return Optional.ofNullable(epargne);
    }

    public Optional<Cesu> getCesu() {
        return Optional.ofNullable(cesu);
    }

    public int getTotalVersement() {
        return getCesu().map(Cesu::getVersement).orElse(0) + getEpargne().map(Epargne::getVersement).orElse(0);
    }

    public int getOptimizedTotalVersement() {
        return availablesItems.findCesuByVersement(Integer.MAX_VALUE).map(Cesu::getVersement).orElse(0)
                + availablesItems.findEpargneByVersement(Integer.MAX_VALUE).map(Epargne::getVersement).orElse(0);
    }

    public SimulationCriteria getSimulationCriteria() {
        return simulationCriteria;
    }
}
