package com.natixis.nie.hubis.core.db;

import com.natixis.nie.hubis.core.Ged;
import com.natixis.nie.hubis.core.domain.*;
import com.natixis.nie.hubis.core.domain.simulation.Simulation;
import com.natixis.nie.hubis.core.exception.NoEntrepriseFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.EmptyResultDataAccessException;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.util.Optional;

@Singleton
public class LazyUserData {

    private final static Logger logger = LoggerFactory.getLogger(LazyUserData.class);

    private final UploadDAO uploadDAO;
    private final SimulationDAO simulationDAO;
    private final EntrepriseDAO entrepriseDAO;
    private final StateDAO stateDAO;
    private final Ged ged;

    @Inject
    public LazyUserData(UploadDAO uploadDAO, SimulationDAO simulationDAO, EntrepriseDAO entrepriseDAO, StateDAO stateDAO, Ged ged) {
        this.uploadDAO = uploadDAO;
        this.simulationDAO = simulationDAO;
        this.entrepriseDAO = entrepriseDAO;
        this.stateDAO = stateDAO;
        this.ged = ged;
    }

    public State getState(User user) {
        return stateDAO.getState(user);
    }

    public Simulation getSimulation(User user) {
        return simulationDAO.findByUser(user);
    }

    public Optional<Entreprise> getEntreprise(User user) {
        try {
            Entreprise entreprise = entrepriseDAO.findByUser(user);
            return Optional.of(entreprise);
        } catch (NoEntrepriseFoundException e) {
            logger.debug(e.getMessage());
            return Optional.empty();
        }
    }

    public Optional<Document> getSignedContrat(User user) {

        Id entrepriseId = user.getEntreprise().getIdOrFail();
        try {
            DocumentMetadatas metadatas = uploadDAO.getMetadatas(entrepriseId, DocumentType.CONVENTION);
            Document document = ged.get(metadatas);
            return Optional.of(document);

        } catch (EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }
}
