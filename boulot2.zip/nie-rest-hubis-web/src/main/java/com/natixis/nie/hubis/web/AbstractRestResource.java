package com.natixis.nie.hubis.web;

import com.natixis.nie.hubis.core.AppProperties;
import com.natixis.nie.hubis.core.Messages;
import com.natixis.nie.hubis.core.domain.State;
import com.natixis.nie.hubis.security.AppSecurity;
import com.natixis.nie.hubis.web.dto.StateDTO;

import javax.inject.Inject;
import javax.ws.rs.core.Response;

public class AbstractRestResource {

    @Inject
    protected Messages messages;

    @Inject
    protected AppSecurity appSecurity;

    @Inject
    protected AppProperties appProperties;

    public Response sendState(State state) {
        return Response.ok(StateDTO.fromModel(state)).build();
    }
}
