package com.natixis.nie.hubis.features.user.dto;


import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.natixis.nie.hubis.web.validation.Validable;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

public class ForgottenPasswordDTO implements Validable {

    @Email
    @NotEmpty
    private final String email;

    @JsonCreator
    public ForgottenPasswordDTO(@JsonProperty("email") String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }
}
