package com.natixis.nie.hubis.features.simulation.web.dto;

import com.natixis.nie.hubis.features.user.dto.RawCredentialsDTO;
import com.natixis.nie.hubis.web.validation.Validable;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Pattern;


public class NewUserDTO implements Validable {

    @NotEmpty
    @Email
    private String email;

    @NotEmpty
    @Pattern(regexp = "(?=.*\\d{2,})(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z]{8,}", message = "Password does not match security constraints")
    private String password;


    public NewUserDTO() {
        //used by jackson
    }

    public NewUserDTO(String email, String password) {
        this.email = email;
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "NewUserDTO{" +
                "email='" + email + '\'' +
                '}';
    }

    public RawCredentialsDTO asRawCredentialsDTO() {
        return new RawCredentialsDTO(email, password);
    }
}
