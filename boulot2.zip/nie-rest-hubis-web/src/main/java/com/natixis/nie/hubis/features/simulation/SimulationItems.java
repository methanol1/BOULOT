package com.natixis.nie.hubis.features.simulation;


import com.natixis.nie.hubis.core.domain.simulation.Cesu;
import com.natixis.nie.hubis.core.domain.simulation.Epargne;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class SimulationItems {


    private final List<Epargne> epargnes;
    private final List<Cesu> cesus;

    public SimulationItems(List<Epargne> epargnes, List<Cesu> cesus) {
        this.epargnes = epargnes;
        this.cesus = cesus;
    }

    public List<Epargne> getEpargnes() {
        return epargnes;
    }

    public List<Cesu> getCesus() {
        return cesus;
    }

    public static int asInt(double d) {
        return Double.valueOf(d).intValue();
    }

    public Optional<Cesu> findCesuByVersement(int versement) {

        return getCesus().stream()
                .filter(e -> e.getVersement() <= versement)
                .sorted(Comparator.comparing(Cesu::getVersement).reversed())
                .findFirst();
    }

    public Optional<Epargne> findEpargneByVersement(int versement) {
        return getEpargnes().stream()
                .filter(e -> e.getVersement() <= versement)
                .sorted(Comparator.comparing(Epargne::getVersement).reversed())
                .findFirst();
    }
}
