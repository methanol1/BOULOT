package com.natixis.nie.hubis.features.editique;

import nbp.framework.print.sefas.enveloppe_1.Header;
import nbp.framework.print.sefas.enveloppe_1.Technique;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * Classe Helper Sefas
 */
public class EditiqueHelper {

    /**
     * Le code du domaine
     */
    private static String DOMAINE = "f";

    /**
     * Code Etablissement
     */
    private static String CODEETAB = "000";
    /**
     * Code Sous Etablissement NXS
     */
    private static String CODESSETAB_NXS = "STD";

    /**
     * Code Batch Affranchissement
     */
    private static String BATCHAFFRANCHISSEMENT = "";

    /**
     * Batch Code Pays
     */
    private static String BATCHCODEPAYS = "";

    /**
     * Code Batch Type Archivage
     */
    private static String BATCHTYPEARCHIVAGE = "";

    /**
     * Code application
     */
    private static String CODEAPPLICATION = "eaf";

    /**
     * Init header
     *
     * @param aDistributeur
     * @return Header
     */
    public static Header initHeaderByCodeApplication(String codeApplication) {
        final StringBuffer lId = new StringBuffer();
        lId.append(DOMAINE).append(codeApplication);
        lId.append("_").append("1");

        final Calendar lCalendar = Calendar.getInstance();
        final Calendar lCalendarHeur = Calendar.getInstance();

        // Header
        final Header lHeader = new Header();
        // Request ID
        lHeader.setRequeteId(lId.toString());
        // Request Date
        lHeader.setRequeteDate(lCalendar);
        // Request Heur
        lHeader.setRequeteHeure(lCalendarHeur);
        // Code application
        lHeader.setApplication(codeApplication);
        // Code domaine
        lHeader.setDomaine(DOMAINE);
        // Code etab
        lHeader.setCodeEtab(CODEETAB);
        // Code sous etab
        lHeader.setCodeSsEtab(CODESSETAB_NXS);
        // Batch Affranchissement
        lHeader.setBatchAffranchissement(BATCHAFFRANCHISSEMENT);
        // Batch Code Pays
        lHeader.setBatchCodePays(BATCHCODEPAYS);
        // Batch Affiche Logos
        lHeader.setBatchAfficheLogos(true);
        // Batch Affiche Mentions Legales
        lHeader.setBatchAfficheMentionLegale(true);
        // Batch Type Archivage
        lHeader.setBatchTypeArchivage(BATCHTYPEARCHIVAGE);
        // Recto verso à true
        lHeader.setRectoVerso(false);

        return lHeader;
    }


    public static Header initHeader() {
        return initHeaderByCodeApplication(CODEAPPLICATION);
    }

    /**
     * Init technique
     *
     * @param aModele
     * @return Technique
     */
    public static Technique convertToTechnique(final String aModele) {
        // Bloc technique
        final Technique lTechnique = new Technique();
        lTechnique.setModele(aModele);
        lTechnique.setDate(Calendar.getInstance());
        lTechnique.setAfficheLogo(true);
        lTechnique.setAfficheMentionLegale(false);
        lTechnique.setNbreExemplaire(1);
        return lTechnique;
    }

    /**
     * Init le nombre de dataVar
     *
     * @param aNbData
     * @return List<String>
     */
    public static List<String> initDataList(final int aNbData) {
        final List<String> listData = new ArrayList<String>(aNbData);
        if (aNbData > 0) {
            for (int indice = 0; indice < aNbData; indice++) {
                listData.add(new String(""));
            }
        }
        return listData;
    }

    /**
     * Méthode qui permet de controler une liste de String afin de remplacer
     * toute donnée null par ""
     *
     * @param aData
     * @return aData
     */
    public static List<String> controlData(final List<String> aData) {
        String lLeaf = null;
        for (int i = 0; i < aData.size(); i++) {
            lLeaf = aData.get(i);
            if (lLeaf == null) {
                aData.set(i, new String(""));
            }
        }
        return aData;
    }

    /**
     * Set la DataVar
     *
     * @param lListeDataVar
     * @param aVarNumber
     * @param aData
     */
    public static void setDataVar(List<String> lListeDataVar, int aVarNumber, String aData) {
        if (lListeDataVar != null && lListeDataVar.size() >= (aVarNumber - 1)) {
            lListeDataVar.set(aVarNumber - 1, aData);
        }
    }

    /**
     * Formatte un object en string si nécessaire.
     *
     * @param aObject L'objet � formatter
     * @return Une chaine de caracteres
     */
    public static String format(Object aObject) {
        String result = "";
        if (aObject != null) {
            result += aObject;
        }
        return result;
    }
}
