package com.natixis.nie.hubis.core.domain;


import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.Optional;

public class Dirigeant {

    private Id id;
    private final String fullname;
    private final String fonction;
    private final String telephone;
    private final LocalDate datenaiss;
    private final Adresse adresse;
    private final String numSecu;
    private BankData bankData;

    private Dirigeant(String fullname, String fonction, String telephone, LocalDate datenaiss, Adresse adresse, String numSecu) {
        this.fullname = fullname;
        this.fonction = fonction;
        this.telephone = telephone;
        this.datenaiss = datenaiss;
        this.adresse = adresse;
        this.numSecu = numSecu;
    }

    public Optional<Id> getId() {
        return Optional.ofNullable(id);
    }

    public void setId(Id id) {
        this.id = id;
    }

    public String getFullname() {
        return fullname;
    }

    public String getFonction() {
        return fonction;
    }

    public Adresse getAdresse() {
        return adresse;
    }

    public Optional<BankData> getBankData() {
        return Optional.ofNullable(bankData);
    }

    public LocalDate getDatenaiss() {
        return datenaiss;
    }

    public Date getDatenaissAsDate() {
        Instant instant = getDatenaiss().atStartOfDay().atZone(ZoneId.systemDefault()).toInstant();
        return Date.from(instant);
    }

    public String getTelephone() {
        return telephone;
    }

    public static Dirigeant newDirigeant(String fullname, String fonction, String telephone, LocalDate datenaiss, Adresse adresse, String numSecu) {
        return new Dirigeant(fullname, fonction, telephone, datenaiss, adresse, numSecu);
    }

    public static Dirigeant existingDirigeant(int id, String fullname, String fonction, String telephone, LocalDate datenaiss, Adresse adresse, String numSecu) {
        Dirigeant dirigeant = newDirigeant(fullname, fonction, telephone, datenaiss, adresse, numSecu);
        dirigeant.id = new Id(id);
        return dirigeant;
    }

    public Id getIdOrFail() {
        if (id == null) {
            throw new IllegalArgumentException("Unable to obtain id for this dirigeant. It has probably never been saved");
        }
        return id;
    }

    @Override
    public String toString() {
        return "Dirigeant [id=" + id + ", fullname=" + fullname + ", fonction="
                + fonction + ", telephone=" + telephone + ", datenaiss="
                + datenaiss + ", adresse=" + adresse + ", bankData=" + bankData
                + ", numSecu=" + numSecu + "]";
    }
}
