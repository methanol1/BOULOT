package com.natixis.nie.hubis.web.exception;


import com.natixis.nie.hubis.web.Errors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import static com.natixis.nie.hubis.web.Errors.Type.UNKNOWN;

@Provider
public class HubisExceptionMapper implements ExceptionMapper<Throwable> {

    private final static Logger logger = LoggerFactory.getLogger(HubisExceptionMapper.class);

    @Override
    public Response toResponse(Throwable throwable) {
        String message = "An error has occurred during request processing";

        logger.error(message, throwable);

        return Response
                .serverError()
                .entity(Errors.error(UNKNOWN, message))
                .build();
    }
}