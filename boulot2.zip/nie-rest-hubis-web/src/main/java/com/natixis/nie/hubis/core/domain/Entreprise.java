package com.natixis.nie.hubis.core.domain;


import com.natixis.nie.hubis.core.domain.kbis.Kbis;

import java.time.Month;
import java.util.Optional;

public class Entreprise {

    private Id id;
    private final Siret siret;
    private final String raisonSociale;
    private final int effectif;
    private final Month moisDeCloture;
    private final Adresse adresse;
    private final BankData bankData;
    private final FormeJuridique formeJuridique;
    private final Nace nace;
    private final Dirigeant dirigeant;
    private final String nomDispositif;
    private final Kbis kbis;


    public Entreprise(Siret siret, String raisonSociale, FormeJuridique formeJuridique, Nace nace, Adresse adresse, int effectif, Month moisDeCloture, Dirigeant dirigeant, BankData bankData, Kbis kbis, String nomDispositif) {

        this.dirigeant = dirigeant;
        this.adresse = adresse;
        this.raisonSociale = raisonSociale;
        this.siret = siret;
        this.formeJuridique = formeJuridique;
        this.nace = nace;
        this.moisDeCloture = moisDeCloture;
        this.effectif = effectif;
        this.bankData = bankData;
        this.id = null;
        this.kbis = kbis;
        this.nomDispositif = nomDispositif;
    }

    public Entreprise(Id id, Siret siret, String raisonSociale, FormeJuridique formeJuridique, Nace nace, Adresse adresse, int effectif, Month moisDeCloture, Dirigeant dirigeant, BankData bankData, Kbis kbis, String nomDispositif) {
        this(siret, raisonSociale, formeJuridique, nace, adresse, effectif, moisDeCloture, dirigeant, bankData, kbis, nomDispositif);
        this.id = id;
    }

    public Optional<Id> getId() {
        return Optional.ofNullable(id);
    }

    public void setId(Id id) {
        this.id = id;
    }

    public Siret getSiret() {
        return siret;
    }

    public String getRaisonSociale() {
        return raisonSociale;
    }

    public FormeJuridique getFormeJuridique() {
        return formeJuridique;
    }

    public Nace getNace() {
        return nace;
    }

    public int getEffectif() {
        return effectif;
    }

    public Month getMoisDeCloture() {
        return moisDeCloture;
    }

    public Adresse getAdresse() {
        return adresse;
    }

    public BankData getBankData() {
        return bankData;
    }

    public Dirigeant getDirigeant() {
        return dirigeant;
    }

    public Optional<Kbis> getKbis() {
        return Optional.ofNullable(kbis);
    }

    public Optional<String> getNomDispositif() {
        return Optional.ofNullable(nomDispositif);
    }

    public Id getIdOrFail() {
        if (id == null) {
            throw new IllegalArgumentException("Unable to obtain id for this entreprise. It has probably never been saved");
        }
        return id;
    }

    @Override
    public String toString() {
        return "Entreprise [id=" + id + ", siret=" + siret + ", raisonSociale="
                + raisonSociale + ", effectif=" + effectif + ", moisDeCloture="
                + moisDeCloture + ", adresse=" + adresse + ", bankData="
                + bankData + ", formeJuridique=" + formeJuridique + ", nace="
                + nace + ", dirigeant=" + dirigeant + ", kbis=" + kbis
                + ", nomTeneurES=" + nomDispositif + "]";
    }


}
