package com.natixis.nie.hubis.features.entreprise.kbis;


import com.natixis.nie.hubis.core.domain.Siret;
import com.natixis.nie.hubis.core.domain.kbis.Kbis;

import java.util.Optional;

public interface KbisFetcher {

    Optional<Kbis> fetch(Siret siret) throws KbisException;
}
