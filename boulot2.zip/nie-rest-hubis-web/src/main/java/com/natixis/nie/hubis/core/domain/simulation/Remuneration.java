package com.natixis.nie.hubis.core.domain.simulation;

import static com.natixis.nie.hubis.features.simulation.SimulationItems.asInt;

public class Remuneration {

    private final SimulationCriteria criteria;
    private double chargesSociales;
    private double montantBrut;
    private double chargesPatronales;

    public Remuneration(int versement, SimulationCriteria criteria) {
        this.criteria = criteria;

        SimulationsDatas datas = criteria.getDatas();
        if (criteria.isDirigeantSalarie()) {
            this.montantBrut = versement / (1 + datas.getChargesPatronales());
            this.chargesPatronales = montantBrut * criteria.getDatas().getChargesPatronales();
            this.chargesSociales = montantBrut * datas.getChargesSalariales();

        } else {
            this.montantBrut = versement;
            this.chargesPatronales = 0;
            this.chargesSociales = montantBrut * datas.getChargesSociales();
        }
    }

    public int getChargesPatronales() {
        return asInt(chargesPatronales);
    }

    public int getChargesSociales() {
        return asInt(chargesSociales);
    }

    public int getCsgCrds() {
        return asInt(montantBrut * criteria.getDatas().getTauxCSG_CRDS() * criteria.getDatas().getAssieteCSG_CRDS());
    }

    public int getImpotsRevenu() {
        double csgDeductible = montantBrut * criteria.getDatas().getDeductionCSG_CRDS() * criteria.getDatas().getAssieteCSG_CRDS();
        double abattement = (montantBrut - chargesSociales - csgDeductible) * criteria.getDatas().getTauxAbattement();
        return asInt((montantBrut - chargesSociales - csgDeductible - abattement) * criteria.getDatas().getTauxImposition());
    }

    public int getMontantNet() {
        return asInt(montantBrut - getCsgCrds() - chargesSociales - getImpotsRevenu());
    }

}
