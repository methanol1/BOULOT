package com.natixis.nie.hubis.web;

import com.natixis.nie.hubis.core.Messages;
import com.natixis.nie.hubis.web.exception.HttpBadRequestException;
import com.natixis.nie.hubis.web.exception.HttpException;
import com.natixis.nie.hubis.web.exception.HttpUnexpectedRequestException;

import javax.inject.Inject;

import static com.natixis.nie.hubis.web.Errors.Type.INVALID_PARAMS;
import static com.natixis.nie.hubis.web.Errors.Type.UNKNOWN;
import static com.natixis.nie.hubis.web.Errors.error;


public class ResourceBase {

    @Inject
    Messages messages;

    public HttpException _400(String exceptionMessage, String message) {
        Errors errors = error(INVALID_PARAMS, messages.get(message));
        return new HttpBadRequestException(exceptionMessage, errors);
    }

    public HttpException _500(String exceptionMessage, Throwable e, String message) {
        Errors errors = error(UNKNOWN, messages.get(message));
        return new HttpUnexpectedRequestException(exceptionMessage, e, errors);
    }
}
