package com.natixis.nie.hubis.features.dimelo;


import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Iterator;
import java.util.List;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.natixis.nie.hubis.core.AppProperties;
import com.natixis.nie.hubis.core.domain.AgentDimelo;
import com.natixis.nie.hubis.core.domain.ChannelDimelo;

public class DimeloApiFetcher {

    private final static Logger logger = LoggerFactory.getLogger(DimeloApiFetcher.class);

    private OkHttpClient client;
    private final String apiUrl;

    public DimeloApiFetcher(AppProperties appProperties) {
        this.apiUrl = appProperties.get("dimelo.api.url");

        String host = appProperties.get("proxy.host");
        int port = appProperties.getInt("proxy.port");
        
        OkHttpClient.Builder builder = new OkHttpClient.Builder()
                .proxy(new Proxy(Proxy.Type.HTTP, new InetSocketAddress(host, port)));

        if (appProperties.isLocal()) {
            builder.sslSocketFactory(getUnsafeSSLSocketFactory());
        }

        this.client = builder.build();
    }

    public boolean isTempsReel() {
        logger.info("Requesting dimelo with url {}", this.apiUrl);
        Request request = new Request.Builder()
                .url(this.apiUrl)
                .get()
                .build();
        
        try {
            Response response = client.newCall(request).execute();
            String json = new String(response.body().bytes(),"utf-8");
            ObjectMapper mapper = new ObjectMapper();
            
            List<AgentDimelo> lListAgent = mapper.readValue(json, mapper.getTypeFactory().constructCollectionType(List.class, AgentDimelo.class));
            		
            //On recherche si un agent est dispo, on envoie ok dans ce cas
            for (Iterator lIterator  = lListAgent.iterator(); lIterator.hasNext();) {
				AgentDimelo lAgentDimelo = (AgentDimelo) lIterator .next();
				List<ChannelDimelo> lListChannel = lAgentDimelo.getChannels();
				for (Iterator lIterator2 = lListChannel.iterator(); lIterator2.hasNext();) {
					ChannelDimelo lChannel = (ChannelDimelo) lIterator2.next();
					if (lChannel.getName()!=null && lChannel.getName().equals("Temps réel")) {
						if (lChannel.getStatus()!=null && lChannel.getStatus().equals("available")) { 
							if (lChannel.getBusyness()!=null && (lChannel.getBusyness().equals("unoccupied") || lChannel.getBusyness().equals("ok")) ) { 
								return true;
							}
						}
					}
				}
			}
            
            return false;
            
        } catch (IOException e) {
            throw new RuntimeException("Unable to get  reponse from dimelo", e);
        }
    }

    private static SSLSocketFactory getUnsafeSSLSocketFactory() {
        try {
            // Create a trust manager that does not validate certificate chains
            TrustManager tm = new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                }

                public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                }

                public X509Certificate[] getAcceptedIssuers() {
                    return null;
                }
            };

            // Install the all-trusting trust manager
            SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(null, new TrustManager[]{tm}, null);

            // Create an ssl socket factory with our all-trusting manager
            return sslContext.getSocketFactory();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
