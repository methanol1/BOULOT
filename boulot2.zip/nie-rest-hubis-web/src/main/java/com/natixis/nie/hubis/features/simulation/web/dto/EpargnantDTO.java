package com.natixis.nie.hubis.features.simulation.web.dto;


import com.natixis.nie.hubis.core.domain.simulation.Epargnant;

public class EpargnantDTO {

    private RemunerationDTO remuneration;
    private int versementAnnuel;
    private int versementMensuel;

    public RemunerationDTO getRemuneration() {
        return remuneration;
    }

    public void setRemuneration(RemunerationDTO remuneration) {
        this.remuneration = remuneration;
    }

    public int getVersementAnnuel() {
        return versementAnnuel;
    }

    public void setVersementAnnuel(int versementAnnuel) {
        this.versementAnnuel = versementAnnuel;
    }

    public int getVersementMensuel() {
        return versementMensuel;
    }

    public void setVersementMensuel(int versementMensuel) {
        this.versementMensuel = versementMensuel;
    }

    public static EpargnantDTO fromModel(Epargnant e) {

        EpargnantDTO dto = new EpargnantDTO();
        dto.setVersementMensuel(e.getVersementMensuel());
        dto.setVersementAnnuel(e.getVersementAnnuel());
        dto.setRemuneration(RemunerationDTO.fromModel(e.getRemuneration()));
        return dto;

    }

    @Override
    public String toString() {
        return "EpargnantDTO{" +
                "remuneration=" + remuneration +
                ", versementAnnuel=" + versementAnnuel +
                ", versementMensuel=" + versementMensuel +
                '}';
    }
}
