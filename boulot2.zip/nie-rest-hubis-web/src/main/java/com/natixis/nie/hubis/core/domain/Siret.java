package com.natixis.nie.hubis.core.domain;


public class Siret {

    private String siret;

    public Siret(String siret) {
        this.siret = siret;
    }

    public String getSiren() {
        return siret.substring(0, 9);
    }

    public String asString() {
        return siret;
    }

    @Override
    public String toString() {
        return "Siret{" +
                "siret='" + siret + '\'' +
                '}';
    }
}
