package com.natixis.nie.hubis.features.simulation.web.validation;

import com.natixis.nie.hubis.features.simulation.web.dto.CartDTO;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class CartValidator implements ConstraintValidator<NonEmptyCart, CartDTO> {

    @Override
    public void initialize(NonEmptyCart constraintAnnotation) {
    }

    @Override
    public boolean isValid(CartDTO dto, ConstraintValidatorContext constraintContext) {
        return dto.getChosenEpargneVersement() > 0 || dto.getChosenCesuVersement() > 0;
    }
}
