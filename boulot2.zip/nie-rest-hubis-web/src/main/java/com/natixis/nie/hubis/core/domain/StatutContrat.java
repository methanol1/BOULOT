package com.natixis.nie.hubis.core.domain;


import java.util.Arrays;
import java.util.List;

public enum StatutContrat {

    NOUVEAU, SIGNE, UPLOAD, PRISENCHARGE, KYCETAPE1ANO, KYCETAPE1VALIDE, KYCETAPE2, KYCETAPE2MANQUE, KYCETAPE2ANO, KYCETAPE2VALIDE, VALIDE, ANNULE;

    public static StatutContrat getNextState(StatutContrat currentState) {
        List<StatutContrat> states = Arrays.asList(StatutContrat.values());
        int i = states.indexOf(currentState);

        return i == states.size() - 1 ? VALIDE : states.get(i + 1);
    }
}
