package com.natixis.nie.hubis.features.simulation.web.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.natixis.nie.hubis.features.user.dto.RawCredentialsDTO;
import com.natixis.nie.hubis.web.validation.Validable;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

public class SignupDTO implements Validable {

    @NotNull
    @Valid
    private final NewUserDTO newUser;

    @NotNull
    @Valid
    private final NewSimulationDTO simulation;

    @JsonCreator
    public SignupDTO(@JsonProperty("newUser") NewUserDTO newUser, @JsonProperty("simulation") NewSimulationDTO simulation) {
        this.newUser = newUser;
        this.simulation = simulation;
    }

    public NewUserDTO getNewUser() {
        return newUser;
    }

    public NewSimulationDTO getSimulation() {
        return simulation;
    }

    public RawCredentialsDTO asRawCredentialsDTO() {
        return new RawCredentialsDTO(getNewUser().getEmail(), getNewUser().getPassword());
    }

    @Override
    public String toString() {
        return "SignupDTO{" +
                "newUser=" + newUser +
                ", simulation=" + simulation +
                '}';
    }
}
