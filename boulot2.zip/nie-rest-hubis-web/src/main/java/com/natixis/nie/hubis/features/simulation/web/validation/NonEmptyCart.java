package com.natixis.nie.hubis.features.simulation.web.validation;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Target({TYPE, ANNOTATION_TYPE})
@Retention(RUNTIME)
@Constraint(validatedBy = CartValidator.class)
public @interface NonEmptyCart {

    String message() default "Cart must not be empty";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
