package com.natixis.nie.hubis.features.entreprise.web.validation;

import org.iban4j.IbanUtil;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class IBANValidator implements ConstraintValidator<IBAN, String> {

    @Override
    public void initialize(IBAN constraintAnnotation) {
    }

    @Override
    public boolean isValid(String object, ConstraintValidatorContext constraintContext) {
        try {
            String iban = object != null ? object.toUpperCase() : null;
            IbanUtil.validate(iban);
        } catch (Exception e) {
            return false;
        }
        return true;
    }
}
