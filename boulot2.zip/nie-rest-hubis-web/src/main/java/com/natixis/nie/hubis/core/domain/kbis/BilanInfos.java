package com.natixis.nie.hubis.core.domain.kbis;

import java.util.Date;

public class BilanInfos {

    private Date dateFinExerc;

    public BilanInfos(Date dateFinExerc) {
        this.dateFinExerc = dateFinExerc;
    }

    public Date getDateFinExerc() {
        return dateFinExerc;
    }

    public void setDateFinExerc(Date aDateFinExerc) {
        dateFinExerc = aDateFinExerc;
    }

}
