package com.natixis.nie.hubis.features.entreprise.web.dto;

import com.natixis.nie.hubis.core.Datas;
import com.natixis.nie.hubis.core.domain.*;
import com.natixis.nie.hubis.core.domain.kbis.EntrepriseInfos;
import com.natixis.nie.hubis.core.domain.kbis.Kbis;
import com.natixis.nie.hubis.features.entreprise.web.validation.SIRET;
import com.natixis.nie.hubis.web.validation.Validable;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import java.time.Month;

public class EntrepriseInfosDTO implements Validable {

    private String siret;

    private String raisonSociale;

    private Integer moisDeCloture;

    private AdresseDTO adresse;

    private Integer formeJuridique;

    private String nace;

    private DirigeantDTO dirigeant;


    public String getSiret() {
        return siret;
    }

    public void setSiret(String siret) {
        this.siret = siret;
    }

    public String getRaisonSociale() {
        return raisonSociale;
    }

    public void setRaisonSociale(String raisonSociale) {
        this.raisonSociale = raisonSociale;
    }

    public Integer getMoisDeCloture() {
        return moisDeCloture;
    }

    public void setMoisDeCloture(Integer moisDeCloture) {
        this.moisDeCloture = moisDeCloture;
    }

    public AdresseDTO getAdresse() {
        return adresse;
    }

    public void setAdresse(AdresseDTO adresse) {
        this.adresse = adresse;
    }

    public Integer getFormeJuridique() {
        return formeJuridique;
    }

    public void setFormeJuridique(Integer formeJuridique) {
        this.formeJuridique = formeJuridique;
    }

    public String getNace() {
        return nace;
    }

    public void setNace(String nace) {
        this.nace = nace;
    }

    public DirigeantDTO getDirigeant() {
        return dirigeant;
    }

    public void setDirigeant(DirigeantDTO dirigeant) {
        this.dirigeant = dirigeant;
    }

    public static EntrepriseInfosDTO fromModel(EntrepriseInfos infos) {
        EntrepriseInfosDTO dto = new EntrepriseInfosDTO();
        dto.setSiret(infos.getSiret().asString());
        dto.setRaisonSociale(infos.getRaisonSociale());
        if (infos.getFormeJuridique() != null) {
            dto.setFormeJuridique(infos.getFormeJuridique().getId());
        }
        dto.setNace(infos.getNace().getCode());
        dto.setAdresse(AdresseDTO.fromModel(infos.getAdresse()));
        dto.setDirigeant(DirigeantDTO.fromModel(infos.getDirigeantInfos()));
        dto.setMoisDeCloture(infos.getMoisDeCloture().getValue());
        return dto;
    }
}
