package com.natixis.nie.hubis.web.validation;


import com.fasterxml.jackson.annotation.JsonIgnore;

public interface Validable {

    @JsonIgnore
    default boolean isValid() {
        return !Validation.hasErros(this);
    }
}
