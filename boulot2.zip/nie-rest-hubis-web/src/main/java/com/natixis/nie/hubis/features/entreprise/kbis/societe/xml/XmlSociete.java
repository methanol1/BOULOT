package com.natixis.nie.hubis.features.entreprise.kbis.societe.xml;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.util.Date;
import java.util.List;

@XmlRootElement(name = "main")
class XmlSociete {

    @XmlElement(name = "psiret")
    public String siret;

    @XmlElement(name = "no")
    public String siren;

    @XmlElement(name = "deno")
    public String denomination;

    @XmlElement(name = "enseigne")
    public String enseigne;

    @XmlElement(name = "adresse")
    public String adresse;

    @XmlElement(name = "codepostal")
    public int codepostal;

    @XmlElement(name = "commune")
    public String commune;

    @XmlElement(name = "ape")
    public String nace;

    @XmlElement(name = "apetexte")
    public String naceDescription;

    @XmlElement(name = "dcren")
    @XmlJavaTypeAdapter(DateAdapter.class)
    public Date dateCreation;

    @XmlElement(name = "nationalite")
    public String nationalite;

    @XmlElement(name = "formejur")
    public String formeJuridique;

    @XmlElement(name = "dirig")
    public List<XmlDirigeant> dirigeants;

    @XmlElement(name = "bilan")
    public List<XmlBilan> bilans;

    public boolean hasDirigeants() {
        return dirigeants != null && dirigeants.size() > 0;
    }

    public boolean hasBilans() {
        return bilans != null && bilans.size() > 0;
    }

    public boolean hasFormeJuridique() {
        return formeJuridique != null;
    }
}
