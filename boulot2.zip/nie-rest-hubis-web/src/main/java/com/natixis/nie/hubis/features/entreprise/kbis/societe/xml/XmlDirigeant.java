package com.natixis.nie.hubis.features.entreprise.kbis.societe.xml;


import javax.xml.bind.annotation.XmlElement;

class XmlDirigeant {

    @XmlElement(name = "titredirig")
    public String titre;

    @XmlElement(name = "detdirig")
    public String denomination;

}
