package com.natixis.nie.hubis.core.domain;


public class Nace {

    private String label;
    private String code;
    private boolean isEtatFinRequired;

    public Nace(String code, String label, boolean isEtatFinRequired) {
        this.label = label;
        this.code = code;
        this.isEtatFinRequired = isEtatFinRequired;
    }

    public String getLabel() {
        return label;
    }

    public String getCode() {
        return code;
    }

    public boolean isEtatFinRequired() {
        return isEtatFinRequired;
    }

    @Override
    public String toString() {
        return "Nace [label=" + label + ", code=" + code
                + ", isEtatFinRequired=" + isEtatFinRequired + "]";
    }


}
