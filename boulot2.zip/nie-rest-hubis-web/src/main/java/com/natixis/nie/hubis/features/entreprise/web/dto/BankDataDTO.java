package com.natixis.nie.hubis.features.entreprise.web.dto;


import com.natixis.nie.hubis.core.domain.BankData;
import com.natixis.nie.hubis.features.entreprise.web.validation.BIC;
import com.natixis.nie.hubis.web.validation.Validable;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Pattern;

public class BankDataDTO implements Validable {

    @NotEmpty
    @BIC
    private String bic;

    // Validation on IBAN is made in EntrepriseResource because it needs contextual informations
    private String iban;

    @Pattern(regexp = "(^$|[0-9]{10})")
    private String telephone;

    @NotEmpty
    private String agence;

    public String getBic() {
        return bic;
    }

    public void setBic(String bic) {
        this.bic = bic;
    }

    public String getIban() {
        return iban;
    }

    public void setIban(String iban) {
        this.iban = iban;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getAgence() {
        return agence;
    }

    public void setAgence(String agence) {
        this.agence = agence;
    }

    public static BankDataDTO fromModel(BankData bankData) {
        BankDataDTO dto = new BankDataDTO();
        dto.setBic(bankData.getBic());
        dto.setIban(bankData.getEncryptedIban());
        dto.setTelephone(bankData.getTelephone());
        dto.setAgence(bankData.getAgence());
        return dto;
    }

    public BankData toModel() {
        return new BankData(bic, iban, telephone, agence);
    }
}
