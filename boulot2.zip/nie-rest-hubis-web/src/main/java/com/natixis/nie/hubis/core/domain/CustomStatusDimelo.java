package com.natixis.nie.hubis.core.domain;

public class CustomStatusDimelo {
	private String id;
	
	public String getId() {
		return id;
	}
	public void setId(String aId) {
		id = aId;
	}
}
