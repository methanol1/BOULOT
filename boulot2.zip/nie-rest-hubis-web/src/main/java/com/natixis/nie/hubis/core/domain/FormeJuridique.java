package com.natixis.nie.hubis.core.domain;


import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotNull;

public class FormeJuridique {

    @NotNull
    private int id;
    private String label;
    private boolean isStatutRequired;

    @JsonCreator
    public FormeJuridique(@JsonProperty("id") int id, @JsonProperty("label") String label, @JsonProperty("isStatutRequired") boolean isStatutRequired) {
        this.id = id;
        this.label = label;
        this.isStatutRequired = isStatutRequired;
    }

    public int getId() {
        return id;
    }

    public String getLabel() {
        return label;
    }

    public boolean isStatutRequired() {
        return isStatutRequired;
    }

    @Override
    public String toString() {
        return "FormeJuridique [id=" + id + ", label=" + label
                + ", isStatutRequired=" + isStatutRequired + "]";
    }


}
