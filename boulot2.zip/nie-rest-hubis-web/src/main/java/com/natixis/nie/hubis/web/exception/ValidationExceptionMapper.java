package com.natixis.nie.hubis.web.exception;

import com.natixis.nie.hubis.core.Messages;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;
import java.util.List;
import java.util.stream.Collectors;

import static com.natixis.nie.hubis.web.Errors.Type.INVALID_PARAMS;
import static com.natixis.nie.hubis.web.Errors.error;
import static javax.ws.rs.core.Response.Status.BAD_REQUEST;

@Provider
public class ValidationExceptionMapper implements ExceptionMapper<ConstraintViolationException> {

    private final static Logger logger = LoggerFactory.getLogger(ValidationExceptionMapper.class);

    @Inject
    private Messages messages;

    @Override
    public Response toResponse(ConstraintViolationException ex) {

        logException(ex);

        String[] constrainsMessages = ex.getConstraintViolations().stream()
                .map(ConstraintViolation::getMessage)
                .toArray(String[]::new);

        return Response
                .status(BAD_REQUEST)
                .entity(error(INVALID_PARAMS, messages.get("validation.errors", constrainsMessages)))
                .build();
    }

    private void logException(ConstraintViolationException ex) {
        List<String> violations = ex.getConstraintViolations().stream()
                .map(v -> v.getPropertyPath() + " " + v.getMessage())
                .collect(Collectors.toList());
        String message = "Sending back a 400 HTTP status code due to violations [" + String.join(",", violations) + "]";
        logger.error(message, ex);
    }
}