package com.natixis.nie.hubis.features.user;

import com.natixis.nie.hubis.core.db.UserDAO;
import com.natixis.nie.hubis.core.domain.User;
import com.natixis.nie.hubis.core.exception.AppException;
import com.natixis.nie.hubis.features.email.EmailService;
import com.natixis.nie.hubis.features.email.ResetEmailTemplate;
import com.natixis.nie.hubis.features.user.dto.ForgottenPasswordDTO;
import com.natixis.nie.hubis.features.user.dto.RawCredentialsDTO;
import com.natixis.nie.hubis.features.user.dto.ResetPasswordDTO;
import com.natixis.nie.hubis.security.InvalidCredentials;
import com.natixis.nie.hubis.security.LockedUserException;
import com.natixis.nie.hubis.web.AbstractRestResource;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.UUID;

import static com.natixis.nie.hubis.web.Errors.Type.INVALID_PARAMS;
import static com.natixis.nie.hubis.web.Errors.Type.LOCKED;
import static com.natixis.nie.hubis.web.Errors.error;
import static javax.ws.rs.core.Response.Status.BAD_REQUEST;
import static javax.ws.rs.core.Response.Status.FORBIDDEN;
import static javax.ws.rs.core.Response.Status.UNAUTHORIZED;

@Path("/v1/auth")
@Produces({MediaType.APPLICATION_JSON})
@Consumes(MediaType.APPLICATION_JSON)
@Api(value = "v1-auth",
        description = "Handles all authentication actions login/logout/password-reset...",
        consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
public class AuthResource extends AbstractRestResource {

    private final static Logger logger = LoggerFactory.getLogger(AuthResource.class);

    @Inject
    UserDAO userDAO;

    @Inject
    EmailService emailService;


    @POST
    @Path("/login")
    public Response login(RawCredentialsDTO raw) {

        try {
            String email = appSecurity.login(raw.getEmail(), raw.getPassword());
            logger.info("User {} has been successfully authenticated", email);

            User user = userDAO.get(email);

            return sendState(user.getCurrentState());

        } catch (InvalidCredentials e) {
            logger.error("User has been rejected", e);
            return Response
                    .status(BAD_REQUEST)
                    .entity(error(INVALID_PARAMS, messages.get("auth.errors.credentials.invalid")))
                    .build();
        } catch (LockedUserException e) {
            logger.error("User is locked", e);
            return Response
                    .status(FORBIDDEN)
                    .entity(error(LOCKED, messages.get("auth.errors.account.locked")))
                    .build();
        }
    }

    @POST
    @Path("/forgotten-password")
    @ApiOperation(value = "Request a token to be able to reset password")
    public Response forgottenPassword(ForgottenPasswordDTO dto) {

        try {
            UUID resetKey = UUID.randomUUID();
            userDAO.addResetKey(dto.getEmail(), resetKey);
            emailService.sendEmailAsync(dto.getEmail(), new ResetEmailTemplate(resetKey, appProperties));

        } catch (AppException e) {
            logger.error("Unable to init reset password", e);
            return Response
                    .status(BAD_REQUEST)
                    .entity(error(INVALID_PARAMS, messages.get("auth.errors.reset")))
                    .build();
        }

        return Response.ok(dto).build();
    }

    @POST
    @Path("/reset")
    @ApiOperation(value = "Reset password")
    public Response reset(ResetPasswordDTO dto) {

        RawCredentialsDTO credentials = dto.getCredentials();
        String email = credentials.getEmail();

        if (!dto.isPasswordValid() || !userDAO.canResetPassword(email, dto.getResetKey())) {
            return Response
                    .status(BAD_REQUEST)
                    .entity(error(INVALID_PARAMS, messages.get("auth.errors.generic")))
                    .build();
        }

        String hash = appSecurity.hashPassword(credentials.getPassword());
        userDAO.resetPassword(email, hash);

        return Response.ok().build();
    }

    @GET
    @Path("/logout")
    public Response logout() {
        appSecurity.logout();
        return Response.ok().build();
    }
}
