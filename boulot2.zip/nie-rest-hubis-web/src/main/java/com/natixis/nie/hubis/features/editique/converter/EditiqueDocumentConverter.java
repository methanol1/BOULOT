package com.natixis.nie.hubis.features.editique.converter;

import com.natixis.nie.hubis.features.editique.EditiqueHelper;
import com.natixis.nie.hubis.features.editique.bean.EditiqueBean;
import nbp.framework.print.sefas.enveloppe_1.Client;
import nbp.framework.print.sefas.enveloppe_1.Content;
import nbp.framework.print.sefas.enveloppe_1.Rib;
import nbp.framework.print.sefas.enveloppe_1.XMLElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;


/**
 * Converter pour les documents éditique
 */
public final class EditiqueDocumentConverter {
    /**
     * Logger
     */
    private final static Logger logger = LoggerFactory.getLogger(EditiqueDocumentConverter.class);


    /**
     * Classe Statique
     */
    public EditiqueDocumentConverter() {
    }

    /**
     * Retourne le XML element à fournir à l'éditique
     *
     * @param aEditiqueBean
     * @return
     */
    public static XMLElement convert(final EditiqueBean aEditiqueBean, String codeModele) {
        // Init XmlElement
        XMLElement lElement = new XMLElement();

        // Header
        lElement.setHeader(EditiqueHelper.initHeader());

        List<Content> listeContent = new ArrayList<Content>();

        initContent(lElement, aEditiqueBean, listeContent, codeModele);

        lElement.setContent(listeContent);

        // Retourne l'élément
        return lElement;
    }

    /**
     * Initialise le contenu de l'élément XML à partir des données passées en
     * paramètre.
     *
     * @param aElement
     * @param aEditiqueBean
     * @param aListeContent
     */
    private static void initContent(XMLElement aElement, final EditiqueBean aEditiqueBean, List<Content> aListeContent, String codeModele) {
        // Init Content
        Content lContent = new Content();

        // Technique
        lContent.setTechnique(EditiqueHelper.convertToTechnique(codeModele));

        // Data
        initData(lContent, aEditiqueBean);

        initEmprunteur(lContent, aEditiqueBean);

        initCaution(lContent, aEditiqueBean);

        initRib(lContent, aEditiqueBean);

        // Content
        aListeContent.add(lContent);
    }


    /**
     * Initialise le contenu avec les données passée en paramètre.
     *
     * @param aContent
     * @param aEditiqueBean
     */
    private static void initData(Content aContent, final EditiqueBean aEditiqueBean) {
        // Init Liste Data
        List<String> lListeData = EditiqueHelper.initDataList(30);

        /**
         * Données générales
         */
        // Var1 - Autre teneur (C1)
        EditiqueHelper.setDataVar(lListeData, 1, aEditiqueBean.getAutreTeneur());

        // Var2 - Nom autre teneur	(C2)
        EditiqueHelper.setDataVar(lListeData, 2, aEditiqueBean.getNomAutreTeneur());

        // Var3 - Plafond montant	(C3)
        EditiqueHelper.setDataVar(lListeData, 3, aEditiqueBean.getPlafondMontant());

        // Var4 - Plafond % du PASS	(C4)
        EditiqueHelper.setDataVar(lListeData, 4, aEditiqueBean.getPlafondPASS());

        // Var5 - Versement mensuel	(C5)
        EditiqueHelper.setDataVar(lListeData, 5, aEditiqueBean.getVersementMensuel());

        // Var6 - Valeur CESU	(C6)
        EditiqueHelper.setDataVar(lListeData, 6, aEditiqueBean.getValeurCESU());

        // Var7 - Date signature (C7)
        EditiqueHelper.setDataVar(lListeData, 7, aEditiqueBean.getDateSignature());

        // Var8 - Top Epargne salariale (C8)
        EditiqueHelper.setDataVar(lListeData, 8, aEditiqueBean.getEpargneSalariale());

        // Var9 - Top CESU (C9)
        EditiqueHelper.setDataVar(lListeData, 9, aEditiqueBean.getCESU());

        /**
         * Les liens
         */
        // Var10 - Ratification (C10)
        EditiqueHelper.setDataVar(lListeData, 10, aEditiqueBean.getLienRatification());

        // Var11 - Reglement Plan (C11)
        EditiqueHelper.setDataVar(lListeData, 11, aEditiqueBean.getLienReglementPlan());

        // Var12 - Reglements fonds (C12)
        EditiqueHelper.setDataVar(lListeData, 12, aEditiqueBean.getLienReglementFonds());

        // Var13 - Conditions generales ES (C13)
        EditiqueHelper.setDataVar(lListeData, 13, aEditiqueBean.getLienConditionsGeneralesES());

        // Var14 - Annexe tarifaire (C14)
        EditiqueHelper.setDataVar(lListeData, 14, aEditiqueBean.getLienAnnexeTarifaire());

        // Var15 - Contrat d'echange (C15)
        EditiqueHelper.setDataVar(lListeData, 15, aEditiqueBean.getLienContratEchange());

        // Var16 - Conditions generales CESU (C16)
        EditiqueHelper.setDataVar(lListeData, 16, aEditiqueBean.getLienConditionsGeneralesCESU());

        // Var17 - Ratification (C17)
        EditiqueHelper.setDataVar(lListeData, 17, aEditiqueBean.getLibLienRatification());

        // Var18 - Reglement Plan (C18)
        EditiqueHelper.setDataVar(lListeData, 18, aEditiqueBean.getLibLienReglementPlan());

        // Var19 - Reglements fonds (C19)
        EditiqueHelper.setDataVar(lListeData, 19, aEditiqueBean.getLibLienReglementFonds());

        // Var20 - Conditions generales ES (C20)
        EditiqueHelper.setDataVar(lListeData, 20, aEditiqueBean.getLibLienConditionsGeneralesES());

        // Var21 - Annexe tarifaire (C21)
        EditiqueHelper.setDataVar(lListeData, 21, aEditiqueBean.getLibLienAnnexeTarifaire());

        // Var22 - Contrat d'echange (C22)
        EditiqueHelper.setDataVar(lListeData, 22, aEditiqueBean.getLibLienContratEchange());

        // Var23 - Conditions generales CESU (C23)
        EditiqueHelper.setDataVar(lListeData, 23, aEditiqueBean.getLibLienConditionsGeneralesCESU());

        // Controle les var
        EditiqueHelper.controlData(lListeData);

        // DataVar
        aContent.setData(lListeData);
    }

    /**
     * Initialise le content emprunteur
     */
    private static void initEmprunteur(Content aContent, final EditiqueBean aEditiqueBean) {
        if (aEditiqueBean != null) {
            Client emprunteur = new Client();
            emprunteur.setNom(aEditiqueBean.getRaisonSociale());
            emprunteur.setAdresse1(aEditiqueBean.getAdresseEntreprise());
            emprunteur.setAdresse5(aEditiqueBean.getCodePostalEntreprise());
            emprunteur.setAdresse6(aEditiqueBean.getVilleEntreprise());

            // Init Liste CustVar
            List<String> lListeCustVar = EditiqueHelper.initDataList(5);

            EditiqueHelper.setDataVar(lListeCustVar, 1, aEditiqueBean.getSiret());
            EditiqueHelper.setDataVar(lListeCustVar, 2, aEditiqueBean.getFormeJuridique());
            EditiqueHelper.setDataVar(lListeCustVar, 3, aEditiqueBean.getCodeNAF());
            EditiqueHelper.setDataVar(lListeCustVar, 4, aEditiqueBean.getEffectifs());
            EditiqueHelper.setDataVar(lListeCustVar, 5, aEditiqueBean.getMoisCloture());
            emprunteur.setCustVars(lListeCustVar);

            aContent.setEmprunteur(emprunteur);
        }
    }

    /**
     * Initialise le content caution
     */
    private static void initCaution(Content aContent, final EditiqueBean aEditiqueBean) {
        if (aEditiqueBean != null) {
            Client caution = new Client();
            caution.setNom(aEditiqueBean.getDenomRespLegal());
            caution.setAdresse1(aEditiqueBean.getAdresseRespLegal());
            caution.setAdresse5(aEditiqueBean.getCodePostalRespLegal());
            caution.setAdresse6(aEditiqueBean.getVilleRespLegal());
            caution.setMail(aEditiqueBean.getEmail());
            caution.setTelPro(aEditiqueBean.getTelephone());

            // Init Liste CustVar
            List<String> lListeCustVar = EditiqueHelper.initDataList(1);
            EditiqueHelper.setDataVar(lListeCustVar, 1, aEditiqueBean.getFonction());
            caution.setCustVars(lListeCustVar);

            aContent.setCaution(caution);
        }
    }

    /**
     * Initialise le content rib
     */
    private static void initRib(Content aContent, final EditiqueBean aEditiqueBean) {
        if (aEditiqueBean != null) {
            Rib lrib = new Rib();
            lrib.setBic(aEditiqueBean.getBIC());
            lrib.setIban(aEditiqueBean.getIBAN());

            aContent.setRib(lrib);
        }
    }

}
