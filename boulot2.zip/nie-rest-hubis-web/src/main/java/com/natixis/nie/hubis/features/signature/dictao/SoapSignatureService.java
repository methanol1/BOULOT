package com.natixis.nie.hubis.features.signature.dictao;


import com.google.common.net.MediaType;
import com.natixis.nie.hubis.core.AppProperties;
import com.natixis.nie.hubis.core.SignatureService;
import com.natixis.nie.hubis.core.domain.*;
import com.natixis.nie.hubis.core.domain.Document;
import com.natixis.nie.hubis.core.exception.AppException;
import com.natixis.nie.hubis.signature.*;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

@Singleton
public class SoapSignatureService implements SignatureService {

    private final DictaoWSClient service;
    private final AppProperties appProperties;

    @Inject
    public SoapSignatureService(AppProperties appProperties) {
        this.appProperties = appProperties;
        this.service = new DictaoWSClient(appProperties);
    }

    @Override
    public SignatureTransaction createTransactionSignature(User user, byte[] docToSign) {

        String typeUser = "SIGNER";
        String label = "LABEL";
        String zoneSignatureEntite = "ZONESIGNENTITE";
        String zoneSignatureUser = "ZONESIGNUSER";
        String fileName = "contrat.pdf";
        //hubis_rec
        String tenant = appProperties.get("signature.ws.tenant");
        //service
        String policy = appProperties.get("signature.ws.policy");
        //hubis
        String businessId = appProperties.get("signature.ws.businessId");
        //CONTRACT
        String typeDoc = appProperties.get("signature.ws.typeDoc");
        //Natixis
        String organisation = appProperties.get("signature.ws.organisation");

        try {

            //Création de la transaction
            TransactionPort transactionPort = service.getTransactionPort();
            String transactionId = transactionPort.createTransaction(tenant, policy, businessId, null, null);

            //Ajout du Document
            DocumentPort documentPort = service.getDocumentPort();
            //File file = new ClassPathResource("signature/contrat.pdf").getFile();
            com.natixis.nie.hubis.signature.Document document = new com.natixis.nie.hubis.signature.Document();
            document.setMimetype("application/pdf");
            document.setFilename(fileName);
            document.setLabel(label);
            document.setDescription("Description du bulletin de souscription Hubis");
            //FileInputStream fis = new FileInputStream(file);
            //byte[] content = new byte[(int) file.length()];
            //fis.read(content);
            //fis.close();
            //document.setContent(content);
            document.setContent(docToSign);

            SignatureField signatureFieldEntite = new SignatureField();
            signatureFieldEntite.setLabel(zoneSignatureEntite);
            signatureFieldEntite.setLocation(null);
            document.getSignatureField().add(signatureFieldEntite);

            SignatureField signatureFieldUser = new SignatureField();
            signatureFieldUser.setLabel(zoneSignatureUser);
            signatureFieldUser.setLocation(null);
            document.getSignatureField().add(signatureFieldUser);

            documentPort.putDocument(transactionId, document, typeDoc, false, null);

            //Création d’un accès utilisateur:
            /*Informations sur le signataire*/
            Dirigeant dirigeant = user.getEntreprise().getDirigeant();

            PersonalInfo pi = new PersonalInfo();
            pi.setUserId(UUID.randomUUID().toString());
            SignatureInfo si = new SignatureInfo();
            si.setFirstName(dirigeant.getFullname());
            //si.setFirstName("testgpl");

            UserDN udn = new UserDN();
            udn.setCountryName("FR");
            udn.setOrganizationName(organisation);
            udn.setCommonName(dirigeant.getFullname());
            //udn.setCommonName("testgpl");

            si.setUserDN(udn);
            pi.setSignatureInfo(si);

			/*Informations sur l’authentification*/
            AuthenticationInfo ai = new AuthenticationInfo();
            ai.setPhoneNumber(dirigeant.getTelephone());
            //ai.setPhoneNumber("0616626472");
            String sNumTelDirigent = dirigeant.getTelephone();

            pi.setAuthenticationInfo(ai);

            //Personnalisation du SMS (option)
            /*AuthenticationContextType context = new AuthenticationContextType();
            ContextMetadataType ctxMd = new ContextMetadataType();
			ctxMd.setName("1");
			ctxMd.setValue("Jean");
			context.getMetadatas().add(ctxMd);
			ContextMetadataType ctxMd1 = new ContextMetadataType();
			ctxMd1.setName("2");
			ctxMd1.setValue("Dupont");
			context.getMetadatas().add(ctxMd1);*/

            List<String> authorizedDocs = Arrays.asList(new String[]{typeDoc});
            //Temps de validité de la transaction: 1h pour le test
            Long timeout = 3600000L;
            Metadata metadata = null;
            String uaId = transactionPort.createUserAccess(transactionId, pi, timeout, metadata, authorizedDocs, typeUser, null, false);

            //Signature Cachet d’un document:
            SignatureRequest signatureRequest = new SignatureRequest();
            signatureRequest.setType(typeDoc);
            signatureRequest.setLabel(zoneSignatureEntite);
            String signPolicy = null;
            documentPort.signDocuments(transactionId, Arrays.asList(signatureRequest), signPolicy);

            //On retourne l'accessId
            return new SignatureTransaction(uaId, transactionId, sNumTelDirigent);

        } catch (SystemFaultException | UserFaultException e) {
            throw new AppException("Exception on createTransactionSignature : ", e);
        }

    }

    @Override
    public Document finishTransaction(SignatureTransaction signatureTransaction) {

        try {
            String typeDoc = appProperties.get("signature.ws.typeDoc");        //CONTRACT
            DocumentPort documentPort = service.getDocumentPort();

            //Récupération du document via WS
            com.natixis.nie.hubis.signature.Document documentSigned = documentPort.getDocumentByType(signatureTransaction.getTransactionId(), typeDoc);

            TransactionPort transactionPort = service.getTransactionPort();

            //Fermeture de l’accès utilisateur :
            transactionPort.finishUserAccess(signatureTransaction.getAccessId());

            //Finalisation de la transaction :
            transactionPort.finishTransaction(signatureTransaction.getTransactionId());

            return new Document(DocumentType.CONVENTION, documentSigned.getContent(), MediaType.PDF);

        } catch (SystemFaultException | UserFaultException e) {
            throw new AppException("Exception on createTransactionSignature : ", e);
        }
    }
}
