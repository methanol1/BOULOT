package com.natixis.nie.hubis.web.validation;

import javax.validation.ConstraintViolation;
import javax.validation.ValidatorFactory;
import java.util.Set;


public class Validation {

    public static ValidatorFactory factory = javax.validation.Validation.buildDefaultValidatorFactory();
    public static javax.validation.Validator validator = factory.getValidator();

    public static <T> boolean hasErros(T pojo) {
        Set<ConstraintViolation<T>> constraintViolations = validator.validate(pojo);
        return constraintViolations.size() > 0;
    }
}
