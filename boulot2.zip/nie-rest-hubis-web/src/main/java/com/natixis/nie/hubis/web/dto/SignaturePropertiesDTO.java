package com.natixis.nie.hubis.web.dto;


import com.fasterxml.jackson.annotation.JacksonInject;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.natixis.nie.hubis.core.AppProperties;

public class SignaturePropertiesDTO {

    @JsonIgnore
    private AppProperties appProperties;

    @JsonCreator
    public SignaturePropertiesDTO(@JacksonInject AppProperties appProperties) {
        this.appProperties = appProperties;
    }

    public String getIframeUrl() {
        return appProperties.get("signature.iframe.url");
    }
}
