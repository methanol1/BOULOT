package com.natixis.nie.hubis.core.db;

import com.natixis.nie.hubis.core.domain.Id;
import com.natixis.nie.hubis.core.domain.State;
import com.natixis.nie.hubis.core.domain.User;
import com.natixis.nie.hubis.core.exception.AppException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.util.UUID;

@Singleton
public class UserDAO {

    private final static Logger logger = LoggerFactory.getLogger(UserDAO.class);

    private final DataSourceHandler dataSourceHandler;
    private final LazyUserData lazyUserData;

    @Inject
    public UserDAO(DataSourceHandler dataSourceHandler, LazyUserData lazyUserData) {
        this.dataSourceHandler = dataSourceHandler;
        this.lazyUserData = lazyUserData;
    }

    public boolean exists(String email) {

        int nbUser = dataSourceHandler.getJdbcTemplate().queryForInt(
                "SELECT count(EMAIL)FROM THUBUSER WHERE EMAIL = ?", new Object[]{email});

        return nbUser > 0;
    }


    public User get(String email) {
        try {
            return dataSourceHandler.getJdbcTemplate().queryForObject(
                    "SELECT ID_USER, EMAIL FROM THUBUSER WHERE EMAIL = ?", new Object[]{email}, (rs, rowNum) -> {

                        return createUser(new Id(rs.getInt("ID_USER")), rs.getString("EMAIL"));
                    });
        } catch (DataAccessException e) {
            throw new AppException("Unable to retrieve user " + email + " from db", e);
        }
    }

    public User create(String email, String saltedPassword) {

        logger.info("Saving new user into database");

        KeyHolder keyHolder = new GeneratedKeyHolder();
        MapSqlParameterSource parameters = new MapSqlParameterSource();
        parameters.addValue("email", email);
        parameters.addValue("password", saltedPassword);
        parameters.addValue("state", State.SIMULATION.name());

        dataSourceHandler.getNamedJdbcTemplate().update("INSERT INTO THUBUSER (EMAIL, PASSWORD, STATE) " +
                "VALUES (:email,:password, :state)", parameters, keyHolder, new String[]{"ID_USER"});

        Id userId = new Id(keyHolder.getKey().intValue());
        return createUser(userId, email);
    }

    public void addResetKey(String email, UUID resetKey) {
        logger.info("Adding reset key {} to user {} with email {}", resetKey, email);

        int nbRowsAffected = dataSourceHandler.getJdbcTemplate()
                .update("UPDATE THUBUSER SET RESET_KEY = ? WHERE EMAIL = ? ", resetKey.toString(), email);

        if (nbRowsAffected == 0) {
            throw new NoDataUpdatedException("Unable to add reset key for user " + email);
        }
    }

    public boolean canResetPassword(String email, String key) {
        int nbUser = dataSourceHandler.getJdbcTemplate().queryForInt(
                "SELECT count(EMAIL)FROM THUBUSER WHERE EMAIL = ? AND RESET_KEY = ?",
                new Object[]{email, key});

        return nbUser > 0;
    }

    public void resetPassword(String email, String hash) {

        logger.info("Reseting password for user", email);

        int nbRowsAffected = dataSourceHandler.getJdbcTemplate()
                .update("UPDATE THUBUSER SET PASSWORD = ?, NBECHEC = 0 WHERE EMAIL = ?", hash, email);

        if (nbRowsAffected == 0) {
            throw new NoDataUpdatedException("Unable to reset password for user " + email);
        }
    }

    /**
     * Acts as a user factory
     */
    private User createUser(Id userId, String email) {
        return new User(userId, email, lazyUserData);
    }

}
