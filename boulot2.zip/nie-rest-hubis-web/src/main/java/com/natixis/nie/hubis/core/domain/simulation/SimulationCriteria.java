package com.natixis.nie.hubis.core.domain.simulation;

public class SimulationCriteria {

    private boolean isDirigeantSalarie;
    private boolean hasSalaries;
    private final SimulationsDatas datas;

    public SimulationCriteria(boolean isDirigeantSalarie, boolean hasSalaries, SimulationsDatas datas) {
        this.isDirigeantSalarie = isDirigeantSalarie;
        this.hasSalaries = hasSalaries;
        this.datas = datas;
    }

    public boolean isDirigeantSalarie() {
        return isDirigeantSalarie;
    }

    public boolean hasSalaries() {
        return hasSalaries;
    }

    public SimulationsDatas getDatas() {
        return datas;
    }

    public static SimulationCriteria tnsWithSalarie(SimulationsDatas datas) {
        return new SimulationCriteria(false, true, datas);
    }

    public static SimulationCriteria tnsWithoutSalarie(SimulationsDatas datas) {
        return new SimulationCriteria(false, false, datas);
    }

    public static SimulationCriteria dirigeantSalarieWithSalarie(SimulationsDatas datas) {
        return new SimulationCriteria(true, true, datas);
    }

    public static SimulationCriteria dirigeantSalarieWithoutSalarie(SimulationsDatas datas) {
        return new SimulationCriteria(true, false, datas);
    }
}
