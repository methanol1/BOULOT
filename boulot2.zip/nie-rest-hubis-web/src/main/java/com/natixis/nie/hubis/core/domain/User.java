package com.natixis.nie.hubis.core.domain;


import com.natixis.nie.hubis.core.db.LazyUserData;
import com.natixis.nie.hubis.core.domain.simulation.Simulation;
import com.natixis.nie.hubis.core.exception.InvalidUserStateException;

import java.io.Serializable;
import java.util.Optional;

public class User implements Serializable {

    private final Id id;
    private final String email;
    private final LazyUserData lazyUserData;

    public User(Id id, String email, LazyUserData lazyUserData) {
        this.id = id;
        this.email = email;
        this.lazyUserData = lazyUserData;
    }

    public Id getId() {
        return id;
    }

    public String getEmail() {
        return email;
    }

    public State getCurrentState() {
        return lazyUserData.getState(this);
    }

    public Simulation getSimulation() {
        return lazyUserData.getSimulation(this);
    }

    public Entreprise getEntreprise() {
        return getEntrepriseAsOptional().orElseThrow(() ->
                new InvalidUserStateException("Unable to obtain entreprise for user " + id));
    }

    public Optional<Entreprise> getEntrepriseAsOptional() {
        return lazyUserData.getEntreprise(this);
    }

    public Document getSignedContrat() {
        return lazyUserData.getSignedContrat(this).orElseThrow(() ->
                new InvalidUserStateException("Unable to obtain contrat for user " + id));
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", email='" + email + '\'' +
                '}';
    }
}
