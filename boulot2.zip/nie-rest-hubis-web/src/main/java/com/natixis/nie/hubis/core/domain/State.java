package com.natixis.nie.hubis.core.domain;


import java.util.Collections;
import java.util.List;

import static com.google.common.collect.Lists.newArrayList;
import static java.util.Arrays.stream;
import static java.util.stream.Collectors.toList;

public enum State {

    SIMULATION(10), RECAPITULATIF(15), ENTREPRISE(20), SIGNATURE(30, true), UPLOAD(40, true), VERSEMENT(50, true);

    private final int order;
    private final boolean nextOnly;

    State(int order) {
        this.order = order;
        nextOnly = false;
    }

    State(int order, boolean nextOnly) {
        this.order = order;
        this.nextOnly = nextOnly;
    }

    public State nextState() {
        return stream(State.values())
                .filter(s -> s.order > order)
                .findFirst()
                .orElse(this);
    }

    public List<State> allowedStates() {
        State state = nextState();
        return nextOnly ? newArrayList(this, state) : stream(State.values())
                .filter(s -> s.order <= state.order)
                .sorted(Collections.reverseOrder())
                .collect(toList());
    }
}
