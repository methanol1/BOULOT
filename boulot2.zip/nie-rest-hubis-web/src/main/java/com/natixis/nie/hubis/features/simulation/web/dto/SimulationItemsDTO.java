package com.natixis.nie.hubis.features.simulation.web.dto;


import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.natixis.nie.hubis.features.simulation.SimulationItems;

import java.util.List;
import java.util.stream.Collectors;

public class SimulationItemsDTO {

    private final List<EpargneDTO> epargneAvailableVersements;
    private final List<CesuDTO> cesuAvailableVersements;

    @JsonCreator
    public SimulationItemsDTO(@JsonProperty("epargneAvailableVersements") List<EpargneDTO> epargneAvailableVersements, @JsonProperty("cesuAvailableVersements") List<CesuDTO> cesuAvailableVersements) {
        this.epargneAvailableVersements = epargneAvailableVersements;
        this.cesuAvailableVersements = cesuAvailableVersements;
    }

    public List<EpargneDTO> getEpargneAvailableVersements() {
        return epargneAvailableVersements;
    }

    public List<CesuDTO> getCesuAvailableVersements() {
        return cesuAvailableVersements;
    }

    public static SimulationItemsDTO fromModel(SimulationItems simulationItems) {
        List<EpargneDTO> epargneDTOs = simulationItems.getEpargnes().stream().map(EpargneDTO::fromModel).collect(Collectors.toList());
        List<CesuDTO> cesuDTOs = simulationItems.getCesus().stream().map(CesuDTO::fromModel).collect(Collectors.toList());
        return new SimulationItemsDTO(epargneDTOs, cesuDTOs);
    }
}
