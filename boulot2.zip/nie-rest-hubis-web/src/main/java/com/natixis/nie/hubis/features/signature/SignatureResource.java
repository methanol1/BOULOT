package com.natixis.nie.hubis.features.signature;

import com.natixis.nie.hubis.core.EditiqueService;
import com.natixis.nie.hubis.core.Env;
import com.natixis.nie.hubis.core.SignatureService;
import com.natixis.nie.hubis.core.SouscriptionService;
import com.natixis.nie.hubis.core.domain.Document;
import com.natixis.nie.hubis.core.domain.SignatureTransaction;
import com.natixis.nie.hubis.core.domain.State;
import com.natixis.nie.hubis.core.domain.User;
import com.natixis.nie.hubis.features.email.ConfirmationEmailTemplate;
import com.natixis.nie.hubis.features.email.EmailService;
import com.natixis.nie.hubis.web.AbstractRestResource;
import com.natixis.nie.hubis.web.dto.StateDTO;
import io.swagger.annotations.Api;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;

import static com.natixis.nie.hubis.core.domain.State.SIGNATURE;

@Path("/v1/signature")
@Produces({MediaType.APPLICATION_JSON})
@Consumes(MediaType.APPLICATION_JSON)
@Api(value = "v1-signature",
        description = "Allows user to create/close a transaction and sign convention",
        consumes = MediaType.APPLICATION_JSON,
        produces = MediaType.APPLICATION_JSON)
public class SignatureResource extends AbstractRestResource {

    @Inject
    @Env
    SignatureService signatureService;

    @Inject
    EditiqueService editiqueService;

    @Inject
    SouscriptionService souscriptionService;

    @Inject
    EmailService emailService;

    @POST
    @Path("/create")
    public Response createTransaction() throws IOException {

        User user = appSecurity.getCurrentUserForState(SIGNATURE);

        byte[] contrat = editiqueService.generatePdf(user);

        SignatureTransaction transaction = signatureService.createTransactionSignature(user, contrat);

        return Response.ok(transaction).build();
    }

    @POST
    @Path("/finish")
    public Response finishTransaction(SignatureTransaction signatureTransaction, @QueryParam("cancel") boolean cancel) throws IOException {

        User user = appSecurity.getCurrentUserForState(SIGNATURE);

        Document signedDocument = signatureService.finishTransaction(signatureTransaction);

        if (cancel) {
            return Response.ok(StateDTO.fromModel(State.SIGNATURE)).build();
        }

        State state = souscriptionService.sign(user, signedDocument);
        emailService.sendEmailAsync(user.getEmail(), new ConfirmationEmailTemplate(user, appProperties));

        return sendState(state);
    }

    @GET
    @Produces("application/pdf")
    public Response getSignedContrat() throws IOException {
        User user = appSecurity.getCurrentUser();
        Document document = user.getSignedContrat();
        return Response.ok(document.asFile()).build();
    }
}
