package com.natixis.nie.hubis.core.db;

import com.natixis.nie.hubis.core.domain.State;
import com.natixis.nie.hubis.core.domain.StatutContrat;
import com.natixis.nie.hubis.core.domain.User;
import com.natixis.nie.hubis.core.exception.InvalidUserStateException;
import org.springframework.dao.EmptyResultDataAccessException;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class StateDAO {

    private final DataSourceHandler dataSourceHandler;

    @Inject
    public StateDAO(DataSourceHandler dataSourceHandler) {
        this.dataSourceHandler = dataSourceHandler;
    }

    public State getState(User user) {

        int userId = user.getId().asInt();

        try {
            return dataSourceHandler.getJdbcTemplate().queryForObject(
                    "SELECT STATE FROM THUBUSER WHERE ID_USER = ?",
                    new Object[]{userId},
                    (rs, rowNum) -> {
                        return State.valueOf(rs.getString("STATE"));
                    });

        } catch (EmptyResultDataAccessException e) {
            throw new InvalidUserStateException("Unable to find user with id " + userId);
        }
    }

    public void updateState(User user, State newState) {

        int userId = user.getId().asInt();

        int nbRowsAffected = dataSourceHandler.getJdbcTemplate()
                .update("UPDATE THUBUSER SET STATE = ? WHERE ID_USER = ?", newState.name(), userId);

        if (nbRowsAffected == 0) {
            throw new NoDataUpdatedException("Unable to update user with id " + userId + " with new status " + newState.name());
        }
    }

    public void updateStateContract(User user, StatutContrat newState) {

        int userId = user.getId().asInt();

        int nbRowsAffected = dataSourceHandler.getJdbcTemplate()
                .update("UPDATE THUBCONTRAT SET STATE = ? WHERE FK_THUB_CONTRAT_USER = ?", newState.name(), userId);

        if (nbRowsAffected == 0) {
            throw new NoDataUpdatedException("Unable to update contract with userId " + userId + " with new status " + newState.name());
        }
    }

}
