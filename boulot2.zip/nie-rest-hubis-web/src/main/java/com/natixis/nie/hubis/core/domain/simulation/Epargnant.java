package com.natixis.nie.hubis.core.domain.simulation;


import static com.natixis.nie.hubis.features.simulation.SimulationItems.asInt;

public class Epargnant {

    private final int abondementBrut;
    private final SimulationCriteria criteria;
    private final Remuneration remuneration;

    public Epargnant(int versement, int abondementBrut, SimulationCriteria criteria) {
        this.criteria = criteria;
        this.abondementBrut = abondementBrut;
        this.remuneration = new Remuneration(versement, criteria);
    }

    public int getVersementAnnuel() {
        return asInt(abondementBrut / criteria.getDatas().getTauxAbondement());
    }

    public int getVersementMensuel() {
        return getVersementAnnuel() / 12;
    }

    public Remuneration getRemuneration() {
        return remuneration;
    }
}

