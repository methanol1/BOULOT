package com.natixis.nie.hubis.features.recapitulatif;

import com.natixis.nie.hubis.core.SouscriptionService;
import com.natixis.nie.hubis.core.domain.State;
import com.natixis.nie.hubis.core.domain.User;
import com.natixis.nie.hubis.web.AbstractRestResource;
import io.swagger.annotations.Api;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import static com.natixis.nie.hubis.core.domain.State.RECAPITULATIF;

@Path("/v1/recapitulatif")
@Produces({MediaType.APPLICATION_JSON})
@Consumes(MediaType.APPLICATION_JSON)
@Api(value = "v1-recapitulatif",
        description = "Exposes services to deal with recapitulatif",
        consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
public class RecapitulatifResource extends AbstractRestResource {

    @Inject
    SouscriptionService souscriptionService;

    @POST
    public Response validate() {

        User user = appSecurity.getCurrentUserForState(RECAPITULATIF);

        State state = souscriptionService.validateSimulation(user);

        return sendState(state);
    }

}
