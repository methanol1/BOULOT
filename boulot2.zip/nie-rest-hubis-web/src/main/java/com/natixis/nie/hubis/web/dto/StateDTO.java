package com.natixis.nie.hubis.web.dto;


import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.natixis.nie.hubis.core.domain.State;

import java.util.List;

public class StateDTO {

    private State name;

    @JsonCreator
    public StateDTO(@JsonProperty("name") State name) {
        this.name = name;
    }

    public static StateDTO fromModel(State state) {
        return new StateDTO(state);
    }

    public State getName() {
        return name;
    }

    public List<State> getAllowedStates() {
        return name.allowedStates();
    }

    public State getNextState() {
        return name.nextState();
    }

}
