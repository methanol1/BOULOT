package com.natixis.nie.hubis.features.entreprise.web.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class SIRETValidator implements ConstraintValidator<SIRET, String> {

    @Override
    public void initialize(SIRET constraintAnnotation) {
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext constraintContext) {
        return value != null && value.length() == 14 && isLuhnValid(value);
    }

    private boolean isLuhnValid(String value) {
        int sum = 0;
        boolean alternate = false;
        for (int i = value.length() - 1; i >= 0; i--) {
            int n = Integer.parseInt(value.substring(i, i + 1));
            if (alternate) {
                n *= 2;
                if (n > 9) {
                    n = (n % 10) + 1;
                }
            }
            sum += n;
            alternate = !alternate;
        }
        return (sum % 10 == 0);
    }
}
