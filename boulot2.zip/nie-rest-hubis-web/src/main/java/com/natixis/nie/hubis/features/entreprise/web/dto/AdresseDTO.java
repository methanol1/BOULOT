package com.natixis.nie.hubis.features.entreprise.web.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.natixis.nie.hubis.core.domain.Adresse;

public class AdresseDTO {

    private String rue;
    private int codePostal;
    private String ville;

    @JsonCreator
    public AdresseDTO(@JsonProperty("rue") String rue, @JsonProperty("codePostal") int codePostal, @JsonProperty("ville") String ville) {
        this.rue = rue;
        this.codePostal = codePostal;
        this.ville = ville;
    }

    public String getRue() {
        return rue;
    }

    public int getCodePostal() {
        return codePostal;
    }

    public String getVille() {
        return ville;
    }

    public Adresse toModel() {
        return new Adresse(rue, codePostal, ville);
    }

    public static AdresseDTO fromModel(Adresse adresse) {
        return new AdresseDTO(adresse.getRue(), adresse.getCodePostal(), adresse.getVille());
    }

}
