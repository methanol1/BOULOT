package com.natixis.nie.hubis.core;

import com.natixis.nie.hubis.core.domain.Document;
import com.natixis.nie.hubis.core.domain.DocumentMetadatas;


public interface Ged {

    void save(Document... documents);

    Document get(DocumentMetadatas metadatas);
}
