package com.natixis.nie.hubis.features.entreprise.kbis.societe.xml;


import com.natixis.nie.hubis.core.Datas;
import com.natixis.nie.hubis.core.KbisMapper;
import com.natixis.nie.hubis.core.domain.Adresse;
import com.natixis.nie.hubis.core.domain.FormeJuridique;
import com.natixis.nie.hubis.core.domain.Nace;
import com.natixis.nie.hubis.core.domain.Siret;
import com.natixis.nie.hubis.core.domain.kbis.BilanInfos;
import com.natixis.nie.hubis.core.domain.kbis.DirigeantInfos;
import com.natixis.nie.hubis.core.domain.kbis.EntrepriseInfos;
import com.natixis.nie.hubis.core.domain.kbis.Kbis;
import com.natixis.nie.hubis.core.exception.AppException;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.StringReader;
import java.time.Month;
import java.util.*;

import static java.util.stream.Collectors.toList;

@Singleton
public class KbisXmlMapper implements KbisMapper {

    private final Datas datas;
    private final JAXBContext jaxbContext;

    @Inject
    public KbisXmlMapper(Datas datas) {
        this.datas = datas;

        try {
            jaxbContext = JAXBContext.newInstance(XmlSociete.class);
        } catch (JAXBException e) {
            throw new AppException("Unable to init jaxb context", e);
        }
    }

    @Override
    public Optional<Kbis> map(String xml) {

        if (xml.contains("errcode")) {
            return Optional.empty();
        }
        XmlSociete xmlSociete = unmarshall(xml);
        Kbis kbis = new Kbis(xml, extractEntreprise(xmlSociete), extractDirigeants(xmlSociete));

        return Optional.of(kbis);
    }

    private XmlSociete unmarshall(String xml) {
        try {
            Unmarshaller unmarshaller = createUnmarshaller();
            return (XmlSociete) unmarshaller.unmarshal(new StringReader(xml));
        } catch (JAXBException e) {
            throw new AppException("Unable to create entreprise from kbis xml content " + xml, e);
        }
    }

    private EntrepriseInfos extractEntreprise(XmlSociete xmlSociete) {

        DirigeantInfos dirigeant = extractDefaultDirigeant(xmlSociete);
        FormeJuridique formeJuridique = extractFormeJuridique(xmlSociete);
        Nace nace = extractNace(xmlSociete);
        Adresse adresse = new Adresse(xmlSociete.adresse, xmlSociete.codepostal, xmlSociete.commune);
        Siret siret = new Siret(xmlSociete.siret);
        Month moisDeCloture = Month.of(12);
        BilanInfos bilan = extractLastBilan(xmlSociete);
        Date dateFinExerc = bilan.getDateFinExerc();
        if (dateFinExerc != null) {
            Calendar cal = Calendar.getInstance();
            cal.setTime(dateFinExerc);
            moisDeCloture = Month.of(cal.get(Calendar.MONTH) + 1);
        }

        return new EntrepriseInfos(siret, xmlSociete.denomination, formeJuridique, nace, adresse, dirigeant, moisDeCloture);
    }

    private DirigeantInfos extractDefaultDirigeant(XmlSociete societe) {
        if (societe.hasDirigeants()) {
            return societe.dirigeants.stream()
                    .findFirst()
                    .map(d -> new DirigeantInfos(d.denomination, d.titre))
                    .get();
        }
        return new DirigeantInfos(societe.enseigne, "Dirigeant");
    }


    private List<DirigeantInfos> extractDirigeants(XmlSociete xmlSociete) {
        if (!xmlSociete.hasDirigeants()) {
            return new ArrayList<>();
        }

        return xmlSociete.dirigeants.stream()
                .map(d -> new DirigeantInfos(d.denomination, d.titre))
                .collect(toList());
    }

    private Nace extractNace(XmlSociete societe) {
        return datas.findAllNaces().stream()
                .filter(n -> n.getCode().equals(societe.nace))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Unable to find Nace with code " + societe.nace));
    }

    private FormeJuridique extractFormeJuridique(XmlSociete societe) {
        if (societe.hasFormeJuridique()) {
            return datas.findAllFormesJuridiques().stream()
                    .filter(fj -> fj.getLabel().equals(societe.formeJuridique))
                    .findFirst()
                    .orElseThrow(() -> new IllegalArgumentException("Unable to find Forme juridique with label " + societe.formeJuridique));
        }
        return null;
    }

    private Unmarshaller createUnmarshaller() {
        try {
            return jaxbContext.createUnmarshaller();
        } catch (JAXBException e) {
            throw new AppException("Unable to initialize xml loader", e);
        }
    }

    private BilanInfos extractLastBilan(XmlSociete societe) {
        if (societe.hasBilans()) {
            return societe.bilans.stream()
                    .findFirst()
                    .map(b -> new BilanInfos(b.dateFinExerc))
                    .get();
        }
        return new BilanInfos(null);
    }
}
