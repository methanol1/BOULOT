package com.natixis.nie.hubis.features.editique.bean;

public class EditiqueBean {
    //modèle éditique
    private String model;

    //Entreprise
    private String siret;
    private String raisonSociale;
    private String formeJuridique;
    private String codeNAF;
    private String effectifs;
    private String moisCloture;
    private String adresseEntreprise;
    private String codePostalEntreprise;
    private String villeEntreprise;

    //Responsable légal
    private String denomRespLegal;
    private String fonction;
    private String telephone;
    private String adresseRespLegal;
    private String codePostalRespLegal;
    private String villeRespLegal;
    private String email;

    //Contrat
    private String autreTeneur;
    private String nomAutreTeneur;
    private String plafondMontant;
    private String plafondPASS;
    private String versementMensuel;
    private String valeurCESU;
    private String dateSignature;
    private String epargneSalariale;
    private String CESU;

    //Coordonnées bancaires
    private String BIC;
    private String IBAN;

    //Liens
    private String lienRatification;
    private String lienReglementPlan;
    private String lienReglementFonds;
    private String lienConditionsGeneralesES;
    private String lienAnnexeTarifaire;
    private String lienContratEchange;
    private String lienConditionsGeneralesCESU;
    private String libLienRatification;
    private String libLienReglementPlan;
    private String libLienReglementFonds;
    private String libLienConditionsGeneralesES;
    private String libLienAnnexeTarifaire;
    private String libLienContratEchange;
    private String libLienConditionsGeneralesCESU;

    public String getModel() {
        return model;
    }

    public void setModel(String aModel) {
        model = aModel;
    }

    public String getSiret() {
        return siret;
    }

    public void setSiret(String aSiret) {
        siret = aSiret;
    }

    public String getRaisonSociale() {
        return raisonSociale;
    }

    public void setRaisonSociale(String aRaisonSociale) {
        raisonSociale = aRaisonSociale;
    }

    public String getFormeJuridique() {
        return formeJuridique;
    }

    public void setFormeJuridique(String aFormeJuridique) {
        formeJuridique = aFormeJuridique;
    }

    public String getCodeNAF() {
        return codeNAF;
    }

    public void setCodeNAF(String aCodeNAF) {
        codeNAF = aCodeNAF;
    }

    public String getEffectifs() {
        return effectifs;
    }

    public void setEffectifs(String aEffectifs) {
        effectifs = aEffectifs;
    }

    public String getMoisCloture() {
        return moisCloture;
    }

    public void setMoisCloture(String aMoisCloture) {
        moisCloture = aMoisCloture;
    }

    public String getAdresseEntreprise() {
        return adresseEntreprise;
    }

    public void setAdresseEntreprise(String aAdresseEntreprise) {
        adresseEntreprise = aAdresseEntreprise;
    }

    public String getCodePostalEntreprise() {
        return codePostalEntreprise;
    }

    public void setCodePostalEntreprise(String aCodePostalEntreprise) {
        codePostalEntreprise = aCodePostalEntreprise;
    }

    public String getVilleEntreprise() {
        return villeEntreprise;
    }

    public void setVilleEntreprise(String aVilleEntreprise) {
        villeEntreprise = aVilleEntreprise;
    }

    public String getDenomRespLegal() {
        return denomRespLegal;
    }

    public void setDenomRespLegal(String aDenomRespLegal) {
        denomRespLegal = aDenomRespLegal;
    }

    public String getFonction() {
        return fonction;
    }

    public void setFonction(String aFonction) {
        fonction = aFonction;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String aTelephone) {
        telephone = aTelephone;
    }

    public String getAdresseRespLegal() {
        return adresseRespLegal;
    }

    public void setAdresseRespLegal(String aAdresseRespLegal) {
        adresseRespLegal = aAdresseRespLegal;
    }

    public String getCodePostalRespLegal() {
        return codePostalRespLegal;
    }

    public void setCodePostalRespLegal(String aCodePostalRespLegal) {
        codePostalRespLegal = aCodePostalRespLegal;
    }

    public String getVilleRespLegal() {
        return villeRespLegal;
    }

    public void setVilleRespLegal(String aVilleRespLegal) {
        villeRespLegal = aVilleRespLegal;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String aEmail) {
        email = aEmail;
    }

    public String getAutreTeneur() {
        return autreTeneur;
    }

    public void setAutreTeneur(String aAutreTeneur) {
        autreTeneur = aAutreTeneur;
    }

    public String getNomAutreTeneur() {
        return nomAutreTeneur;
    }

    public void setNomAutreTeneur(String aNomAutreTeneur) {
        nomAutreTeneur = aNomAutreTeneur;
    }

    public String getPlafondMontant() {
        return plafondMontant;
    }

    public void setPlafondMontant(String aPlafondMontant) {
        plafondMontant = aPlafondMontant;
    }

    public String getPlafondPASS() {
        return plafondPASS;
    }

    public void setPlafondPASS(String aPlafondPASS) {
        plafondPASS = aPlafondPASS;
    }

    public String getVersementMensuel() {
        return versementMensuel;
    }

    public void setVersementMensuel(String aVersementMensuel) {
        versementMensuel = aVersementMensuel;
    }

    public String getValeurCESU() {
        return valeurCESU;
    }

    public void setValeurCESU(String aValeurCESU) {
        valeurCESU = aValeurCESU;
    }

    public String getDateSignature() {
        return dateSignature;
    }

    public void setDateSignature(String aDateSignature) {
        dateSignature = aDateSignature;
    }

    public String getEpargneSalariale() {
        return epargneSalariale;
    }

    public void setEpargneSalariale(String aEpargneSalariale) {
        epargneSalariale = aEpargneSalariale;
    }

    public String getCESU() {
        return CESU;
    }

    public void setCESU(String aCESU) {
        CESU = aCESU;
    }

    public String getBIC() {
        return BIC;
    }

    public void setBIC(String aBIC) {
        BIC = aBIC;
    }

    public String getIBAN() {
        return IBAN;
    }

    public void setIBAN(String aIBAN) {
        IBAN = aIBAN;
    }

    public String getLienRatification() {
        return lienRatification;
    }

    public void setLienRatification(String aLienRatification) {
        lienRatification = aLienRatification;
    }

    public String getLienReglementPlan() {
        return lienReglementPlan;
    }

    public void setLienReglementPlan(String aLienReglementPlan) {
        lienReglementPlan = aLienReglementPlan;
    }

    public String getLienReglementFonds() {
        return lienReglementFonds;
    }

    public void setLienReglementFonds(String aLienReglementFonds) {
        lienReglementFonds = aLienReglementFonds;
    }

    public String getLienConditionsGeneralesES() {
        return lienConditionsGeneralesES;
    }

    public void setLienConditionsGeneralesES(String aLienConditionsGeneralesES) {
        lienConditionsGeneralesES = aLienConditionsGeneralesES;
    }

    public String getLienAnnexeTarifaire() {
        return lienAnnexeTarifaire;
    }

    public void setLienAnnexeTarifaire(String aLienAnnexeTarifaire) {
        lienAnnexeTarifaire = aLienAnnexeTarifaire;
    }

    public String getLienContratEchange() {
        return lienContratEchange;
    }

    public void setLienContratEchange(String aLienContratEchange) {
        lienContratEchange = aLienContratEchange;
    }

    public String getLienConditionsGeneralesCESU() {
        return lienConditionsGeneralesCESU;
    }

    public void setLienConditionsGeneralesCESU(String aLienConditionsGeneralesCESU) {
        lienConditionsGeneralesCESU = aLienConditionsGeneralesCESU;
    }

    public String getLibLienRatification() {
        return libLienRatification;
    }

    public void setLibLienRatification(String aLibLienRatification) {
        libLienRatification = aLibLienRatification;
    }

    public String getLibLienReglementPlan() {
        return libLienReglementPlan;
    }

    public void setLibLienReglementPlan(String aLibLienReglementPlan) {
        libLienReglementPlan = aLibLienReglementPlan;
    }

    public String getLibLienReglementFonds() {
        return libLienReglementFonds;
    }

    public void setLibLienReglementFonds(String aLibLienReglementFonds) {
        libLienReglementFonds = aLibLienReglementFonds;
    }

    public String getLibLienConditionsGeneralesES() {
        return libLienConditionsGeneralesES;
    }

    public void setLibLienConditionsGeneralesES(String aLibLienConditionsGeneralesES) {
        libLienConditionsGeneralesES = aLibLienConditionsGeneralesES;
    }

    public String getLibLienAnnexeTarifaire() {
        return libLienAnnexeTarifaire;
    }

    public void setLibLienAnnexeTarifaire(String aLibLienAnnexeTarifaire) {
        libLienAnnexeTarifaire = aLibLienAnnexeTarifaire;
    }

    public String getLibLienContratEchange() {
        return libLienContratEchange;
    }

    public void setLibLienContratEchange(String aLibLienContratEchange) {
        libLienContratEchange = aLibLienContratEchange;
    }

    public String getLibLienConditionsGeneralesCESU() {
        return libLienConditionsGeneralesCESU;
    }

    public void setLibLienConditionsGeneralesCESU(
            String aLibLienConditionsGeneralesCESU) {
        libLienConditionsGeneralesCESU = aLibLienConditionsGeneralesCESU;
    }


}
