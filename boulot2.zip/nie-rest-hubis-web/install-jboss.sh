#!/usr/bin/env bash

mvn clean process-test-resources -Pgenerate-jboss-server -DskipTest -Djboss.output.dir=/c/work/apps

